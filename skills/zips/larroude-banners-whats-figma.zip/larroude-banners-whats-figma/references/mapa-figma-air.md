# Mapa · Figma + Air
Levantado em 05–06/10/2026. Arquivo Figma: FIGMA ZAINERS NOVO (`DRphNBA9HvgZ6HwazNMHrm`). Coordenadas aproximadas: confira com `scripts/figma/proximo_espaco_banners.js` antes de criar.

## 1. Onde criar no Figma

### 1.1 POP UP (`15686:2`)
- Cada campanha ganha uma **fileira nova embaixo** da última. A fileira começa em x=2162, com passo de ~655 em x entre as versões.
- Campanhas recentes:
  - y=5044: Best Duo 01-02/10, depois Best Duo Últimas Horas Cyprus e Stella;
  - y=5805: The Hit List Dolly / Fiore / Bianca.
- Próxima campanha: x=2162, y ≈ última fileira + 761.

### 1.2 Card Whats (`1019:238`)
- Blocos por campanha; os dias seguem em colunas.
- Recentes:
  - Best Duo: x 18813–22572, fileiras y 47748 / 48963;
  - The Hit List abertura: @15139,50428;
  - carrinho abandonado: coluna x=31835, y 50874→54879.
- Variação ou segunda ideia do mesmo dia: ao lado, +1.136 em x.

### 1.3 Banners (`3850:2`)
| Tipo | Coluna | Mais recente embaixo |
|---|---|---|
| Hero BR | DESK x=-116.822 · MOB x=-113.301 | The Hit List HERO2 @y 97245 (HERO1 @92495). Próximo: y + ~4.750 |
| Hero US | x≈-127.276 / -123.798 | L420 Fall @y 67917 |
| Middle | DESK -88.649 / MOB -85.271 (e -82.347/-78.969) | y≈65.270 |
| Slim / Collection Slider | DESK x≈-98.346 · MOB x≈-94.675 | The Hit List @y 50623 |
| Grid 1600 | x≈-105.015 / -103.304 | y≈-920 |
| Categoria 1080 | x -95.522 / -94.370 / -93.176 / -91.982 | fileira y=6180 |

Os TEXT "Homepage att BR/US DD.MM", "hero banner", "categorias" e "Bloco banner" marcam **mockups de homepage**, não peças.

### 1.4 Footers de email (Emails Brasil `21432:2` · Email USA `21433:7490`)
Organizados em 06/10/2026 em **uma coluna por mês**, com rótulo em Graphik Semibold 200 no topo. Dentro do mês, o mais recente fica embaixo e as variações do mesmo dia ficam lado a lado (+760 em x).
- **BR:**
  - colunas JUL / AGO / SET / OUT 26 em x = -120000 / -117700 / -115400 / -113100;
  - frames a partir de y=-93600, passo de 330.
  - Mês novo: coluna +2300 à direita, com rótulo ("NOV 26").
- **US:**
  - colunas JAN–SEP 26 em x = -118000 + (mês-1)×2300;
  - frames a partir de y=-99600, passo de 330.
- **Arquivo:** footers sem data e de 2025 ficam nas colunas antigas à esquerda, abaixo do título "Banners Footer".

## 2. Air

### 2.1 Fotos
- **Busca pelo SKU ou modelo:** `list_assets` com `search="L471-BIAN-BLAC-2422"` ou `"BIANCA LOW"`, e `includeThumbnails: true` para ver.
- **Pastas de modelo:** `list_boards name="<MODELO>"`. Ex.: "Cyprus on Model", "Cyprus Still Life", "09.24 Cyprus colors".
- **Prefira fotos cruas** (nome = SKU, `IMG_xxxx`, `GROUP_…`). Descarte:
  - peças finais com texto (`_STATIC_`, `_ADS_`, `Final`, "it's our bestseller…");
  - PDP com callouts (`_BR`, fundo cinza com setas) quando o texto for branco.
- **Download:** `curl "https://air-prod.imgix.net/<versionId>.jpg?w=1800&fm=jpg&q=90"` numa pasta de caminho curto (ex.: `C:/Users/<voce>/airtmp`).
- A busca semântica está desligada no plano atual (dá erro 422).
- **Site, como alternativa:** `https://br.larroude.com/products/<handle>.json` traz as fotos 1200×1800 (`site_produto.py`).

### 2.2 Entrega
| Peça | Pasta | Comentário no Asana |
|---|---|---|
| Pop Up | `Graphic Design › Site › Pop Up › 2026 › <MÊS AA> › <DD.MM Campanha>` (ex.: `OCT 26 › 06.10 The Hit List`) | `@Luiza Amanda Moreira disponível aqui!` + link |
| Card Whats | `Graphic Design › Whatsapp › 2026 › <MÊS AA> › <DD.MM Campanha>` | `@Luiza Amanda Moreira disponível aqui!` + link |
| Banners do site | `Graphic Design › Site › Banners Home › <DD.MM Campanha>`, sem ano nem mês (ex.: `05.10 60Off The Hit List`, `29.09 Nicolo B`). Landing page: `Site › LP` | `@Monique Tauane da Silva disponível aqui!` + link (gid 1210732809098268) |
| Footer de email | **não sobe para o Air** | marcar a pessoa **no Figma** para revisar; o CRM exporta depois |

IDs dos boards:
- **Site:** `7633254b-3c5c-4252-8650-948020a4eddd`
  - Pop Up `39a45342-7667-4f8c-b2f1-f0679be379b1` › 2026 `db6ef9bc-8d43-4336-9e1b-2f31267b4df6` › OCT 26 `c4331ec3-09eb-4ec4-8810-1543790edfa9`
  - Banners Home `5a3a3b3f-a215-4271-a65c-1b62c22eeadb`
  - LP `6628882c-a897-48ed-ad5f-b4cd1151003d`
- **Whatsapp:** `4562a3d8-1a54-4338-a2ff-52eb8eac1b79` › 2026 `00b93399-6f58-4cd1-88c4-8606be06d32e` › OCT 26 `3552bde2-ee7f-434a-a3a9-3e8763139038`
- Mês novo: crie `<MÊS AA>` (ex.: "NOV 26") dentro de 2026.
- **Datas das pastas:** aqui é **DD.MM** ("05.10 Best Duo"). No ADS é MM.DD.

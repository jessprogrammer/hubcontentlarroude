# Aprendizados com os ajustes da pessoa responsável
Cada item diz o que foi ajustado e o que vira regra ou tendência. As regras firmes ficam em `regras-firmes.md`.
**Método:** quando a pessoa disser "ajustei", **não edite**. Leia com `inspecionar_frames.js` e compare em tabela (onde / eu fiz / você fez / lição).

## 05/10 · POPUP_BR 05/10 - Best Duo Últimas Horas
- **Eu copiei o texto do card de WhatsApp da campanha** em vez de ler a tarefa. A COPY dizia "Últimas horas / Leve 2 best sellers com 60% off" e outro disclaimer.
  - **Regra:** a tarefa no Asana é o passo 1 e a COPY vale palavra por palavra (regras 1–3).
- **Eu repeti as fotos do card de WhatsApp** da mesma tarefa/campanha. **Regra:** não repetir foto dentro da tarefa; buscar no Air uma foto nova.
- **Ajuste dele (Stella):** texto mais baixo e maior (título Platform 63 em 4 linhas, caixa de 355px), degradê de cima removido e foto com zoom.
- **Versão final:** frame 600×600, texto alinhado à direita no canto superior direito. **Regra:** o texto vai na área livre da foto.
- **Nome com `/` quebra a exportação** para o Asana/Air. Use `-`.

## 05/10 · [BANNER Hero + Collection_Slider] - 60% OFF Itens Selecionados BR
Eu interpretei errado e ele montou a peça. O que mudou no entendimento:
- `XXX_` no nome = **ID da coleção do Shopify** (535822696762).
- **Collection_Slider = formato Slim** (3200×400 / 3200×1000), e não os quadrados de categoria 1080×1080.
- **"precisa de copy"** → ele criou um **conceito** ("The Hit List", hits de NY) com "60% OFF" grande em Very Vogue + "%" em Items. Um "Tudo com 60% off" genérico é fraco demais.
- **Hero 1 (só texto):** vermelho `#B41724` + butter `#FEE88E`. **Hero 2:** foto on-foot de NY.
- As fotos são **on-foot/lifestyle**, não still de PDP.
- QA que encontrei: no Hero 2 MOB, a headline e o subheader estavam ~34px fora do centro.

## 06/10 · POPUP_BR 06 a 11/10 - The Hit List
- **Eu fiz:** texto alinhado à esquerda, foto aberta, frame 600×600.
- **Ele fez:**
  - composição **centralizada** (eyebrow "THE HIT LIST" → 60% OFF → subheader);
  - **zoom fechado no produto**, com o produto grande embaixo;
  - eyebrow da campanha incluído mesmo fora da COPY.
- **Regras:**
  - na campanha, siga a identidade dela (eyebrow + Very Vogue);
  - no pop up, o produto aparece grande;
  - para uma versão nova, **duplique o frame ajustado e troque só a foto**.
- **Bianca:** a foto ideal (Sand) **não estava na lista da ação**. Usei a Champagne. **Regra:** conferir o SKU na planilha.
- **Pop Up passa a ser 600×600.**

## 06/10 · [FOOTER BR] 06 a 12/10 - The Hit List
- **Estrutura aprovada:** painel vermelho com texto + 3 faixas de produto, o que comunica "seleção".
- **Ajustes dele:**
  1. Caixa do subheader de 215 para **200px**: quebra equilibrada, sem palavra solta.
  2. CTA de y=167 para **y=184**: respiro de ~30px.
  3. Disclaimer de branco para **butter**: o painel fica com uma cor só.
  4. Faixas com **zoom aberto** (altura da imagem 0.55–0.96, contra 0.45–0.6 no meu): o par aparece inteiro.
- **Regra:** em foto única, zoom fechado; em faixa estreita, zoom aberto.

## 06/10 · Card Whats de abertura The Hit List (feito por ele)
- Grade 2×2: 3 fotos on-foot (uma por produto do briefing) + 1 quadrante vermelho com o texto em butter e o ícone L.
- Ele reaproveitou a foto do Hero 2 → **repetir foto entre canais da mesma campanha é ok**.

## 06/10 · Organização das colunas de footer
- A pessoa responsável escolheu **uma coluna por mês** (mais recente embaixo, variações ao lado, antigos sem data no arquivo). Ver `mapa-figma-air.md` §1.4.

## Erros a evitar
- Montar sem ler a tarefa e copiar texto de peça irmã.
- Usar foto com texto pronto ou foto já usada na mesma tarefa.
- Tentar carregar a fonte Very Vogue no conector: ela não existe lá. Use `clonar_texto_campanha.js`.
- Dar o upload de imagem como concluído sem conferir: um POST pode voltar 502 e a imagem não entrar. Confira o `imageHash` no node e repita com uma URL nova.
- Comentar no Asana antes da aprovação.

# Log de fotos usadas
- **Dentro da mesma tarefa:** nenhuma foto se repete.
- **Entre canais da mesma campanha:** repetir é aceitável.
- **Entre campanhas diferentes:** evite a mesma foto nos últimos 10 dias, salvo falta de material ou pedido; sinalize.
- Depois da entrega, acrescente uma linha por foto (mais recente em cima).

| Data | Tarefa · canal | Frame | Arquivo · id | Papel | Cena |
|---|---|---|---|---|---|
| 06/10/2026 | [FOOTER BR] 06 a 12/10 - The Hit List · Footer | 21703:2 | as 3 fotos dos pop ups abaixo (hashes 69ad2f46 / 99e69974 / 0bcdba9f) | faixas | reuso dentro da campanha |
| 06/10/2026 | POPUP_BR 06 a 11/10 - The Hit List · Pop Up | 21691:2 | L471-BIAN-CHAM-2653 · versão e714aee6 | herói | Bianca Low champagne on-foot, carro vintage azul |
| 06/10/2026 | POPUP_BR 06 a 11/10 - The Hit List · Pop Up | 21684:11 | L450-FIOR-BLAC-2875 · versão 42fec7a5 | herói | Flat Fiore on-foot, calçada com grade preta |
| 06/10/2026 | POPUP_BR 06 a 11/10 - The Hit List · Pop Up | 21684:3 | IMG_0785 (DOLLY VERONA LOW, L471-VERO-NATU-1967) · versão dc569607 | herói | sandália ráfia on-foot na escada, vestido dourado |
| 05/10/2026 | POPUP_BR 05/10 - Best Duo Últimas Horas · Pop Up | 21547:2 | GROUP_CYPRUS "Cyprus_2" (09.24 Cyprus colors) · versão 465ac1d9 | herói | 3 Cyprus camurça em fundo azul com sombra |
| 05/10/2026 | POPUP_BR 05/10 - Best Duo Últimas Horas · Pop Up | 21547:9 | STELLA_GROUP (2) · versão 4525d604 (já usada no card WPP 05-10; mantida pelo Pietro) | herói | Stella várias cores em diagonal, fundo verde |

# Formatos e padrões
Levantado em 05–06/10/2026 lendo todos os frames de cada aba e os ajustes da pessoa responsável.
**Regra geral:** o padrão vigente é o que está **mais embaixo da coluna** do formato. Antes de montar, confira se apareceu algo mais novo (`proximo_espaco_banners.js`).
Coordenadas relativas ao frame. Todo texto é branco (`#FFFFFF`) e centralizado, salvo indicação.

---

## 1. Pop Up (aba POP UP `15686:2`) · **600×600**
- **Tamanho:** 600×600 desde 06/10 (antes 550×550), mesmo que a tarefa diga 550.
- **Nome:** `POPUP_BR DD-MM - Tema - Produto` (ex.: `POPUP_BR 06 a 11-10 - The Hit List - Flat Fiore`).
- **Copy:** só o texto da COPY, **sem CTA** (o CTA fica no Klaviyo).
- **Padrão por tarefa:** 2 peças, um produto cada. Se o briefing lista 3 produtos, a pessoa responsável pode pedir a 3ª.
- **Estrutura:**
  - foto sangrada;
  - degradê escuro atrás do texto (Rectangle com GRADIENT preto 0→80%);
  - degradê no rodapé se o chão for claro;
  - disclaimer em Plain ~11, centralizado, no rodapé (y≈548–552).
- **O texto vai onde a foto deixa espaço:**

  | Versão final | Composição | Texto |
  |---|---|---|
  | The Hit List (`21684:3`/`:11`, `21691:2`) | **centralizada no alto** | eyebrow da campanha Platform 16 caps ls28 (y≈56) → "60% OFF" Very Vogue 117 (y≈74) → subheader Graphik 28.8 w330 (y≈190) |
  | Best Duo Últimas Horas (`21547:2`/`:9`) | **canto superior direito, alinhado à direita** | "Últimas horas" Graphik 28.8 @376,28 → título Platform 61 w389 @171,85 |
  | Best Duo 01-02/10 (`21317:46`) | **canto superior esquerdo** | eyebrow Graphik 26 → título Platform 56 em x=52 |

- **Foto:** zoom **fechado** no produto, com o produto grande na metade de baixo e o texto na parte escura de cima. O CROP fica em ~0.6–0.7 da largura da imagem.

---

## 2. Card Whats (aba Card Whats `1019:238`) · **1024×1024**
- **Nome:** `WPP_BR DD-MM - Tema [Produto]`. Cupom entre parênteses no fim. Use `DD-MM`, nunca `/`.
- **Canvas:** cada campanha forma um bloco; os dias seguem em colunas (passo ~1.130–1.500 em x) e as fileiras novas ficam ~1.215 abaixo. Ações paralelas (carrinho abandonado por produto) ficam numa coluna própria, empilhadas.
- **Duas ideias:** quando fizer sentido, entregue 2 hierarquias lado a lado (oferta em destaque × urgência em destaque) para o CRM escolher.

**Elementos fixos (campanhas recentes):**
| Elemento | Especificação |
|---|---|
| Ícone L | Vector branco 40×76 @492,185 (ou 24×45 dentro de um bloco de cor) |
| Overlay topo | Rectangle 1024² GRADIENT preto 30%→21%→0% |
| Degradê rodapé | Rectangle @0,759 1025×281 |
| Disclaimer | Plain Italic 18 · lh 21 · @145,942 · w734 · 2 linhas |

**Arquétipos:**
| # | Tipo | Texto | Exemplo |
|---|---|---|---|
| A | Foto sangrada (1 a 3 faixas) + título central | título Platform 86 (2 linhas, y≈387) + subtítulo Plain Light 31 caps (y≈563) | Best Duo 04-10 Verona |
| A' | Último dia, 2 hierarquias | "60% off" Platform 146 + linha Platform 49 · ou "ÚLTIMO DIA" Platform 106 caps + linha Graphik Medium/Plain Light 31 | Best Duo 05-10 |
| B | Oferta com cupom | abertura Plain 43 (y≈239) + "50% OFF" Suprapower 116 + "+10% OFF EXTRA" Suprapower 54 + cupom em caixa 442×96 com contorno de 3px (y≈709) | carrinho abandonado |
| C | Só tipografia, fundo sólido (lilás, burgundy `#481022` + butter `#FEE88E`) | L no topo + oferta + cupom | flash sale, 48H |
| D | Progressiva | 3 selos butter "1 PAR 50% / 2 PARES 60% / 3+ 70%" | 05/09, 11/09 |
| E | Barra de campanha no topo (1024×150, cor da campanha) com calendário | lockup + oferta Suprapower 60 + urgência Plain Light 48 | Larroudé Fest |
| F | Editorial serifado | Very Vogue + wordmark | "Últimos pares" |
| G | Lockup de collab, sem oferta | Larroudé by NICOLÒ B. + "Drop II" | Drop Nicolò |
| H | **Grade 2×2 de campanha** (vários produtos) | 3 quadrantes 512² com foto on-foot + 1 quadrante de cor `#B41724` com eyebrow Platform 14 caps → lead-in Platform 25 caps → "60% OFF" Very Vogue 117 (+% Items) → ícone L, tudo em butter | The Hit List 06-10 (`21672:187`) |

**Fontes:** Suprapower SE Heavy (ofertas, %), Platform (títulos), Plain Light/Regular (subtítulos, cupom), Plain Italic (disclaimer), Very Vogue + Items (campanhas editoriais), Blitz Script (lockups).

---

## 3. Banners do site (aba Banners `3850:2`)
Sempre em **par DESK + MOB**, salvo o Grid.

| Tipo | DESK | MOB | Coluna no canvas (aprox.) |
|---|---|---|---|
| Hero | 3200×1600 | 1920×3200 | BR: DESK x≈-116.8k, MOB x≈-113.3k; nova data ~4.750 abaixo. US: x≈-127k/-124k |
| Middle | 3200×1200 | 1920×2560 | pares lado a lado em x≈-88.6k/-85.3k e -82.3k/-79k |
| Slim / **Collection Slider** | 3200×400 | 3200×1000 | DESK x≈-98.3k, MOB x≈-94.7k |
| Grid / Categoria | 1600×1600 / 1080×1080 | — | Grid x≈-105k/-103.3k; Categoria x≈-95.5k…-92k (fileiras de 4) |

**Nomes:**
- Quando a tarefa dá o padrão `XXX_BANNER_…`: `XXX` = **ID da coleção do Shopify**. Ex.: `535822696762_BANNER_HERO1_DESKTOP`, `…_HERO2_MOBILE`, `…_BANNER_COLLECTION_SLIDER_DESK`.
- Promo BR antiga: `Herobanner_<CAMP>_DD-MM_DESK_BR`, `DD.MM_Middle_DESK_BR`.
- Produto (US): `<SKU>_BANNER_HERO_DESKTOP`, `<SKU>_BANNER_GRID`.

### 3.1 Hero de promo: grade atual (Best Duo 25-09 `20754:546`/`:536`, Fest 48H `20639:1560`)
| Camada | DESK 3200×1600 | MOB 1920×3200 |
|---|---|---|
| Eyebrow (texto) | Platform 73 caps ls28 · @950,304 w1301 | Platform 73 caps ls28 · @310,1104 |
| Eyebrow (lockup) | Blitz Script 143 + Suprapower 166 caps (y≈274–379) | Blitz 157 + Suprapower 182 (y≈597–711) |
| Título | Platform **139** · 1 linha · y=667 · sombra r310 | Platform **181** · 2 linhas · @191,1411 w1536 |
| Subheader | Graphik **67.5** caps · y=894 · sombra r78 a0.3 | Graphik **73** caps · @455,1814 |
| CTA | Plain **40** sublinhado · @1411,1052 · Ellipse preta 15% atrás | Plain **57** · @689,2137 |
| Disclaimer | Graphik **22** · 1 linha · @552,1509 w2096 | Graphik **36** · 2 linhas · @193,3055 w1534 |

- **Fundo:** foto com tint preto de 20–30% + 2 camadas pretas de tela cheia (10% e 7%). No MOB o texto não leva sombra; no DESK leva.
- **Hero split:** com 2 produtos, as fotos ficam lado a lado no DESK e uma sobre a outra no MOB.
- **Copy:**
  - título: frase da oferta em sentence case;
  - subheader: urgência em caixa alta;
  - CTA: em primeira pessoa ("Garantir meus pares").
- **Hero com conceito de campanha** (The Hit List): a headline vira **"60% OFF" em Very Vogue Text 414 com o "%" em Items**, abaixo de um eyebrow com o nome da campanha (Platform 51 caps ls28). O CTA e o disclaimer seguem a grade acima.
  - **Hero 1, só texto:** fundo `#B41724`, texto todo em butter `#FEE88E`.
  - **Hero 2, com foto:** texto branco.
- **Hero de collab:** só título Platform ~100 + CTA ("Descubra a Collab").

### 3.2 Middle
| | DESK 3200×1200 | MOB 1920×2560 |
|---|---|---|
| Título | Platform 100–130 · y≈510–535 | Platform 149–165 · y≈1140–1195 |
| Subtítulo | Graphik 55 / Plain 36 · y≈670–680 | Plain 50–60 · y≈1373 |
| CTA | Plain 36–40 · y≈873 | Plain 57 · y≈1616 |
| Disclaimer | Graphik 24 · y≈1525 | — |

### 3.3 Slim / Collection Slider (3200×400 · 3200×1000)
O "Collection_Slider" do briefing é **este formato**, e não os quadrados de categoria.
- **DESK (The Hit List `21591:71`):**
  - à esquerda, painel `#B41724` com texto alinhado à esquerda em x=211: eyebrow Platform 43 caps ls28 → "60% OFF" Very Vogue 184 → linha Graphik 32 caps;
  - à direita, foto on-foot; ícone L 48×91 no meio;
  - disclaimer Plain Italic 20 @0,339.
- **MOB (`21591:82`):** foto sangrada, texto **alinhado à direita** (até x≈3030), "60% OFF" Very Vogue 298, ícone L à esquerda (@352,434), disclaimer Plain Italic 32 @422,916.
- **Áreas de corte:** retângulos de 316px nas duas laterais (@0 e @2884). Nada de texto ou logo ali.
- **Promo simples:** eyebrow Plain 40 + headline Platform 85–90 numa linha, foto de produto à direita, L na ponta e disclaimer Plain 20 (y≈337).

### 3.4 Grid / Categoria
Foto quadrada **sem texto e sem logo**, uma por produto ou categoria. Grid 1600×1600; Categoria 1080×1080 (foto still de cima, fundo claro). O nome da categoria é renderizado pelo site, embaixo da imagem.

---

## 4. Footer de email (abas Emails Brasil / Email USA) · **700×255**
- **Nome:** `[FOOTER BR] DD a DD-MM - Tema` / `[FOOTER US] MM/DD - Tema` (sem `/` no frame BR: use `-`).
- **Lugar:** bloco "Banners Footer", na **coluna do mês** (ver `mapa-figma-air.md` §1.4).
- **Padrão de foto única** (Best Duo `21696:968`, 23/09, Sergio Hudson):
  - foto sangrada, com degradê no rodapé;
  - eyebrow Graphik 17 → título Platform 36 → CTA Plain 14.2 sublinhado → disclaimer Plain 9 em y≈219;
  - o texto vai na área vazia da foto (centro, direita ou esquerda).
- **Padrão de campanha com vários produtos** (The Hit List `21703:2`, aprovado com ajustes):

  | Elemento | Especificação |
  |---|---|
  | Painel | `#B41724`, x 0–320 |
  | Fotos | 3 faixas de 125×255 (x 322 / 448 / 574), com **zoom aberto** (o par inteiro aparece) |
  | Eyebrow | Platform 11 caps ls28 · y36 |
  | Headline | "60% OFF" Very Vogue 66 · y52 |
  | Subheader | Graphik 15 lh18 · **caixa de 200px** (2 linhas equilibradas) · y117 |
  | CTA | Plain 13 sublinhado · **y184** (~30px de respiro) |
  | Disclaimer | Plain 8 · **butter**, como o resto do texto · y232 w640 |
  | Degradê | sobre as fotos, no rodapé |

  Por que funciona: ver três produtos lado a lado deixa claro que é **seleção**, e não a loja toda.
- **Exportação:** os footers antigos têm um `Slice 01` 700×255. Mantenha.

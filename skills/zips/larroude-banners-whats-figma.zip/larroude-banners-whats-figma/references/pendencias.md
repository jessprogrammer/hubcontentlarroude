# Pendências (decisões em aberto)
Atualize quando forem respondidas.

1. **Banners US:** convenção de nome e de coluna para as próximas campanhas US ainda não testada nesta skill.

## Respondidas (06/10/2026)
- **Pastas do Air:**
  - Card Whats → `Whatsapp › 2026 › <MÊS AA> › <DD.MM Campanha>`;
  - Banners → `Site › Banners Home › <DD.MM Campanha>`;
  - Pop Up → `Site › Pop Up › 2026 › <MÊS AA> › <DD.MM Campanha>`.
- **Footer de email:** não vai para o Air. A pessoa é marcada no Figma para revisar e o CRM exporta depois.
- **Very Vogue Text:** use como der, copiando o texto de outra artboard (`clonar_texto_campanha.js`).
- **"60% off" × "60% OFF":** ignorar. A caixa do lockup da campanha não precisa ser sinalizada.
- **Footers antigos** (arquivo das abas de email): deixar como estão.
- **Entrega de Banners do site:** marcar @Monique Tauane da Silva.

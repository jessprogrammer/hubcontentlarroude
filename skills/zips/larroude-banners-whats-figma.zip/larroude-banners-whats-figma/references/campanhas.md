# Campanhas fechadas (referência)
Use para ver como uma campanha se desdobra entre canais. Não copie texto daqui: o texto vem sempre da COPY da tarefa.

## The Hit List · 60% off em itens selecionados (BR, 06–12/10/2026)
- **Conceito:** "The Hit List", os favoritos de NY. Coleção Shopify `535822696762` (link `/collections/the-hit-list`).
- **Identidade:** vermelho `#B41724` + butter `#FEE88E`. "60% OFF" em Very Vogue Text com o "%" em Items. Eyebrow "THE HIT LIST" em Platform caixa alta ls28.
- **Produtos de foco:** Dolly Verona Low, Flat Fiore, Plataforma Bianca Low (+ lista de 166 SKUs na planilha da ação).
- **Peças:**
  | Canal | Frame | Formato |
  |---|---|---|
  | Hero 1 (só texto) | `21589:2` / `21589:13` | vermelho + butter |
  | Hero 2 (foto) | `21589:22` / `21589:33` | foto NY, texto branco |
  | Collection Slider | `21591:71` / `21591:82` | Slim: painel vermelho + foto |
  | Pop Up 06–11/10 | `21684:3` / `21684:11` / `21691:2` | 600², centralizado |
  | Card Whats abertura | `21672:187` | grade 2×2 + quadrante vermelho |
  | Footer BR | `21703:2` | painel vermelho + 3 faixas |
- **Air:** `Site › Pop Up › 2026 › OCT 26 › 06.10 The Hit List`.

## Best Duo · leve 2 best sellers com 60% off (BR, 01–05/10/2026)
- **Produtos:** Cyprus, Verona, Stella.
- **Peças:**
  - Card Whats 01→05-10, com 2 ideias no Último Dia;
  - Hero 25-09 (split de 2 fotos);
  - Slim "Favoritos em dobro";
  - Pop Ups 01-02/10 e Últimas Horas 05/10 (600², texto no canto superior direito);
  - Footer 01 a 05-10.
- **Air:** `Site › Pop Up › 2026 › OCT 26 › 05.10 Best Duo`.

## Larroudé Fest (BR, 23–27/09/2026)
- **Identidade:** azul `#2364AA`, lockup "Larroudé" em Blitz Script + "FEST" em Suprapower, e calendário com 4 dias/produtos (Botas, Stella, Verona, Cyprus).
- **Peças:**
  - cards com barra de calendário no topo;
  - hero 48H;
  - pop ups "50% off em <produto> / Apenas 24 horas";
  - footers com 4 cartões de foto em P&B e o produto do dia em destaque.

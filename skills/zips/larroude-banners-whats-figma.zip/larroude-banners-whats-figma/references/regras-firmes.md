# Regras firmes · checklist
Versão 06/10/2026. Valem sempre. Rode **antes de montar** e **no QA**. Se uma regra não puder ser cumprida, sinalize na entrega; não ignore.

## Tarefa e texto
- [ ] 1. Li a **tarefa atual** no Asana antes de abrir o Figma (o nome da peça é o nome da tarefa).
- [ ] 2. O texto da arte é o da **seção COPY**, palavra por palavra. Só as quebras de linha podem mudar. Em conflito com outra linha da tarefa (ex.: "DISCLAIMER:"), vale a COPY.
- [ ] 3. Peças irmãs (card de WhatsApp, email, pop up de outro dia) servem de referência de **layout e foto**, **nunca de texto**.
- [ ] 4. O CTA do **pop up** fica **fora** da arte. No footer e nos banners de Hero e Middle, ele entra.
- [ ] 5. O assunto da campanha (ex.: "THE HIT LIST") pode entrar como eyebrow/assinatura, mesmo sem estar na COPY.

## Formato, nome e lugar
- [ ] 6. Tamanhos: Card Whats 1024² · Pop Up **600²** · Hero 3200×1600/1920×3200 · Middle 3200×1200/1920×2560 · Slim/Collection Slider 3200×400/3200×1000 · Grid 1600² / Categoria 1080² · Footer 700×255.
- [ ] 7. Nome = nome da tarefa, **sem `/`** (troque por `-`). `XXX_` = ID da coleção do Shopify.
- [ ] 8. Lugar no canvas: seguindo a organização da aba (`mapa-figma-air.md`). O mais recente fica **embaixo** da coluna, e as versões da mesma tarefa ficam lado a lado.
- [ ] 9. Banners saem em **par DESK + MOB**. O Grid é peça única.

## Fotos
- [ ] 10. Só fotos reais (nunca IA). Nada de peça final de ads com texto ou logo como foto.
- [ ] 11. Os produtos das fotos estão na **lista da ação**, na planilha ou em PRODUCTS. Produto fora do site entra, mas é sinalizado.
- [ ] 12. **Nenhuma foto repetida dentro da mesma tarefa.** Entre canais da mesma campanha, pode.
- [ ] 13. Calçado inteiro e reconhecível, sem texto em cima do produto.
  - Foto única: zoom fechado.
  - Faixa ou grade estreita: zoom aberto.

## Tipografia e cor
- [ ] 14. Texto branco só sobre área escura ou calma. Preto só sobre branco ou cor clara, sem dividir espaço com mais nada.
- [ ] 15. Disclaimer legível. Se o fundo for claro, use degradê escuro no rodapé.
- [ ] 16. Sem palavra solta na última linha. Estreite a caixa de texto para equilibrar as linhas.
- [ ] 17. Wordmark com acento **sempre rosa**. Lockup de collab intocável (só escalar).
- [ ] 18. Nunca converter texto em vetor.

## Entrega
- [ ] 19. Air e Asana **só depois da aprovação**. O footer de email não vai para o Air: fica no Figma para revisão e exportação do CRM.
- [ ] 20. Arquivos juntos na pasta da campanha. Confira a contagem antes de comentar.
- [ ] 21. Comentário com menção real (Pop Up/Whats: @Luiza Amanda Moreira + "disponível aqui!" + link). Banners do site: @Monique Tauane da Silva.
- [ ] 22. Nunca apagar ou mover trabalho de outra pessoa sem pedido.

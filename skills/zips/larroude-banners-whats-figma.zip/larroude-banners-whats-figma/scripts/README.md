# Biblioteca de scripts (banners, pop ups, footers, WhatsApp)
Scripts testados. **Use estes antes de escrever código novo.**
- **Figma:** rode com `use_figma` (skillNames `figma-use`), editando só o bloco `CONFIG` do topo. Os scripts devolvem texto sem acento, porque o conector quebra com acento no retorno.
- **Python:** precisa de Pillow e numpy (o `doc_imagens.py` também precisa de pymupdf). Trabalhe numa pasta de caminho curto, como `C:/Users/<voce>/airtmp`; caminho longo quebra o curl no Windows.

## Fluxo típico de uma peça
1. Onde criar → `figma/proximo_espaco_banners.js`
2. Fotos → `python/air_baixar.py` (Air) ou `python/site_produto.py` (site, SKU, ON/OFF) → `python/folha_contato.py`
3. Área calma para o texto → `python/area_vazia.py`
4. Subir para o Figma → `figma/enviar_imagem.md` (confira o `imageHash` no node: o POST pode voltar 502)
5. Enquadrar → `figma/aplicar_crop.js` (ou calcular antes com `python/crop_celula.py`)
6. Textos → `figma/trocar_texto.js`. Headline em Very Vogue → `figma/clonar_texto_campanha.js`
7. QA → `figma/qa_rapido.js` + 1 print por peça
8. Aprender com o ajuste → `figma/inspecionar_frames.js` (antes e depois)
9. Entregar → `figma/exportar_para_air.md`

## Figma (`figma/`)
| Script | O que faz | Altera? |
|---|---|---|
| `proximo_espaco_banners.js` | Colunas de um formato numa aba, a peça mais embaixo de cada uma e onde criar a próxima | não |
| `clonar_texto_campanha.js` | Duplica e redimensiona um texto pronto (ex.: "60% OFF" Very Vogue) sem carregar a fonte | sim |
| `aplicar_crop.js` | Põe a foto com CROP sem esticar (zoom e centro escolhidos) e avisa resolução baixa | sim |
| `trocar_texto.js` | Troca o texto mantendo o estilo de cada linha; avisa fonte faltando | sim |
| `qa_rapido.js` | Margens, camadas escondidas, crop vazando ou esticado, resolução, fontes, nomes | não |
| `inspecionar_frames.js` | Raio-X dos frames (posições, estilos, crops, efeitos) para comparar antes e depois | não |
| `enviar_imagem.md` | Upload de foto do computador (upload_assets + POST dos bytes) | sim |
| `exportar_para_air.md` | Exportar PNG do Figma → importar no Air → comentar no Asana | externo |

## Python (`python/`)
| Script | O que faz |
|---|---|
| `air_baixar.py <versionId> saida.jpg [--largura 1800]` | Baixa a foto do Air pelo id de versão (imgix) |
| `site_produto.py <link/handle>` | Título, SKU, ON/OFF e fotos do site |
| `folha_contato.py saida.jpg fotos...` | Folha de contato numerada para escolher fotos |
| `area_vazia.py` | Mede a área calma da foto para pôr texto |
| `crop_celula.py W H cw ch [--zoom] [--cx] [--cy]` | Calcula o imageTransform e a resolução |
| `recorte_calcado.py entrada saida.png` | Tira o fundo liso do packshot |
| `doc_imagens.py doc.json saida/` | Lê o doc de copy dos comentários como imagem (modelo + fotos) |

## Valores de referência
- **Pop Up 600²:** CROP com ~0.6–0.7 da largura da imagem (zoom fechado), produto na metade de baixo.
- **Faixa estreita** (footer 125×255): altura da imagem 0.55–0.96 (zoom aberto), o par inteiro.
- **Degradê de legibilidade:** preto de 0% a 60–80%, atrás do texto ou no rodapé.

## Origem e testes
- `aplicar_crop`, `trocar_texto`, `qa_rapido`, `inspecionar_frames`, `enviar_imagem` e os scripts Python vêm da skill de ADS (testados em 01/10/2026). O `doc_imagens.py` vem da skill de emails.
- `proximo_espaco_banners.js`: testado em 06/10 na aba POP UP (próxima fileira em y=6566).
- `clonar_texto_campanha.js`: mesma lógica usada nos pop ups e no footer The Hit List (06/10).
- `exportar_para_air.md`: usado nas entregas de 05 e 06/10.
- `qa_rapido.js` tem margens de 1080×1920 (ADS). Para os formatos daqui, use a margem de 40px e confira as áreas de corte do Slim (316px nas laterais).

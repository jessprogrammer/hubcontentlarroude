// Aplica uma foto (imageHash) num retângulo/frame com CROP sem esticar.
// Uso: use_figma (skillNames "figma-use"). Edite o bloco CONFIG. Retorno ASCII.
// imgW/imgH = tamanho real da imagem (retornado por figma.getImageByHash(hash).getSizeAsync()).
// zoom 1 = maior recorte possível; 1.05–1.2 = zoom leve (padrão da casa).
// cx/cy = centro do assunto na foto (0–1). Calçado no terço de baixo → cy 0.7.
const CONFIG = {
  pageId: 'PAGE_ID',
  itens: [
    // { node: 'NODE_ID', hash: 'IMAGE_HASH', zoom: 1.1, cx: 0.5, cy: 0.6 },
  ],
};

function calcCrop(W, H, cw, ch, zoom = 1, cx = 0.5, cy = 0.5) {
  let sx = 1, sy = sx * W * ch / (H * cw);
  if (sy > 1) { sy = 1; sx = sy * H * cw / (W * ch); }
  sx /= zoom; sy /= zoom;
  const tx = Math.min(Math.max(cx - sx / 2, 0), 1 - sx);
  const ty = Math.min(Math.max(cy - sy / 2, 0), 1 - sy);
  return { t: [[sx, 0, tx], [0, sy, ty]], res: (sx * W) / cw };
}

const page = await figma.getNodeByIdAsync(CONFIG.pageId);
await figma.setCurrentPageAsync(page);
const out = [];
for (const it of CONFIG.itens) {
  const n = await figma.getNodeByIdAsync(it.node);
  if (!n) { out.push(it.node + ' NAO ENCONTRADO'); continue; }
  const img = figma.getImageByHash(it.hash);
  const { width: W, height: H } = await img.getSizeAsync();
  const { t, res } = calcCrop(W, H, n.width, n.height, it.zoom, it.cx, it.cy);
  n.fills = [{ type: 'IMAGE', imageHash: it.hash, scaleMode: 'CROP', imageTransform: t }];
  out.push(it.node + ' ok res=' + res.toFixed(2) + (res < 1 ? ' BAIXA RESOLUCAO' : ''));
}
return out;

# Enviar uma foto local para o Figma (upload_assets)

Usar depois de baixar a foto (`python/air_baixar.py`, `python/site_produto.py --baixar`) ou de gerar um recorte (`python/recorte_calcado.py`).

1. **Crie os retângulos de destino** no frame (ou numa área de apoio) com `use_figma`. Anote os nodeIds.
2. **Chame `upload_assets`** do conector Figma com `fileKey` e `nodeIds` (um por imagem). Ele devolve uma URL de envio para cada node.
3. **Envie os bytes crus** para cada URL (mantém o nome da camada):
   ```bash
   curl -s -X POST -H "Content-Type: image/jpeg" --data-binary @C:/Users/<voce>/airtmp/foto.jpg "<URL_DE_ENVIO>"
   ```
   PNG transparente: `-H "Content-Type: image/png"`.
4. O node passa a ter a imagem com `scaleMode: FILL`. **Em seguida rode `aplicar_crop.js`** com o imageHash do node (leia em `node.fills[0].imageHash`) para enquadrar sem esticar.

Cuidados:
- Use caminho curto (C:/Users/<voce>/airtmp). Caminhos longos quebram o curl e o Python no Windows.
- Uma foto por node. Para usar a mesma foto em vários nodes, envie uma vez e copie o imageHash.
- Para economizar tempo, monte com 2400px de largura. Use o original só se a resolução no QA ficar abaixo de 1×.
- Limpeza: o que é teste e não entrou na arte final pode ser apagado do airtmp depois de 2 dias.

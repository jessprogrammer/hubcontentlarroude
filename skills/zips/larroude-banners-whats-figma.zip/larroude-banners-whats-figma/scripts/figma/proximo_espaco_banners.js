// Leitura (não altera nada). Mostra as peças mais recentes de um formato, por coluna,
// e sugere onde criar a próxima (embaixo da coluna). Serve para POP UP, Card Whats,
// Banners e Footers. Uso: use_figma (skillNames "figma-use"). Edite CONFIG. Retorno ASCII.
const CONFIG = {
  pageId: '15686:2',   // POP UP 15686:2 · Card Whats 1019:238 · Banners 3850:2 · Emails Brasil 21432:2 · Email USA 21433:7490
  w: 600, h: 600,      // tamanho do formato (ex.: 1024x1024, 3200x1600, 1920x3200, 700x255)
  colunaTol: 400,      // frames com x a menos disso entre si contam como mesma coluna
  passoY: null,        // espaço sugerido abaixo do último (null = repete o último intervalo da coluna)
  nomeContem: '',      // filtro opcional no nome (ex.: 'FOOTER BR')
};
const A = s => (s || '').normalize('NFD').replace(/[^\x20-\x7E]/g, '');
const pg = await figma.getNodeByIdAsync(CONFIG.pageId); await figma.setCurrentPageAsync(pg);
const fr = pg.children.filter(n => n.type === 'FRAME' && Math.round(n.width) === CONFIG.w && Math.round(n.height) === CONFIG.h
  && (!CONFIG.nomeContem || n.name.includes(CONFIG.nomeContem)));
const cols = [];
for (const f of fr) { let c = cols.find(c => Math.abs(c.x - f.x) < CONFIG.colunaTol); if (!c) { c = { x: f.x, itens: [] }; cols.push(c); } c.itens.push(f); }
const res = cols.map(c => {
  c.itens.sort((a, b) => a.y - b.y);
  const last = c.itens[c.itens.length - 1];
  const ys = [...new Set(c.itens.map(i => Math.round(i.y)))];
  // passo = último intervalo da coluna (o mais atual), não a média
  const passo = CONFIG.passoY ?? (ys.length > 1 ? ys[ys.length - 1] - ys[ys.length - 2] : CONFIG.h + 100);
  return { x: Math.round(c.x), n: c.itens.length, ultimo: A(last.name).slice(0, 60), ultimoY: Math.round(last.y), proximo: { x: Math.round(c.x), y: Math.round(last.y + passo) } };
}).sort((a, b) => b.ultimoY - a.ultimoY);
return res.slice(0, 8); // as colunas com peça mais embaixo primeiro; confira visualmente antes de criar

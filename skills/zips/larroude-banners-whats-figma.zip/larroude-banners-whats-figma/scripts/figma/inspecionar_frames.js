// Leitura (não altera nada). Lista o conteúdo de frames: posição, tamanho, textos com estilos,
// crop das imagens e efeitos. Usar para: aprender com ajustes da pessoa responsável
// (rodar antes e depois e comparar), conferir uma referência aprovada ou depurar.
// Uso: use_figma (skillNames "figma-use"). Edite CONFIG.
const CONFIG = { pageId: 'PAGE_ID', ids: ['FRAME_ID'] };

const A = s => (s || '').normalize('NFD').replace(/[^\x20-\x7E]/g, '|');
const pg = await figma.getNodeByIdAsync(CONFIG.pageId); await figma.setCurrentPageAsync(pg);
const out = {};
for (const id of CONFIG.ids) {
  const f = await figma.getNodeByIdAsync(id); if (!f) { out[id] = 'NAO ENCONTRADO'; continue; }
  out[id] = { nome: A(f.name), pos: [Math.round(f.x), Math.round(f.y)], tam: [Math.round(f.width), Math.round(f.height)],
    filhos: (f.children || []).map(n => {
      const o = { n: A(n.name).slice(0, 30), t: n.type, x: Math.round(n.x), y: Math.round(n.y), w: Math.round(n.width), h: Math.round(n.height) };
      if (!n.visible) o.oculto = true;
      if (n.rotation) o.rot = Math.round(n.rotation);
      if (n.type === 'TEXT') {
        o.c = A(n.characters); o.al = n.textAlignHorizontal;
        o.seg = n.getStyledTextSegments(['fontName', 'fontSize', 'lineHeight', 'letterSpacing'])
          .map(s => s.fontName.family + ' ' + s.fontName.style + ' ' + Math.round(s.fontSize) + ' lh' + (s.lineHeight.value ? Math.round(s.lineHeight.value) : s.lineHeight.unit)).join(' / ');
      }
      if ('fills' in n && n.fills !== figma.mixed) {
        const im = n.fills.find(x => x.type === 'IMAGE');
        if (im) o.crop = im.imageTransform ? im.imageTransform.map(r => r.map(v => +v.toFixed(3))) : im.scaleMode;
      }
      if (n.effects && n.effects.length) o.fx = n.effects.map(e => e.type + ' r' + e.radius).join(',');
      return o;
    }) };
}
return out;

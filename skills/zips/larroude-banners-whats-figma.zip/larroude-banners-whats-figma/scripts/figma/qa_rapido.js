// QA rápido (passo 1): checagem automática de uma tarefa. Somente leitura.
// Troque PAGE_ID, FRAME_IDS, SRC (tamanho da foto de origem) e nameRe (nome esperado).
// Passo 2: 1 print por peca + checklist de references/regras-firmes.md.
const A=s=>(s||'').normalize('NFD').replace(/[^\x20-\x7E]/g,'');
const pg=await figma.getNodeByIdAsync('PAGE_ID'); await figma.setCurrentPageAsync(pg);
const ids=['FRAME_IDS']; const SRC={w:3000,h:4000}; const nameRe=/^NOME_ESPERADO$/;
const issues=[];
for (const id of ids){ const f=await figma.getNodeByIdAsync(id); const tag=A(f.name).slice(-5);
  if(!nameRe.test(f.name)) issues.push(tag+' nome fora do padrao');
  // Margens por formato (banners/whats): Slim 3200x400/1000 tem corte de 316px nas laterais; footer 700x255 usa 20px; demais 40px.
  const W=Math.round(f.width),H=Math.round(f.height);
  const slim=W===3200&&(H===400||H===1000), footer=W===700&&H===255;
  const M=slim?{x0:356,x1:W-356,y0:20,y1:H-20}:footer?{x0:20,x1:W-20,y0:15,y1:H-10}:{x0:40,x1:W-40,y0:20,y1:H-20};
  for (const n of f.children){ if(!n.visible){issues.push(tag+' camada escondida: '+A(n.name)); continue;}
    const b={x0:n.x,y0:n.y,x1:n.x+n.width,y1:n.y+n.height};
    if(n.type==='TEXT'||/LOGO|L-mark/i.test(n.name)){ if(b.x0<M.x0||b.x1>M.x1||b.y0<M.y0||b.y1>M.y1) issues.push(tag+' '+A(n.name)+' fora da margem');
      if(n.type==='TEXT') issues.push(tag+' fonte: '+n.getStyledTextSegments(['fontName','fontSize']).map(s=>s.fontName.family+' '+Math.round(s.fontSize)).join('/'));}
    if('fills' in n && n.fills!==figma.mixed){ const im=n.fills.find(x=>x.type==='IMAGE'); if(im&&im.scaleMode==='CROP'){const [[sx,,tx],[,sy,ty]]=im.imageTransform;
      if(tx+sx>1.0001||ty+sy>1.0001) issues.push(tag+' crop vaza a imagem');
      if(Math.abs((sx*SRC.w)/(sy*SRC.h)/(n.width/n.height)-1)>0.01) issues.push(tag+' imagem esticada');
      if(sx*SRC.w/n.width<1) issues.push(tag+' resolucao baixa');}}}}
return {checked:ids.length, issues};

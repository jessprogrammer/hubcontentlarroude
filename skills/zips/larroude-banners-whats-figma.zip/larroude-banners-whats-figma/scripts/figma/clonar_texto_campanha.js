// Duplica um texto pronto (ex.: "60% OFF" em Very Vogue Text + "%" em Items) para outro frame
// e redimensiona, SEM carregar a fonte. Use quando a fonte não existe no conector
// (Very Vogue Text dá "font family does not exist").
// Limite: não dá para mudar os caracteres do clone, só posição, escala e efeitos.
// Uso: use_figma (skillNames "figma-use"). Edite CONFIG. Retorno ASCII.
const CONFIG = {
  srcPageId: '3850:2',         // aba onde está o texto-fonte (ex.: Banners)
  srcFrameId: '21589:22',      // frame que contém o texto pronto
  srcMatch: '60',              // trecho que identifica o texto dentro do frame
  dstPageId: '15686:2',        // aba de destino
  dstFrameId: 'FRAME_ID',      // frame de destino
  tamanho: 117,                // tamanho de fonte desejado (px)
  centroX: null,               // centro horizontal no destino (null = centro do frame)
  y: 74,                       // y no destino
  substituirNome: null,        // nome de um TEXT a remover depois (ex.: título antigo), ou null
  copiarEfeitosDe: null,       // nome de um node do destino cujas sombras serão copiadas, ou null
};

const A = s => (s || '').normalize('NFD').replace(/[^\x20-\x7E]/g, '');
const sp = await figma.getNodeByIdAsync(CONFIG.srcPageId); await figma.setCurrentPageAsync(sp);
const srcFrame = await figma.getNodeByIdAsync(CONFIG.srcFrameId);
const src = srcFrame.findAll(n => n.type === 'TEXT' && n.characters.includes(CONFIG.srcMatch))[0];
if (!src) return 'texto-fonte nao encontrado';
const srcSize = typeof src.fontSize === 'number' ? src.fontSize : src.getStyledTextSegments(['fontSize'])[0].fontSize;
const dp = await figma.getNodeByIdAsync(CONFIG.dstPageId); await figma.setCurrentPageAsync(dp);
const dst = await figma.getNodeByIdAsync(CONFIG.dstFrameId);
const c = src.clone(); dst.appendChild(c);
c.rescale(CONFIG.tamanho / srcSize);
c.x = (CONFIG.centroX ?? dst.width / 2) - c.width / 2; c.y = CONFIG.y;
if (CONFIG.copiarEfeitosDe) { const ref = dst.findOne(n => n.name === CONFIG.copiarEfeitosDe); if (ref) c.effects = ref.effects; }
if (CONFIG.substituirNome) { const old = dst.findOne(n => n.type === 'TEXT' && n.name === CONFIG.substituirNome); if (old) old.remove(); }
return { criado: c.id, w: Math.round(c.width), h: Math.round(c.height), x: Math.round(c.x), y: Math.round(c.y), texto: A(c.characters) };

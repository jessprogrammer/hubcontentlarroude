// Troca o texto de uma camada mantendo o estilo de CADA LINHA (fonte, tamanho, entrelinha, caixa).
// Por quê: insertCharacters herda o estilo do caractere anterior e estraga textos com 2 estilos
// (ex.: "Look—1" em Plain Light 70 + nome do modelo em Platform 80). Este script guarda o estilo
// de cada linha antes, troca e reaplica. Depois confere com getStyledTextSegments.
// Nunca converter texto em vetor/contorno.
// Uso: use_figma (skillNames "figma-use"). Edite CONFIG. "linhas" = texto novo, uma string por linha.
// Se o texto novo tiver mais linhas que o original, as linhas extras usam o estilo da última linha.
const CONFIG = {
  pageId: 'PAGE_ID',
  trocas: [
    // { node: 'NODE_ID', linhas: ['Look—1', 'The Bow Mule'] },
    // { node: 'NODE_ID', linha: 1, texto: 'The Suede Pump' },   // troca só a linha 1 (0 = primeira)
  ],
};

const A = s => String(s).normalize('NFD').replace(/[^\x20-\x7E]/g, '?');
const BR = new RegExp('[\\n\\u2028]');
const PROPS = ['fontName', 'fontSize', 'lineHeight', 'letterSpacing', 'textCase', 'fills', 'textDecoration'];

function estilosPorLinha(t) {
  const chars = t.characters, linhas = chars.split(BR); let pos = 0; const est = [];
  for (const l of linhas) {
    const i = Math.min(pos, Math.max(chars.length - 1, 0)); const e = {};
    for (const p of PROPS) {
      const fn = 'getRange' + p[0].toUpperCase() + p.slice(1);
      try { e[p] = t[fn](i, i + 1); } catch (err) {}
    }
    est.push(e); pos += l.length + 1;
  }
  return { linhas, est };
}

const page = await figma.getNodeByIdAsync(CONFIG.pageId);
await figma.setCurrentPageAsync(page);
const out = {};
for (const tr of CONFIG.trocas) {
  const t = await figma.getNodeByIdAsync(tr.node);
  if (!t || t.type !== 'TEXT') { out[tr.node] = 'NAO E TEXTO'; continue; }
  if (t.hasMissingFont) { out[tr.node] = 'FONTE FALTANDO (ex.: Very Vogue) - nao editar, avisar'; continue; }
  const { linhas, est } = estilosPorLinha(t);
  const novas = tr.linhas ? tr.linhas.slice() : linhas.map((l, i) => (i === tr.linha ? tr.texto : l));
  const fontes = new Map();
  for (const e of est) if (e.fontName && e.fontName !== figma.mixed) fontes.set(JSON.stringify(e.fontName), e.fontName);
  for (const f of fontes.values()) await figma.loadFontAsync(f);
  // separador original (\n ou  ) é mantido
  const sep = (t.characters.match(BR) || ['\n'])[0];
  t.characters = novas.join(sep);
  let pos = 0;
  novas.forEach((l, i) => {
    const e = est[Math.min(i, est.length - 1)]; const a = pos, b = pos + l.length + (i < novas.length - 1 ? 1 : 0);
    if (b > a) for (const p of PROPS) {
      if (e[p] === undefined || e[p] === figma.mixed) continue;
      const fn = 'setRange' + p[0].toUpperCase() + p.slice(1);
      try { t[fn](a, b, e[p]); } catch (err) {}
    }
    pos += l.length + 1;
  });
  out[tr.node] = t.getStyledTextSegments(['fontName', 'fontSize'])
    .map(s => A(s.characters).replace(/[\n]/g, '/') + ' = ' + s.fontName.family + ' ' + s.fontName.style + ' ' + s.fontSize);
  // texto mais longo pode passar da margem do frame (40px; stories: x 65-1015)
  const fr = t.parent && t.parent.type === 'FRAME' ? t.parent : null;
  if (fr) { const lim = fr.width === 3200 && (fr.height === 400 || fr.height === 1000) ? fr.width - 356 : fr.width - 20;
    if (t.x + t.width > lim) out[tr.node].push('ATENCAO: passa da margem direita (' + Math.round(t.x + t.width) + ' > ' + lim + ')'); }
}
return out;

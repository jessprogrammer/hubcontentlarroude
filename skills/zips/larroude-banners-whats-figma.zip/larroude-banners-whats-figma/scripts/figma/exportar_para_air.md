# Exportar do Figma → Air → comentar no Asana
Só depois da aprovação da pessoa responsável. Testado em 05 e 06/10/2026 (Pop Ups Best Duo e The Hit List).

1. **Conferir os nomes dos frames** (sem `/`), com `use_figma` só leitura.
2. **Exportar cada frame no tamanho real:**
   ```
   get_screenshot { fileKey, nodeId, maxDimension: <lado maior, ex. 600>, contentsOnly: true }
   ```
   Isso devolve uma `image_url` (PNG, vale por poucos minutos).
3. **Criar as pastas no Air**, se não existirem:
   - `list_boards name="<nome>"` para achar;
   - `create_board { title, parentBoardId }` para criar.
   - Pop Up: `Site › Pop Up (39a45342…) › 2026 › <MÊS AA> › <DD.MM Campanha>`.
   - Card Whats: `Whatsapp (4562a3d8…) › 2026 › <MÊS AA> › <DD.MM Campanha>`.
   - Banners: `Site › Banners Home (5a3a3b3f…) › <DD.MM Campanha>`.
   - Footer de email: **não exporta** (o CRM exporta do Figma).
4. **Importar direto da URL do Figma**, sem baixar:
   ```
   create_import { sourceUrl: <image_url>, fileName: <nome do frame>, title: <nome do frame>, ext: "png", parentBoardId: <pasta> }
   ```
   Repita para cada frame; pode ser em paralelo.
5. **Esperar e conferir:** use `get_import_status` até "succeeded", depois `list_assets { parentBoardId, includeThumbnails: true }`. A contagem tem de bater com o número de peças.
6. **Comentar na tarefa** (`add_comment`, com `html_text` para a menção virar real):
   ```html
   <body><a data-asana-gid="1213376052489242"/> disponível aqui! <a href="LINK_DA_PASTA">LINK_DA_PASTA</a></body>
   ```
   Gids: `1213376052489242` = Luiza Amanda Moreira (Pop Up e Card Whats) · `1210732809098268` = Monique Tauane da Silva (Banners do site). O link é o `url` devolvido pelo `create_board`.
7. Atualizar `references/log-fotos.md`.

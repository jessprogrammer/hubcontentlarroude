"""Monta uma folha de contato numerada (para escolher fotos ou fazer o QA visual).

Uso:
  python folha_contato.py saida.jpg foto1.jpg foto2.jpg ... [--lado 360] [--colunas 6]
Aceita PNG transparente (fundo #F6F6F6). Cada miniatura leva o numero e o nome do arquivo.
"""
import argparse
import os
from PIL import Image, ImageDraw

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('saida')
    p.add_argument('fotos', nargs='+')
    p.add_argument('--lado', type=int, default=360)
    p.add_argument('--colunas', type=int, default=6)
    a = p.parse_args()
    L = a.lado
    C = min(a.colunas, len(a.fotos))
    R = -(-len(a.fotos) // C)
    cab = 28
    sheet = Image.new('RGB', (C * (L + 10) + 10, R * (L + cab + 10) + 10), (255, 255, 255))
    d = ImageDraw.Draw(sheet)
    for i, f in enumerate(a.fotos):
        im = Image.open(f)
        if im.mode in ('RGBA', 'LA', 'P'):
            im = im.convert('RGBA')
            fundo = Image.new('RGBA', im.size, (246, 246, 246, 255))
            im = Image.alpha_composite(fundo, im)
        im = im.convert('RGB')
        im.thumbnail((L, L))
        x = 10 + (i % C) * (L + 10)
        y = 10 + (i // C) * (L + cab + 10)
        sheet.paste(im, (x + (L - im.width) // 2, y + cab + (L - im.height) // 2))
        d.text((x, y + 6), f'{i + 1}. {os.path.basename(f)[:40]}', fill=(0, 0, 0))
    sheet.save(a.saida, quality=85)
    print(a.saida, sheet.size)

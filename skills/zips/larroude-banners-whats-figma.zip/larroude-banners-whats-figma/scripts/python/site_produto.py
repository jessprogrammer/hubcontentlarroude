"""Le um produto do larroude.com: titulo, SKUs, disponibilidade e URLs das fotos.

Uso:
  python site_produto.py <link ou handle> [--baixar PASTA] [--largura 2000]
  python site_produto.py --colecao <handle-da-colecao>     (lista os produtos da colecao, ON/OFF)
Usar quando o briefing traz o produto pelo nome/link e nao pelo SKU (regra: ler o SKU no site).
"""
import argparse
import json
import os
import re
import sys
import urllib.request

sys.stdout.reconfigure(encoding='utf-8')
BASE = 'https://www.larroude.com'


def get(url):
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    return json.loads(urllib.request.urlopen(req, timeout=30).read())


def handle_de(s):
    m = re.search(r'/products/([^/?#]+)', s)
    return m.group(1) if m else s.strip('/')


def disponivel(pr):
    vs = pr['variants']
    if any('available' in v for v in vs):
        return 'ON' if any(v.get('available') for v in vs) else 'OFF'
    return '?'


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('produto', nargs='?')
    p.add_argument('--colecao')
    p.add_argument('--baixar')
    p.add_argument('--largura', type=int, default=2000)
    a = p.parse_args()
    if a.colecao:
        prods = get(f'{BASE}/collections/{a.colecao}/products.json?limit=250')['products']
        for pr in prods:
            sku = re.sub(r'-\d+(\.\d)?-', '-', pr['variants'][0].get('sku') or '', count=1)
            print(disponivel(pr), pr['handle'], '|', sku)
        raise SystemExit
    pr = get(f'{BASE}/products/{handle_de(a.produto)}.json')['product']
    skus = sorted({v.get('sku') for v in pr['variants'] if v.get('sku')})
    # SKU do modelo (sem o tamanho): L517-INNA-10.0-BLAC-0036 -> L517-INNA-BLAC-0036 (formato usado no Air e nos nomes de ADS)
    modelo = sorted({re.sub(r'-\d+(\.\d)?-', '-', s, count=1) for s in skus})
    print('Titulo:', pr['title'])
    print('SKU do modelo:', ', '.join(modelo))
    print('SKUs por tamanho:', len(skus))
    print('Disponivel:', disponivel(pr), '(o .json de produto unico nem sempre traz estoque; confirme no site se for "?")')
    for i, im in enumerate(pr['images'], 1):
        print(f'foto {i}: {im["width"]}x{im["height"]} {im["src"]}')
        if a.baixar:
            os.makedirs(a.baixar, exist_ok=True)
            url = im['src'] + ('&' if '?' in im['src'] else '?') + f'width={a.largura}'
            dst = os.path.join(a.baixar, f'{pr["handle"][:40]}_{i}.jpg')
            urllib.request.urlretrieve(url, dst)

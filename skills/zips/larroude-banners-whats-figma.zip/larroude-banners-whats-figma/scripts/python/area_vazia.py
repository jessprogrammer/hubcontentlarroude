# area_vazia.py · acha a área vazia (fundo) de uma foto no recorte do formato, para pôr o texto SOBRE a foto
# Uso: python area_vazia.py foto.jpg 1080 1920 [larguraBloco alturaBloco]
# Saída: as 3 melhores posições (x, y) do bloco dentro da zona segura, com nº de pixels ocupados (0 = vazio).
import sys, numpy as np
from PIL import Image
src, FW, FH = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
BW, BH = (int(sys.argv[4]), int(sys.argv[5])) if len(sys.argv) > 5 else (440, 300)
im = Image.open(src).convert('RGB'); W, H = im.size
if W / H > FW / FH: cw = int(H * FW / FH); im = im.crop(((W - cw) // 2, 0, (W - cw) // 2 + cw, H))
else: ch = int(W * FH / FW); im = im.crop((0, (H - ch) // 2, W, (H - ch) // 2 + ch))
a = np.asarray(im.resize((FW, FH))).astype(int)
occ = ((a.max(2) - a.min(2)) > 22) | (a.mean(2) < 205)
ii = occ.cumsum(0).cumsum(1)
def s(x, y, w, h): return ii[y+h-1, x+w-1] - (ii[y-1, x+w-1] if y else 0) - (ii[y+h-1, x-1] if x else 0) + (ii[y-1, x-1] if x and y else 0)
y0, y1 = (280, 1500) if FH == 1920 else (40, FH - 40)
best = sorted((s(x, y, BW, BH), x, y) for y in range(y0, y1 - BH, 20) for x in range(60, FW - 60 - BW, 20))
print(best[:3])

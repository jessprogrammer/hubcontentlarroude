"""Calcula o imageTransform (CROP) do Figma para encaixar uma foto numa celula sem esticar.

Uso:
  python crop_celula.py LARG_IMG ALT_IMG LARG_CEL ALT_CEL [--zoom 1.0] [--cx 0.5] [--cy 0.5]
                        [--preview foto.jpg saida.jpg]

--zoom 1.0 = maior recorte possivel; 1.2 = 20% mais perto (padrao da casa: zoom leve 5-20%)
--cx/--cy  centro do assunto na foto (0-1). Ex.: calcado no terco de baixo -> --cy 0.7
Saida: JSON com imageTransform [[sx,0,tx],[0,sy,ty]] e resolucao (px de origem por px de saida; >= 1 ok).
Formula: sy = sx*W*ch/(H*cw), mantendo tx+sx <= 1 e ty+sy <= 1.
"""
import argparse
import json


def crop(W, H, cw, ch, zoom=1.0, cx=0.5, cy=0.5):
    sx = 1.0
    sy = sx * W * ch / (H * cw)
    if sy > 1:
        sy = 1.0
        sx = sy * H * cw / (W * ch)
    sx /= zoom
    sy /= zoom
    tx = min(max(cx - sx / 2, 0), 1 - sx)
    ty = min(max(cy - sy / 2, 0), 1 - sy)
    res = (sx * W) / cw
    return [[round(sx, 5), 0, round(tx, 5)], [0, round(sy, 5), round(ty, 5)]], res


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    for k in ['W', 'H', 'cw', 'ch']:
        p.add_argument(k, type=float)
    p.add_argument('--zoom', type=float, default=1.0)
    p.add_argument('--cx', type=float, default=0.5)
    p.add_argument('--cy', type=float, default=0.5)
    p.add_argument('--preview', nargs=2, metavar=('FOTO', 'SAIDA'))
    a = p.parse_args()
    t, res = crop(a.W, a.H, a.cw, a.ch, a.zoom, a.cx, a.cy)
    print(json.dumps({'imageTransform': t, 'resolucao': round(res, 2), 'ok': res >= 1}))
    if a.preview:
        from PIL import Image
        im = Image.open(a.preview[0])
        W, H = im.size
        (sx, _, tx), (_, sy, ty) = t
        box = (int(tx * W), int(ty * H), int((tx + sx) * W), int((ty + sy) * H))
        im.crop(box).resize((int(a.cw // 2), int(a.ch // 2))).save(a.preview[1])

"""Recorta o calcado do fundo (packshot de site/estudio, fundo liso) e salva PNG transparente.

Uso:
  python recorte_calcado.py entrada.jpg saida.png [--thresh 18] [--contorno 0] [--pad 20]

--thresh   tolerancia do fundo (18 padrao; use 6 para calcado branco/claro em fundo claro)
--contorno espessura do contorno branco tipo adesivo, em px (0 = sem; Dressing Guide usa 23)
--pad      margem em volta do recorte
So funciona bem em fundo liso. Foto de cena/modelo: nao usar (pedir recorte manual ou ferramenta de IA).
"""
import argparse
from PIL import Image, ImageDraw, ImageFilter
import numpy as np


def recortar(im, thresh=18, contorno=0, pad=20):
    im = im.convert('RGB')
    w, h = im.size
    mark = im.copy()
    seeds = [(0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1),
             (w // 2, 0), (w // 2, h - 1), (0, h // 2), (w - 1, h // 2)]
    for s in seeds:
        ImageDraw.floodfill(mark, s, (255, 0, 255), thresh=thresh)
    a = np.array(mark)
    bg = (a[:, :, 0] == 255) & (a[:, :, 1] == 0) & (a[:, :, 2] == 255)
    m = Image.fromarray(np.where(bg, 0, 255).astype('uint8'))
    # fecha furinhos e pontos soltos, depois suaviza a borda
    m = (m.filter(ImageFilter.MaxFilter(5)).filter(ImageFilter.MinFilter(5))
          .filter(ImageFilter.MedianFilter(7)).filter(ImageFilter.GaussianBlur(0.8)))
    bb = m.getbbox()
    if not bb:
        raise SystemExit('Nada encontrado: fundo nao e liso ou thresh alto demais')
    cobertura = (np.array(m) > 128).mean()
    pad = max(pad, contorno * 2)
    rgba = im.copy()
    rgba.putalpha(m)
    rgba = rgba.crop((max(0, bb[0] - pad), max(0, bb[1] - pad),
                      min(w, bb[2] + pad), min(h, bb[3] + pad)))
    if contorno:
        k = contorno if contorno % 2 else contorno + 1
        al = rgba.split()[3]
        borda = (al.point(lambda v: 255 if v > 40 else 0)
                   .filter(ImageFilter.MaxFilter(k)).filter(ImageFilter.GaussianBlur(1.2)))
        branco = Image.new('RGBA', rgba.size, (255, 255, 255, 0))
        branco.putalpha(borda)
        rgba = Image.alpha_composite(branco, rgba)
    return rgba, cobertura


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('entrada')
    p.add_argument('saida')
    p.add_argument('--thresh', type=int, default=18)
    p.add_argument('--contorno', type=int, default=0)
    p.add_argument('--pad', type=int, default=20)
    a = p.parse_args()
    r, cob = recortar(Image.open(a.entrada), a.thresh, a.contorno, a.pad)
    r.save(a.saida)
    aviso = '  ATENCAO: recorte pegou quase tudo (fundo nao liso?)' if cob > 0.85 else ''
    print(f'{a.saida} {r.size[0]}x{r.size[1]} cobertura={cob:.2f}{aviso}')

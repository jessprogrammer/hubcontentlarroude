"""Baixa uma foto do Air pelo id de VERSAO (coverVersion.id, ou o id do link /c/<id>) via imgix.

Uso:
  python air_baixar.py <versionId> saida.jpg [--largura 2400]
--largura 0 = tamanho original. Arquivos GROUP/estudio chegam a 5464x8192: monte com 2400 e,
se precisar, troque pelo original na versao final.
Pasta de trabalho: caminho curto (ex.: C:/Users/<voce>/airtmp); caminhos longos quebram no Windows.
Para o arquivo original exato: get_asset_download_url do conector Air + curl.
"""
import argparse
import urllib.error
import urllib.request
from PIL import Image

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('versao')
    p.add_argument('saida')
    p.add_argument('--largura', type=int, default=2400)
    a = p.parse_args()
    url = f'https://air-prod.imgix.net/{a.versao}.jpg?fm=jpg&q=90' + (f'&w={a.largura}' if a.largura else '')
    try:
        urllib.request.urlretrieve(url, a.saida)
    except urllib.error.HTTPError as e:
        raise SystemExit(f'Erro {e.code}: confira se e o id de VERSAO (coverVersion.id), nao o id do asset')
    print(a.saida, Image.open(a.saida).size)

﻿"""Lê o doc de copy (Google Slides exportado em PDF) e separa páginas e imagens.

Uso:
  1. No conector do Google Drive: download_file_content(fileId, exportMimeType="application/pdf").
     O resultado é grande e fica salvo num .txt (JSON com o campo "content" em base64).
     Copie esse .txt para uma pasta de caminho curto (ex.: C:/Users/<voce>/airtmp/doc.json).
  2. python doc_imagens.py doc.json saida/
     - saida/pagina_N.png: cada página renderizada (para ver o modelo de email, o header e os blocos)
     - saida/pN_img_K.jpg|png: cada imagem embutida, na resolução em que está no doc
     - imprime o tamanho de cada imagem e uma folha de contato saida/_paginas.png

Precisa de: pip install pymupdf pillow
"""
import base64, json, os, sys
import pymupdf
from PIL import Image

src, out = sys.argv[1], sys.argv[2]
os.makedirs(out, exist_ok=True)
raw = open(src, 'rb').read()
if raw[:4] != b'%PDF':
    raw = base64.b64decode(json.loads(raw)['content'])
pdf = os.path.join(out, 'doc.pdf'); open(pdf, 'wb').write(raw)
doc = pymupdf.open(pdf)
pages = []
for i, p in enumerate(doc, 1):
    f = os.path.join(out, f'pagina_{i}.png'); p.get_pixmap(dpi=110).save(f); pages.append(f)
    for k, info in enumerate(p.get_images(full=True), 1):
        im = doc.extract_image(info[0])
        name = os.path.join(out, f'p{i}_img_{k}.{im["ext"]}')
        open(name, 'wb').write(im['image'])
        print(f'pagina {i} - imagem {k}: {im["width"]}x{im["height"]} -> {os.path.basename(name)}')
ims = [Image.open(f) for f in pages]
w, h = ims[0].size
sheet = Image.new('RGB', (w * 2, h * ((len(ims) + 1) // 2)), 'white')
for i, im in enumerate(ims):
    sheet.paste(im, ((i % 2) * w, (i // 2) * h))
sheet.save(os.path.join(out, '_paginas.png'))
print(f'{len(ims)} paginas -> _paginas.png')


---
name: larroude-banners-whats-figma
description: Create, adapt, QA and deliver Larroudé site banners (Hero, Middle, Slim/Collection Slider, Grid/Categoria), email footers, website pop-ups and WhatsApp cards in the Figma file "FIGMA ZAINERS NOVO", using real photos from Air or larroude.com, then export to Air and notify on Asana. Use whenever an Asana task like "POPUP_BR …", "WPP_BR …", "[FOOTER BR] …", "[BANNER Hero + Collection_Slider] …", "Herobanner_…", or any request for Larroudé site banners, pop-ups, footers or WhatsApp cards appears.
---

# Larroudé · Banners, Pop Ups, Footers e Cards de WhatsApp no Figma

Arquivo Figma: `DRphNBA9HvgZ6HwazNMHrm` ("FIGMA ZAINERS NOVO").

| Aba | ID | O que tem |
|---|---|---|
| **Card Whats** | `1019:238` | Cards de WhatsApp BR (1024×1024) |
| **POP UP** | `15686:2` | Pop ups do site (600×600) |
| **Banners** | `3850:2` | Hero, Middle, Slim, Collection Slider e Grid do site |
| **Emails Brasil** | `21432:2` | Footers BR (700×255), no bloco "Banners Footer" |
| **Email USA** | `21433:7490` | Footers US (700×255), no bloco "Banners Footer" |

Papéis:
- **quem solicitou:** abriu a tarefa no Asana (CRM, copy ou site).
- **pessoa responsável:** o designer que revisa e faz o ajuste fino.

## 0. Antes de tudo (todo início de tarefa)
1. **Permissões.** O fluxo faz ações externas: exportar do Figma, subir no Air e comentar no Asana. Na primeira vez que cada uma aparecer, peça à pessoa que **libere a permissão** ou autorize no chat.
2. **Regras firmes.** Leia `references/regras-firmes.md`. Elas sempre valem. Rode o checklist antes de montar e de novo no QA.
3. **Padrões por formato.** Leia `references/formatos-e-padroes.md` na seção do formato da tarefa.

## 1. Fluxo de uma tarefa (1 montagem, 1 correção)

> **Orçamento de tempo:** o objetivo é um **rascunho forte e rápido**. A pessoa responsável sempre faz o ajuste fino.
> - No máximo **1 montagem + 1 correção**. Depois disso, entregue e liste o que ficou pendente.
> - **1 print por peça**, só na hora de mostrar. Não fique tirando print a cada passo.
> - **Extensão ou expansão de imagem (outpaint): sempre perguntar antes.** Prefira recorte mais fechado ou outra foto.
> - Pergunte antes só o que muda a estrutura (formato, qual foto, conceito). O resto, decida e siga.

1. **Ler a tarefa no Asana.** O nome da peça é o nome da tarefa (busque com `search_tasks`).
   - **O texto da arte vem sempre da seção COPY.** Se a linha "DISCLAIMER:" separada divergir do disclaimer da COPY, vale o da COPY.
   - Use as palavras exatas da COPY; só as quebras de linha podem mudar.
   - **O CTA do pop up não entra na arte** (fica no Klaviyo). Em footers e banners, ele entra.
   - Leia também: DIRECIONAMENTO (o que a peça precisa comunicar), PRODUCTS, formatos pedidos, anexos e comentários.
   - **Planilha anexada** (ex.: lista final da ação): leia com Python. Os produtos das fotos **precisam estar na lista** da ação.
   - **Doc nos comentários** (Slides ou PDF): leia como imagem com `scripts/python/doc_imagens.py`, porque pode trazer modelo e fotos.
   - **"precisa de copy"** sem texto pronto: proponha um conceito curto de campanha e mostre antes de montar todas as peças.
   - **`XXX_` no nome pedido** = **ID da coleção do Shopify** da ação (ex.: `535822696762_BANNER_HERO1_DESKTOP`). Pergunte se não estiver na tarefa.
2. **Escolher a base.**
   - **Regra do canvas:** o padrão vigente é sempre **o que está mais embaixo da coluna** do formato.
   - Use como base a **última peça aprovada ou entregue** do mesmo tipo, nunca um rascunho sem aprovação.
   - Se a pessoa responsável ajustou uma peça da mesma campanha, **duplique o frame dela e troque só a foto** (e o texto, se mudar).
3. **Onde criar:** ver `references/mapa-figma-air.md` §1 e `scripts/figma/proximo_espaco_banners.js`.
4. **Fotos, escolhidas pela beleza.**
   - Fontes, nesta ordem: fotos do doc → Air (SKU/modelo; pastas de produto e conteúdo) → site.
   - **Nunca** usar peça final de ads (com texto, borda ou logo) como foto.
   - Monte a folha de contato (`folha_contato.py`) e confira `references/log-fotos.md`.
   - **Dentro da mesma tarefa, nenhuma foto se repete.** Entre canais da mesma campanha, repetir é aceitável (ex.: a foto do hero no card de WhatsApp).
   - Texto branco pede **área escura ou calma** da foto. **O texto vai onde a foto deixa espaço:** esquerda, direita ou centro; não existe posição fixa.
   - **Enquadramento:**
     - foto grande e única (pop up, card): zoom fechado no produto;
     - faixa estreita (footer com 3 produtos, grade): zoom aberto, o par inteiro aparecendo.
5. **Montar com o mínimo de chamadas**, partindo dos scripts de `scripts/`:
   - artboard → upload da foto (`enviar_imagem.md`) → CROP (`aplicar_crop.js`) → textos (`trocar_texto.js`).
   - Fonte **Very Vogue Text** não carrega no conector: use `clonar_texto_campanha.js`, que duplica e redimensiona um texto pronto.
6. **Cor:**
   - **preto** só quando o texto está sobre branco ou cor clara, sem dividir espaço com mais nada;
   - foto escura ou contrastada → **branco**;
   - campanha com cor (ex.: The Hit List) → painel vermelho `#B41724` com **todo** o texto em butter `#FEE88E`, inclusive o disclaimer.
   - Wordmark: acento **sempre rosa** (#F44C7F).
7. **QA, 1 rodada:** `qa_rapido.js` + checklist + 1 print por peça. Mostre a **conferência linha a linha entre o texto da arte e a COPY**. Corrija só o que falhar e entregue para revisão.
8. **Aprender com o ajuste.** Quando a pessoa responsável disser que ajustou, **não edite**.
   - Leia com `inspecionar_frames.js`.
   - Compare em tabela: onde / eu fiz / você fez / lição.
   - Registre as lições em `references/aprendizados.md`.
9. **Entregar** (só depois da aprovação) → §3.

## 2. Formatos e nomes (resumo; detalhes em `formatos-e-padroes.md`)
| Peça | Tamanho | Nome |
|---|---|---|
| Card Whats | 1024×1024 | `WPP_BR DD-MM - Tema` |
| Pop Up | **600×600** (mesmo se a tarefa disser 550) | `POPUP_BR DD-MM - Tema - Produto` |
| Hero | DESK 3200×1600 · MOB 1920×3200 | `<ID coleção>_BANNER_HERO1_DESKTOP` / `_MOBILE` ou `Herobanner_<CAMP>_DD-MM_DESK_BR` |
| Middle | DESK 3200×1200 · MOB 1920×2560 | `<ID>_BANNER_MIDDLE_1_DESKTOP` / `DD.MM_Middle_DESK_BR` |
| Slim / Collection Slider | DESK 3200×400 · MOB 3200×1000 | `<ID>_BANNER_COLLECTION_SLIDER_DESK` / `_MOBILE` |
| Grid / Categoria | 1600×1600 (grid) · 1080×1080 (categoria) | `<SKU>_BANNER_GRID` / `Categories_1080x1080_<Cat>` |
| Footer de email | 700×255 | `[FOOTER BR] DD a DD-MM - Tema` |

- **Nunca use `/` no nome do frame**, porque quebra a exportação. Troque por `-`.
- **Padrão por peça:** 2 peças, um produto em cada, salvo pedido diferente. No card de WhatsApp vale entregar **2 ideias de hierarquia** lado a lado (oferta em destaque × urgência em destaque) para quem solicitou escolher.

## 3. Entrega (Air + Asana)
Só depois da aprovação da pessoa responsável. Ver `scripts/figma/exportar_para_air.md`. Footer de email é exceção (passo 2).
1. Exporte cada frame em PNG no tamanho real (`get_screenshot`, `contentsOnly: true`, `maxDimension` = lado maior).
2. Crie as pastas no Air e importe (`create_import` com a URL do Figma). **Todos os arquivos juntos, sem subpastas STATIC/01.** A data da pasta é **DD.MM**.
   - **Pop Up:** `Graphic Design › Site › Pop Up › 2026 › <MÊS AA> › <DD.MM Campanha>` (ex.: `OCT 26 › 06.10 The Hit List`).
   - **Card Whats:** `Graphic Design › Whatsapp › 2026 › <MÊS AA> › <DD.MM Campanha>`.
   - **Banners do site:** `Graphic Design › Site › Banners Home › <DD.MM Campanha>`, sem ano nem mês (ex.: `05.10 60Off The Hit List`). Quase todos vão aqui. Landing page vai em `Site › LP`.
   - **Footer de email: não vai para o Air.** Deixe pronto no Figma, na coluna do mês, e avise a pessoa responsável. Ela marca a revisora no Figma (o conector não comenta no Figma), e o CRM exporta depois.
3. Confira a contagem na pasta.
4. Comente na tarefa com **menção real**:
   - **Pop Up e Card Whats:** `@Luiza Amanda Moreira disponível aqui!` + link da pasta (gid `1213376052489242`). Só isso, sem outro texto.
   - **Banners do site:** `@Monique Tauane da Silva disponível aqui!` + link da pasta (gid `1210732809098268`).
5. Registre as fotos usadas em `references/log-fotos.md`.

## 4. Decidir, perguntar ou sinalizar
- **Decida:** crop, quebra de linha, posição dentro do padrão, cor pela regra.
- **Pergunte uma vez, no início:** conceito quando falta copy, ID da coleção, formato fora do padrão, pasta de entrega nova.
- **Sinalize na entrega:**
  - diferença entre a COPY e a arte (a caixa do lockup da campanha, como "60% OFF", não precisa ser sinalizada);
  - produto fora da lista da ação ou do site;
  - foto repetida.
- **Nunca:**
  - imagem gerada por IA no lugar de foto real;
  - texto convertido em vetor;
  - apagar ou mover trabalho de outra pessoa sem pedido;
  - comentar no Asana antes da aprovação.

## 5. Referências e scripts
- `references/regras-firmes.md`: checklist que sempre vale.
- `references/formatos-e-padroes.md`: medidas, fontes e arquétipos de cada formato.
- `references/mapa-figma-air.md`: onde fica cada coisa no Figma e no Air, e como achar espaço.
- `references/aprendizados.md`: ajustes da pessoa responsável e o que ensinam.
- `references/campanhas.md`: campanhas fechadas como referência (Best Duo, The Hit List).
- `references/log-fotos.md`: fotos já usadas.
- `references/pendencias.md`: decisões em aberto.
- `scripts/README.md`: scripts testados (Figma e Python).

## Como pedir (para quem usa)
```
Tarefa: POPUP_BR 06 a 11/10 - The Hit List   (nome exato do Asana)
Peças: [n] · Produtos: [da tarefa ou "livre"] · Fotos: [pasta do Air, link ou "livre"]
Onde: [se quiser outro lugar no canvas]
```

# Skill · Larroudé · Banners, Pop Ups, Footers e Cards de WhatsApp no Figma

## Instalar
- **claude.ai:** Settings → Capabilities → Skills → Upload skill → selecione `larroude-banners-whats-figma.zip` → ative.
- **Claude Code:** descompacte em `C:\Users\<seu-usuário>\.claude\skills\larroude-banners-whats-figma\`.

## Pré-requisitos
- **Conector Figma**, com acesso de edição ao arquivo "FIGMA ZAINERS NOVO" (abas Card Whats, POP UP, Banners, Emails Brasil e Email USA).
- **Conector Air**, no workspace da Larroudé.
- **Conector Asana**, para ler a tarefa e comentar a entrega.
- **Python** com Pillow e numpy (e pymupdf, para ler docs de copy).
- **Fontes:**
  - Platform, Plain, Graphik e Items, instaladas.
  - **Very Vogue Text** não carrega no conector. O Claude copia o texto pronto de outra artboard e redimensiona (`clonar_texto_campanha.js`).

## Permissões (importante)
O fluxo faz ações fora do computador:
- exportar imagens do Figma;
- subir arquivos no Air (criar pastas e importar);
- comentar no Asana mencionando uma pessoa.

Na primeira vez que cada ação aparecer, **libere quando o Claude pedir**, ou autorize no chat ("autorizo exportar do Figma, subir no Air e comentar no Asana"). Sem isso a entrega para no meio.

## Como usar
Mande o nome exato da tarefa do Asana (ex.: `POPUP_BR 06 a 11/10 - The Hit List`). O Claude:
1. lê a tarefa (a COPY é a fonte do texto) e os anexos;
2. escolhe a base: a peça aprovada mais recente do formato, a que fica mais embaixo da coluna;
3. busca as fotos no Air e confere se os produtos estão na ação;
4. monta, faz 1 rodada de QA e mostra a conferência entre o texto da arte e a COPY.

Você faz o ajuste fino e ele lê o que você mudou para aprender. Depois da aprovação, ele sobe no Air e comenta na tarefa.

**Versão:** 06/10/2026. As decisões em aberto estão em `references/pendencias.md`.

Figma MCP cannot drive the Air Figma plugin; Claude-in-Chrome tools are not available in the desktop Code session. Working bridge:
1. In-app Browser pane → app.air.inc (Pietro logs in himself via Google; never type credentials). Workspace "Larroude", board **DROPS** (147 boards by model).
2. Search box ("Search DROPS") by SKU, e.g. L300-RICK-BLAC-0742 → assets; read `img` src ids via JS: `https://air-prod.imgix.net/<uuid>.jpg?...`.
3. imgix URLs are public: `curl https://air-prod.imgix.net/<uuid>.jpg?w=2400&fm=jpg&q=88` into a SHORT path (C:/Users/Pietro.Boeira/airtmp — long scratchpad path breaks Windows curl).
4. Create target rectangles in a staging frame on ADS BR ("AIR IMPORTS – Botas (DROPS)" 20866:2), call Figma `upload_assets` with nodeIds, POST multipart `file=@x.jpg` to each submitUrl → returns imageHash.
5. Use hashes in artboards with CROP transforms. PIL is available locally for bbox/bg sampling and free-zone search.
Better permanent option: Air official MCP connector `https://mcp.air.inc/mcp` (Settings → Connectors → Add custom connector) — suggested to Pietro, not yet added.

**Air structure notes (2026-09-25):** FALL BY YEAR → FALL 21…26 (FALL 25 = NYC editorial on-model shoot, ~118 assets, great for TOF editorial; FALL 26 only has a "backdrop" board so far). Search for "shearling" found nothing. Air session in the in-app browser expires — ask Pietro to re-login. Claude-in-Chrome tools may appear but the extension can be unreachable.
**ADS US placement:** Pietro drops a date marker text (e.g. "25.09 - ", fontSize 500) where new artboards go; US column convention stacks 01/02/03 vertically (~97px gap) under it.
**Air workspace-wide search by SKU (2026-09-28):** navigate `https://app.air.inc/all?q=<SKU>` (one navigate per SKU — pushState doesn't re-render), then read img ids + card text; filter out finished ads (_STATIC/_GIF/_CAROUSEL/_VIDEO/_US/_BR) to get raw shoot photos (named SKU, SKU (1), SKU (2)…). Results for L384-ALEX-DARK-1492 were noise (fuzzy match) — fall back to file images.
**Carousel naming:** Pietro pre-creates …_01_A / _02_A; I fill A and add B…G to the right (step W+95), one SKU per card in briefing order.

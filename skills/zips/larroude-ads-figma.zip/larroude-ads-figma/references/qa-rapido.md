# QA rápido (padrão da skill)

Objetivo: revisar em ~1 minuto, sem agente. O revisor completo só roda quando alguém pede ou em segundo plano, sem travar a entrega.

## Passo 1 · Checagem automática (1 chamada use_figma)
Rodar o script abaixo nos frames da tarefa (trocar `ids`, `SRC` e `nameRe`). Ele lista:
- texto/logo fora da margem (1080×1920: x 65–1015, y 269–1536; outros formatos: 40px de respiro);
- camadas escondidas;
- crop que vaza a imagem ou imagem esticada;
- resolução abaixo de 1× (px de origem por px de saída);
- fontes e tamanhos de cada texto (para comparar entre formatos);
- nome do frame fora do padrão.

```js
const A=s=>(s||'').normalize('NFD').replace(/[^\x20-\x7E]/g,'');
const pg=await figma.getNodeByIdAsync('PAGE_ID'); await figma.setCurrentPageAsync(pg);
const ids=['FRAME_IDS']; const SRC={w:3000,h:4000}; const nameRe=/^NOME_ESPERADO$/;
const issues=[];
for (const id of ids){ const f=await figma.getNodeByIdAsync(id); const tag=A(f.name).slice(-5);
  if(!nameRe.test(f.name)) issues.push(tag+' nome fora do padrao');
  const story=f.width===1080&&f.height===1920; const M=story?{x0:65,x1:1015,y0:269,y1:1536}:{x0:40,x1:f.width-40,y0:40,y1:f.height-40};
  for (const n of f.children){ if(!n.visible){issues.push(tag+' camada escondida: '+A(n.name)); continue;}
    const b={x0:n.x,y0:n.y,x1:n.x+n.width,y1:n.y+n.height};
    if(n.type==='TEXT'||/LOGO|L-mark/i.test(n.name)){ if(b.x0<M.x0||b.x1>M.x1||b.y0<M.y0||b.y1>M.y1) issues.push(tag+' '+A(n.name)+' fora da margem');
      if(n.type==='TEXT') issues.push(tag+' fonte: '+n.getStyledTextSegments(['fontName','fontSize']).map(s=>s.fontName.family+' '+Math.round(s.fontSize)).join('/'));}
    if('fills' in n && n.fills!==figma.mixed){ const im=n.fills.find(x=>x.type==='IMAGE'); if(im&&im.scaleMode==='CROP'){const [[sx,,tx],[,sy,ty]]=im.imageTransform;
      if(tx+sx>1.0001||ty+sy>1.0001) issues.push(tag+' crop vaza a imagem');
      if(Math.abs((sx*SRC.w)/(sy*SRC.h)/(n.width/n.height)-1)>0.01) issues.push(tag+' imagem esticada');
      if(sx*SRC.w/n.width<1) issues.push(tag+' resolucao baixa');}}}}
return {checked:ids.length, issues};
```

## Passo 2 · Uma folha de contato
Um screenshot por frame em ~420px, juntos numa imagem só. Olhar 4 coisas:
1. o produto está inteiro (bico e salto) e não está coberto por texto ou logo;
2. o texto e o logo estão sobre um fundo calmo, sem rosto nem área clara atrás de texto branco;
3. a mesma peça é consistente entre os formatos (tamanho da copy, alinhamento);
4. o espaçamento é parecido entre as artboards (o produto na mesma escala e com a mesma base).

## Passo 3 · Entregar
Entregar com as sinalizações. A pessoa responsável revisa e ajusta; o Claude compara o antes e o depois.

## Revisor completo (só quando pedido)
Usar um agente com modelo rápido, limite de ~10 chamadas e saída só com os erros (até 15 linhas). Rodar em segundo plano.

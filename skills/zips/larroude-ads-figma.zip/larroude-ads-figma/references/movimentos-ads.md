# Cardápio de movimentos de layout (ADS)

Versão visual: Figma, aba "Claude Referências", frame "03 Banco de referências ADS · ativo" (21679:3).
Lista de marcas: `refs/README.md` (lista oficial da Marina, 06/10/2026).

## Como usar (sem pesquisar marcas a cada ad)
1. Antes de diagramar, escolha **1 ou 2 movimentos** por peça, de acordo com a foto e o formato.
2. Na mesma entrega, **cada peça usa um movimento diferente**. Dentro de uma peça, os 3 formatos (9:16, 1:1, 1200×628) seguem a mesma lógica, adaptada ao formato.
3. Na entrega, cite os números (ex.: "Verona: P1 + P2").
4. A pesquisa de marcas é **mensal**: traz só o que vira movimento novo neste cardápio. Não é feita a cada ad.

## P · ajustes do Pietro em ads aprovados (06/10, Shearling + NewDrops)
| Nº | Movimento | Como fazer | Quando usar | Evitar |
|---|---|---|---|---|
| P1 | Lockup no canto vazio | Copy e logo juntos, alinhados à direita, na área calma da foto; logo logo abaixo da copy | Foto com um lado livre | Copy e logo em cantos opostos sem motivo |
| P2 | Itálico de ênfase | Platform Regular + palavra-chave em Platform Italic ~10% maior (64 → 71) | Copy de contraste ou lista curta | Mais de uma ênfase por linha |
| P3 | Palavra em script | Plain Light branca + palavra do material em Blitz Script ~1,75× maior, na linha do meio; degradê marrom em multiply na diagonal para leitura | Close quente, foto escura/textura | Script em mais de uma palavra; sobre fundo claro |
| P4 | Assinatura central | Copy curta no alto, produto no meio, logo centralizado na base (9:16 y 1650; 1:1 y 1050) | Produto único, fundo limpo | Usar em todas as peças da entrega |
| P5 | Faixa de detalhe + produto inteiro | Topo: close de outra foto da mesma sessão (~27% da altura). Embaixo: produto inteiro em branco, copy centralizada | Packshot branco que precisa de textura | Fotos de sessões diferentes; listra branca |
| P6 | Split no horizontal | 1200×628 em duas metades: produto + copy + logo à esquerda; close de detalhe à direita (x 643–1200) | Horizontal com produto vertical | Mais de 2 fotos |
| P7 | Foto girada no horizontal | Foto vista de cima girada 90° para encher o 1200×628 | Só flat lay / vista de cima | Foto com chão, sombra ou pessoa |
| P8 | Degradê de respiro | Retângulo degradê na cor do fundo (#F0F0F0 → transparente) no topo, para o texto | Foto boa sem espaço para copy | Cor diferente do fundo; parecer faixa |
| P9 | Texto sobre o produto com halo | Copy branca centralizada sobre o produto, sombra difusa (raio ~40, preto 40%, sem offset) | Produto escuro/estampado no quadro todo | Sombra dura ou deslocada |
| P10 | Cena antes de packshot | Procurar primeiro still com cena real (fita, travesseiro, tecido listrado, sol no piso) | Sempre que existir no Air | Partir do packshot em branco quando há cena |
| P11 | Hierarquia invertida + recorte fechado | A resposta/punchline grande, a pergunta pequena em cima e a etiqueta embaixo, em bloco centralizado sobre o produto com sombra; foto girada e cortada bem fechada (sem fundo estendido); L-mark pequeno no centro da base | Copy em pergunta + resposta; foto de grupo colorida | Estender fundo quando um recorte fechado resolve |

## R · referências de marca (coleta de 30/09)
| Nº | Movimento | Grupo | Origem |
|---|---|---|---|
| R1 | Tom sobre tom (produto e fundo da mesma família de cor) | CORE | Sézane 10, 12 |
| R2 | Macro de material como apoio (combina com P5) | CORE | Khaite 04 |
| R3 | Itálico e regular na mesma frase (combina com P2) | CORE | Net-a-Porter PORTER |
| R4 | Carrossel "the edit": 1 packshot por slide, legenda em 2 níveis | CORE | Net-a-Porter |
| R5 | Close de pernas com contraste de cor (ideia de foto; não repetir o post) | FOOTWEAR | Loeffler Randall 03 |
| R6 | Still com objeto e name-card "Meet [modelo]" | lista antiga | Schutz US 06, 10 |
| R7 | Recorte de pé em ação | lista antiga | Jacquemus 07 |

Detalhes de cada R: fichas em `refs/<marca>/ficha.md`.

## Medidas que o Pietro usou (06/10)
- Copy em Platform Regular, entrelinha 104%: ~64–66 px no 9:16 e no 1:1; ~45–56 px no 1200×628. Menor e mais editorial do que eu vinha usando (80–96).
- Logo: 250×45 no 9:16 e no 1:1; **176×31 no 1200×628**, em (60, 556).
- Fotos: retângulo da foto maior que o frame e posicionado à mão (enquadramento fechado, produto grande); não precisa ser CROP exato.

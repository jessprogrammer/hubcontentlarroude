# stevemadden - 12 primeiros posts do grid público (observado em 2026-09-30, sem login)

Miniaturas do grid público: lado maior 640px (limite sem login; ~1080px só com acesso logado). Tipo inferido pelo ícone do grid; descrição = o que se vê na miniatura (capa do carrossel/reel, sem ver o interior). Ordem = ordem do grid.

| nº | link | tipo | data | resolução salva (px) | descrição visual |
|---|---|---|---|---|---|
| 01 | https://www.instagram.com/azzymilan/reel/DdjUdy2RUJd/ | reel (colab, perfil de criadora @azzymilan) | 2026-09-21 | 640x640 | Mulher de jaqueta de couro e óculos sentada com revista; logotipo STEVE MADDEN bege grande em caixa-alta sobreposto. |
| 02 | https://www.instagram.com/stevemadden/reel/Dd6ZVEUCXDG/ | reel | 2026-09-30 | 360x640 | Bota slouch taupe com jeans claro, texto pequeno "LIBERTY TAUPE" sobreposto; piso metálico azul de ônibus. |
| 03 | https://www.instagram.com/stevemadden/p/Dd45UO3m3sh/ | carrossel | 2026-09-29 | 511x640 | Ilustração de cartas de baralho com táxi amarelo e sapato rosa, logo STEVE MADDEN, sobre rua de NY ao pôr do sol. |
| 04 | https://www.instagram.com/stevemadden/reel/Dd1_jNQvWXT/ | reel | 2026-09-28 | 360x640 | Mulher de camisa xadrez e botas pretas em apartamento claro (estilo UGC/influenciadora). |
| 05 | https://www.instagram.com/stevemadden/p/Ddy4jL0Ex_k/ | carrossel | 2026-09-27 | 512x640 | Mulher de agasalho bordô e minissaia com bolsa e botas vermelhas dentro de ônibus de bancos azuis. |
| 06 | https://www.instagram.com/stevemadden/p/DdwF9Ink7tv/ | carrossel | 2026-09-26 | 512x640 | Pernas em botas pretas de cano alto e minissaia marrom, ônibus azul. |
| 07 | https://www.instagram.com/stevemadden/p/Ddt5SUAk6V9/ | carrossel | 2026-09-25 | 512x640 | Modelo de conjunto estampa de onça e botas de onça sobre tapete zebra; luz quente. |
| 08 | https://www.instagram.com/stevemadden/p/DdsL9wgm2wM/ | carrossel | 2026-09-24 | 512x640 | Gráfico branco "office siren starter pack": 4 itens recortados (scarpin de onça, óculos, saia, jaqueta) com legendas em negrito/regular. |
| 09 | https://www.instagram.com/stevemadden/p/DdrcKAum5ZX/ | carrossel | 2026-09-24 | 480x640 | Close de botas vermelhas de cano alto em croco, salto fino, carpete azul. |
| 10 | https://www.instagram.com/stevemadden/p/DdpOo7fgbWc/ | carrossel | 2026-09-23 | 512x640 | Modelo de casaco de pelo marrom e óculos, botas de amarração até o joelho, poltrona estilo jatinho. |
| 11 | https://www.instagram.com/stevemadden/p/DdmBKz2Edij/ | carrossel | 2026-09-22 | 480x640 | Modelo de óculos segurando sapato de onça como se fosse telefone, jaqueta de couro, caderno. |
| 12 | https://www.instagram.com/stevemadden/p/DdkZ-O9G5t8/ | carrossel | 2026-09-21 | 513x640 | Modelo em botas de amarração em corredor vermelho escuro, luz dramática. |

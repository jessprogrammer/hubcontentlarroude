# Steve Madden

Steve Madden · lower end · @stevemadden (https://www.instagram.com/stevemadden/, 2,8 mi seguidores, bio "Your favorite shoe since 1990", link likeshop.me) · observado em 2026-09-30 · fonte: grid público sem login (12 primeiros posts)

## Leitura dos posts
- **Formatos:** 9 carrosséis e 3 reels. O 1º item do grid é um reel colab de uma criadora (@azzymilan), possivelmente fixado.
- **Composição:** o calçado está visível em 11 dos 12 posts. Há séries temáticas: 3 posts no ônibus de bancos azuis (bota slouch, botas vermelhas, botas pretas) e uma estética "office siren" (onça, óculos, couro). Muitos recortes do joelho para baixo. Há um gráfico de produto recortado sobre branco ("starter pack" com 4 itens e legendas) e uma ilustração sobre foto (cartas de baralho com táxi de NY).
- **Tipografia/texto:** muito mais presente que nos outros grupos: logo grande em caixa-alta sobre o vídeo, nome do modelo sobre a foto ("LIBERTY TAUPE") e legendas de produto em negrito mais regular.
- **Cor:** saturada e contrastante (azul do ônibus contra vermelho e marrom, onça), luz de flash ou dramática.
- **Ritmo:** alta frequência (1 ou mais por dia), com tendência e meme como gancho.
- **Modelo, still ou ambiente:** quase tudo com modelo e cenário forte, mais 1 gráfico e 1 ilustração. UGC e influenciadora aparecem.

## O que aprender
1. **Série de cenário:** o mesmo local (ônibus) em 3 posts com modelos diferentes cria campanha reconhecível.
2. **Nome do produto sobre a imagem** em texto pequeno e discreto, próximo do sapato.
3. **"Starter pack"**: 4 itens recortados com legenda divertida, formato nativo de rede que vende o look de uma tendência.
4. **Gesto inesperado com o produto** (sapato usado como telefone) para chamar atenção.

## Base "nossa" usada para filtrar
Estudo de layouts Larroudé (ADS US/BR, 2026-09-30) e regras da liderança. Os pontos são:
- foto real liderando, com o produto em destaque e inteiro (bico e salto);
- foto única full-bleed em cerca de metade das peças;
- 1:1 hero com foto mais alta que o frame e título no rodapé;
- hero com tira de detalhes do mesmo produto;
- colagem de até 3 fotos do mesmo storytelling ou fundo, coladas, sem listra branca e sem "cara de PowerPoint";
- títulos curtos (≤30 caracteres) em Platform, Items ou Very Vogue;
- name-card "Bota X" ao lado do produto;
- cores chapadas da paleta;
- sem selos ou carimbos em volta do logo.

A referência é uma opção para inovar, nunca uma regra.

## Quando usar / quando não usar
- Tendência, testes rápidos de performance, público jovem.
- Não usar a estética barulhenta como linguagem da marca.

## Sugestões
- **Série de cenário.** Testar o mesmo local em 3 peças, com looks e modelos diferentes, numa campanha ON-FOOT (9:16 e 1:1, foto única cada). Cria reconhecimento sem mudar layout (posts 02, 05 e 06). Evitar cenário "barato": escolher um local com cor da paleta e boa luz.
- **Nome do modelo ao lado do sapato.** Reforçar o nosso name-card "Bota X" (Platform mais wordmark) ao lado do produto, em texto pequeno (post 02). A referência confirma que o nome perto do sapato funciona em performance. Evitar texto grande sobre o produto.
- **Starter pack.** Só como CAROUSEL orgânico, com 1 sapato por slide e uma frase de humor na capa. A versão com 4 itens recortados num quadro tem cara de PowerPoint e soa barata. Evitar recortes de origens diferentes no mesmo quadro.

## Aplicabilidade
**Média.** Ritmo e nome do produto servem; a estética e as montagens não.

## Limite (não trazer)
- Starter pack com vários itens recortados num quadro (post 08).
- Ilustração sobre foto (post 03).
- Logo gigante sobre o vídeo.
- Gesto de meme que banaliza o produto.
- Luz de flash dura e cenário de baixa estética.

## Confiança
Média-alta. O padrão é forte e repetido.

## Limites da coleta
Miniaturas de 640px (grid público). A versão em alta (~1080px) depende de acesso logado. Não abri carrosséis nem reels e não li legendas.

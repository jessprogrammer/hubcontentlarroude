# Índice de referências

| Marca | Grupo | Fonte | Coleta | Status |
|---|---|---|---|---|
| Jacquemus | runway (fora da lista de 06/10) | Instagram @jacquemus, grid público sem login | 2026-09-30 | coletado (12 capas, sem interior de carrossel) |
| Khaite | CORE | Instagram @khaite, grid público sem login | 2026-09-30 | coletado (12 capas) |
| The Row | CORE | Instagram @therow, grid público sem login | 2026-09-30 | coletado (12 capas; feed sem produto) |
| Sézane | CORE | Instagram @sezane, grid público sem login | 2026-09-30 | coletado (12 capas) |
| Cult Gaia | CORE | Instagram @cultgaia, grid público sem login | 2026-09-30 | coletado (12 capas; semana de desfile, pode não ser representativo) |
| Loeffler Randall | FOOTWEAR | Instagram @loefflerrandall, grid público sem login | 2026-09-30 | coletado (12 capas) |
| Steve Madden | FOOTWEAR | Instagram @stevemadden, grid público sem login | 2026-09-30 | coletado (12 capas; 1º item é colab @azzymilan) |
| Schutz | lower end (fora da lista de 06/10) | Instagram @schutz (Schutz U.S.), grid público sem login | 2026-09-30 | parcial (conta dos EUA; a conta Brasil não foi vista) |
| Net-a-Porter | CORE | net-a-porter.com/en-us: home, sapatos, novidades, PORTER | 2026-09-30 | parcial (7 screenshots de 800px; headless bloqueado por anti-bot; corpo do artigo não renderizou) |

Grupos segundo a lista oficial da Marina de 06/10 (ver README). Ainda sem coleta: o restante da CORE, da FOOTWEAR e toda a CREATIVE/GROWTH (Perfectwhitetee já tem estudo próprio no Figma, frame 21165:2).

Síntese do piloto: `SINTESE-PILOTO.md`.

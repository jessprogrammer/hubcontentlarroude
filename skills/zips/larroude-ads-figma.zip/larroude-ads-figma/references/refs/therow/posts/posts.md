# therow - 12 primeiros posts do grid público (observado em 2026-09-30, sem login)

Miniaturas do grid público: lado maior 640px (limite sem login; ~1080px só com acesso logado). Tipo inferido pelo ícone do grid; descrição = o que se vê na miniatura (capa do carrossel/reel, sem ver o interior). Ordem = ordem do grid.

| nº | link | tipo | data | resolução salva (px) | descrição visual |
|---|---|---|---|---|---|
| 01 | https://www.instagram.com/therow/p/Dd0tHI9o9wp/ | foto | 2026-09-28 | 640x640 | Retrato sorridente de mulher de cabelo rosa e camiseta rosa-claro sobre fundo azul-petróleo. |
| 02 | https://www.instagram.com/therow/p/DdbmTt5xRcy/ | foto | 2026-09-18 | 512x640 | Cama com colcha floral e dois telefones antigos cor creme; luz com sombras de folhagem. |
| 03 | https://www.instagram.com/therow/p/DbDrx2YjCyc/ | carrossel | 2026-07-21 | 640x640 | Jovem loira de franja e suéter amarelo, perfil 3/4, fundo cinza-claro. |
| 04 | https://www.instagram.com/therow/p/Da5Yu9aOMXp/ | foto | 2026-07-17 | 640x640 | Pintura de campo de trigo com corvos (obra de arte), cores saturadas. |
| 05 | https://www.instagram.com/therow/p/DZNPcunglEN/ | foto | 2026-06-05 | 640x640 | Pôr do sol laranja visto por um rasgo em lona azul-água. |
| 06 | https://www.instagram.com/therow/p/DY49f4wp7ad/ | foto | 2026-05-28 | 640x640 | Monotipia laranja em forma de cabeça sobre papel claro. |
| 07 | https://www.instagram.com/therow/p/DYFJdEtABV7/ | carrossel | 2026-05-08 | 640x640 | Retrato de homem de terno preto e gravata, fundo cinza-claro, olhar frontal. |
| 08 | https://www.instagram.com/therow/p/DYE7BrdgO30/ | foto | 2026-05-08 | 640x640 | Foto P&B de escultura em estúdio com grande ponto de luz branca. |
| 09 | https://www.instagram.com/therow/p/DYDTy7ACRkn/ | foto | 2026-05-07 | 640x640 | Desenho/colagem abstrato com formas escuras sobre papel bege. |
| 10 | https://www.instagram.com/therow/p/DX9a_2TAPPt/ | carrossel | 2026-05-05 | 640x640 | Retrato de modelo de cabelo preso e top tomara-que-caia preto sobre fundo bege. |
| 11 | https://www.instagram.com/therow/p/DX9MpDRgYbH/ | foto | 2026-05-05 | 640x640 | Foto P&B em formato paisagem de mesa com cerâmicas e objetos expostos. |
| 12 | https://www.instagram.com/therow/p/DX7am4aCTHV/ | foto | 2026-05-04 | 640x640 | Colagem/pintura com sol vermelho e formas verdes em papel envelhecido. |

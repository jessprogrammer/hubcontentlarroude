# The Row

The Row · runway · @therow (https://www.instagram.com/therow/, 3,1 mi seguidores, link therow.com) · observado em 2026-09-30 · fonte: grid público sem login (12 primeiros posts)

## Leitura dos posts
- **Formatos:** 9 fotos únicas e 3 carrosséis, nenhum reel. A frequência é baixa: os 12 posts vão de 04/05 a 28/09/2026.
- **Composição:** o feed parece um caderno de galeria: pinturas, gravuras, colagens, esculturas em P&B e retratos de estúdio frontais sobre fundo liso. Algumas imagens mantêm o formato original (paisagem) dentro do quadro. Não há produto identificável nem calçado nos 12.
- **Tipografia/texto:** nenhum.
- **Cor:** cada imagem traz uma cor própria (laranja, amarelo, azul-petróleo, rosa) e o conjunto é sóbrio. Há bastante P&B.
- **Ritmo:** curadoria, não calendário. A marca comunica gosto e referências, não vende no feed.
- **Modelo, still ou ambiente:** retratos (5), arte e objetos (6) e um interior (cama com telefones).

## O que aprender
1. **Retrato frontal simples sobre fundo de uma cor:** quanto menos elementos, mais autoridade.
2. **Formato original da imagem dentro do quadro com margem:** é o recurso típico da The Row, mas NÃO serve para a Larroudé (vira barra branca; veja Limite).
3. **Referência de arte como paleta:** usar uma obra ou textura para ditar a cor de uma campanha.

## Base "nossa" usada para filtrar
Estudo de layouts Larroudé (ADS US/BR, 2026-09-30) e regras da liderança. Os pontos são:
- foto real liderando, com o produto em destaque e inteiro (bico e salto);
- foto única full-bleed em cerca de metade das peças;
- 1:1 hero com foto mais alta que o frame e título no rodapé;
- hero com tira de detalhes do mesmo produto;
- colagem de até 3 fotos do mesmo storytelling ou fundo, coladas, sem listra branca e sem "cara de PowerPoint";
- títulos curtos (≤30 caracteres) em Platform, Items ou Very Vogue;
- name-card "Bota X" ao lado do produto;
- cores chapadas da paleta;
- sem selos ou carimbos em volta do logo.

A referência é uma opção para inovar, nunca uma regra.

## Quando usar / quando não usar
- Referência de tom para peças institucionais.
- Não usar em ads de performance: não há produto.

## Sugestões
- **Packshot com respiro.** Testar um packshot centralizado com bastante ar em fundo de uma cor (#F6F6F6 ou cor da paleta), num STATIC 1:1 PRODUCT-FOCUSED de peça-ícone. A casa já usa produto centralizado com ar e tipografia ao redor (17543:232); a referência mostra como a simplicidade dá autoridade. Evitar encolher o produto além de cerca de 60% da largura.

## Aplicabilidade
**Baixa.** Vale como lembrete de contenção, não como formato.

## Limite (não trazer)
- Imagem em formato original dentro do quadro com margem branca: vira barra branca, contra a regra da casa.
- Conteúdo de arte sem produto.
- Feed sem calçado.
- P&B como linguagem.

## Confiança
Média para o tom. É baixa a aplicabilidade direta a anúncios de calçado.

## Limites da coleta
Miniaturas de 640px (grid público). A versão em alta (~1080px) depende de acesso logado. Não abri os carrosséis nem li legendas, e não confirmei o selo visualmente.

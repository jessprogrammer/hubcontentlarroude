# Referências externas (pasta da skill)

Inspiração conceitual, visual e de diagramação. Referências são OPÇÕES para inovar, nunca regra. Toda sugestão respeita os limites da comunicação Larroudé: (1) o padrão das nossas postagens e ads; (2) as regras fundamentais da liderança (Marina e Ricardo), hoje revisadas pela equipe de design. O agente de referências avalia a aplicabilidade de cada referência e propõe sugestões objetivas: o que testar, em que tipo de peça e foto, e o que evitar.

## Lista oficial de marcas (Marina, 06/10/2026)
Esta é a lista principal. A lista anterior, de 30/09 (desfiles, concorrentes, lower end, sites), passa a ser secundária.

| Grupo | Para que serve | Marcas |
|---|---|---|
| CORE | Acompanhar sempre; é o conjunto padrão de cada rodada de referências | Alo, Rhode, Reformation, Aritzia, SKIMS, Sézane, STAUD, Tory Burch, Khaite, The Row, Miu Miu, Coach, Cult Gaia, DÔEN, NET-A-PORTER, Mytheresa, Revolve |
| FOOTWEAR | Produto e performance: concorrentes diretos de calçado. Vale a regra de não repetir o que fizeram por último | Margaux, Loeffler Randall, Dear Frances, Aeyde, ALOHAS, Stuart Weitzman, Sam Edelman, Steve Madden, Dolce Vita, Thursday Boot Company |
| CREATIVE / GROWTH | Não são necessariamente concorrentes: servem para aprender formato de ad, gancho, copy e mecânica de crescimento | Uniqlo, La Ligne, Quince, Vuori, Gymshark, Hoka, Glossier, Rare Beauty, Charlotte Tilbury, Poppi, Warby Parker, Bombas, Perfectwhitetee, Zara |

## Estrutura
- `index.md`: lista de marcas, grupo, status e data da coleta.
- `<marca>/ficha.md`: ficha da marca (formato abaixo).
- `<marca>/posts/`: miniaturas dos posts observados (nomeadas 01.jpg a 12.jpg) e `posts.md` com links e descrição.
- Figma: aba "Claude Referências" (mesmo conteúdo, visual).

## Formato da ficha
Marca · grupo (CORE, FOOTWEAR, CREATIVE/GROWTH; ou o grupo antigo, se a marca só estiver na lista de 30/09) · link · data da observação · fonte (grid público, logado)
Leitura dos posts: formatos (carrossel, reel, foto), composição, tipografia e texto, cor, ritmo de conteúdo
O que aprender · quando usar / quando não usar · como adaptar à Larroudé
Peças relacionadas · status · confiança (alta, média, baixa)

## Regras de coleta
- Somente leitura: não curtir, seguir, comentar, enviar mensagem nem baixar material além das miniaturas para referência interna.
- Se uma fonte pedir login ou captcha, parar e pedir à pessoa responsável.
- Sempre registrar a fonte e a data.

## Concorrentes diretos
Em peças criativas, evitar materiais parecidos com os mais recentes dos concorrentes diretos: a ficha deles serve para checar o que não repetir, não como modelo. Em peças básicas (produto ou on-foot simples), semelhança é aceitável, porque a maioria segue um padrão comum. Runway e sites continuam como fonte de inspiração, dentro dos nossos limites.

# Síntese do piloto de referências (coleta de 2026-09-30)

Base: 8 marcas no Instagram (12 capas cada, sem login, 640px) e a Net-a-Porter (7 screenshots públicos de 800px). Referências são **opções para inovar, nunca regra**. Toda ideia abaixo já foi filtrada pelo nosso padrão:
- estudo de layouts ADS US/BR (`C:/Users/Pietro.Boeira/airtmp/estudo-layouts.md`);
- regras da liderança: foto real liderando, produto em destaque e inteiro, colagem de no máximo 3 fotos do mesmo storytelling ou fundo, imagens coladas sem listra branca, nada de "cara de PowerPoint" e nada de selos em volta do logo.

## Ideias ordenadas por aplicabilidade para a Larroudé

### Alta
1. **Close de pernas com contraste de cor** (Loeffler Randall). Testar bota com saia e piso de cores vivas em STATIC 1:1 ON-FOOT hero (foto mais alta que o frame, calçado no terço inferior, título no rodapé), porque é o crop 1:1 da casa com mais cor. Evitar cortar o pé.
2. **Tom sobre tom** (Sézane). Testar sapato e fundo ou cenário da mesma família de cor em STATIC 1:1 ou 9:16 PRODUCT-FOCUSED ou ON-FOOT de estúdio, porque harmoniza sem disputar com o produto e usa as cores chapadas que já são nossas. Evitar fundo mais saturado que o sapato.
3. **Still com objeto de apoio e name-card** (Schutz). Testar o par sobre livros, bandeja ou caixa, com "Bota X" ou "Meet [modelo]" pequeno ao lado, em STATIC 1:1 PRODUCT-FOCUSED, porque une história e produto em destaque. Evitar objeto que rouba a cor ou a escala.
4. **Recorte de pé em ação** (Jacquemus). Testar pedalar, subir degrau ou atravessar em STATIC 9:16 ON-FOOT, foto única full-bleed, só com o wordmark ou um título curto, porque acrescenta gesto ao formato mais usado da casa. Evitar cortar bico ou salto.
5. **Pose sentada que mostra o sapato em perfil** (Schutz). Testar em STATIC 9:16 ON-FOOT, porque mostra o modelo inteiro com naturalidade. Evitar o par no canto do quadro.
6. **Cenário de cor real** (Jacquemus). Testar parede ou chão na cor da paleta em STATIC 1:1 hero, porque a cor vem da foto e não de painel aplicado. Evitar faixa de cor artificial para esticar a foto.

### Média-alta
7. **Carrossel "the edit"** (Net-a-Porter). Testar 1 packshot por slide, mesma escala e direção, fundo #F6F6F6 ou #ECE6E8, legenda em 2 níveis (modelo em Platform, cor ou preço em Plain caixa-alta), em CAROUSEL PRODUCT-MIX, porque organiza vários produtos sem colagem. Evitar vários produtos por slide.
8. **Capa com itálico e regular** (Net-a-Porter). Testar Very Vogue Italic e Regular, 30 caracteres ou menos, sobre foto na capa de carrossel editorial. Evitar caixa-alta gigante sobre o produto.

### Média
9. **Macro de material como detalhe** (Khaite). Testar verniz, croco ou salto como miniatura no layout hero com tira de detalhes (mesmo produto e sessão) ou como slide PRODUCT-DETAILS. Evitar a macro como peça única de performance.
10. **Série de cenário** (Steve Madden). Testar o mesmo local em 3 peças ON-FOOT com looks diferentes, porque cria reconhecimento. Evitar cenário de baixa estética.
11. **Par fora do pé** (Cult Gaia). Testar sandálias tiradas ao lado da modelo em STATIC 9:16 EDITORIAL, foto única. Evitar par pequeno e roupa dominando.
12. **Capa de lançamento com wordmark grande e data pequena** (Sézane). Testar como slide 1 de carrossel de drop ou sobre foto. Evitar ad só de texto.
13. **Flat lay de look com sapato maior** (Loeffler Randall). Testar em STATIC 1:1 PRODUCT-MIX sobre fundo de cor. Evitar sapato do tamanho das outras peças.

### Baixa
14. **Packshot com muito respiro** (The Row). Só para peça-ícone em 1:1, produto com pelo menos 60% da largura.
15. **Starter pack** (Steve Madden). Só como carrossel orgânico, 1 sapato por slide, nunca 4 recortes num quadro.

## O que NÃO trazer (fere o nosso padrão)
- Grade ou montagem com mais de 3 fotos, ou com fotos de shoots diferentes (starter pack, grade solta de pares, composição duplicada).
- Margem ou moldura branca em volta da foto (The Row) e listras brancas entre imagens.
- Posts sem calçado: arte, natureza-morta, cenas-poema, desfile, front row, retratos de rosto.
- Ilustração ou colagem sobre foto, logo gigante como único elemento, selos e carimbos.
- Peça 100% tipográfica como ad de conversão.
- Paletas apagadas (vintage marrom, frio cinza) como linguagem padrão.

## Padrões por grupo
- **Runway** (Jacquemus, Khaite, The Row): pouco produto, quase sem texto, coesão pela luz e pela curadoria. Para nós, serve o recorte de ação e o detalhe de material, não o feed sem calçado.
- **Concorrente direto** (Sézane, Cult Gaia, Loeffler Randall): mistura produto, still e lifestyle, com coesão pela família de cor. É a fonte mais rica de ideias aplicáveis.
- **Lower end** (Steve Madden, Schutz US): sapato em quase todo post, série de cenário, nome do produto na imagem. Serve o ritmo e o name-card; não serve a estética barulhenta nem as montagens.
- **Site** (Net-a-Porter): hierarquia de legenda e packshot padronizado para carrossel de produto.

## Lacunas
- Não foi vista a conta Schutz Brasil.
- O interior de carrosséis e reels não foi visto.
- Não há versão em alta (~1080px, depende de login).
- Os screenshots da Net-a-Porter têm só 800px.
- A Cult Gaia foi observada em semana atípica (desfile).

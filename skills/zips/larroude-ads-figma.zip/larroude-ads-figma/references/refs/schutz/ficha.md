# Schutz

Schutz · lower end (classificação do briefing; a equipe pode reavaliar) · @schutz = "Schutz U.S." (https://www.instagram.com/schutz/, 572 mil seguidores, link schutz-shoes.com) · observado em 2026-09-30 · fonte: grid público sem login (12 primeiros posts)

ATENÇÃO: o @schutz é a conta dos EUA. A conta Brasil não foi verificada; confirmar com a equipe qual conta interessa.

## Leitura dos posts
- **Formatos:** 8 carrosséis, 3 fotos e 1 reel.
- **Composição:** a campanha "preppy/universitária" é totalmente coesa: malas vintage, piquenique na grama, biblioteca, sofá listrado, station wagon antiga. O calçado está visível em 12 dos 12: no pé, em close de pernas (dentro do carro, junto a um telefone antigo) e em still sobre pilha de livros. Muitos enquadramentos do joelho para baixo e poses sentadas que mostram a sola e o perfil.
- **Tipografia/texto:** mínimo. Um reel tem "Meet: Lexi", nome do modelo pequeno ao lado do par.
- **Cor:** quente e vintage: madeira escura, bordô, caramelo, verde-grama e creme, com onça como acento.
- **Ritmo:** 1 post por dia dentro de uma narrativa única de estação.
- **Modelo, still ou ambiente:** cerca de 9 com modelo, 2 stills em cenário e 1 de detalhe.

## O que aprender
1. **Still em cenário com objeto de apoio** (sapato sobre pilha de livros): o objeto dá a história e eleva o produto.
2. **Pose sentada que expõe o sapato** (pernas cruzadas, saindo do carro): o modelo aparece inteiro de forma natural.
3. **Uma estação, uma narrativa:** cenário e paleta repetidos fazem o grid parecer uma campanha só.
4. **Nome do modelo em texto pequeno** ao lado do par ("Meet: Lexi").

## Base "nossa" usada para filtrar
Estudo de layouts Larroudé (ADS US/BR, 2026-09-30) e regras da liderança. Os pontos são:
- foto real liderando, com o produto em destaque e inteiro (bico e salto);
- foto única full-bleed em cerca de metade das peças;
- 1:1 hero com foto mais alta que o frame e título no rodapé;
- hero com tira de detalhes do mesmo produto;
- colagem de até 3 fotos do mesmo storytelling ou fundo, coladas, sem listra branca e sem "cara de PowerPoint";
- títulos curtos (≤30 caracteres) em Platform, Items ou Very Vogue;
- name-card "Bota X" ao lado do produto;
- cores chapadas da paleta;
- sem selos ou carimbos em volta do logo.

A referência é uma opção para inovar, nunca uma regra.

## Quando usar / quando não usar
- Campanha de estação e lançamento de modelo.
- Não usar a paleta marrom-vintage sem recolorir.

## Sugestões
- **Still com objeto de apoio.** Testar o par sobre livros, bandeja ou caixa Larroudé em STATIC 1:1 PRODUCT-FOCUSED, com name-card "Bota X" ou "Meet [modelo]" pequeno ao lado, na altura do sapato. Une produto em destaque e história, e casa com o name-card da casa (posts 06 e 10). Evitar objetos que roubam a cor ou a escala do sapato.
- **Pose sentada.** Testar pose que expõe o sapato em perfil (pernas cruzadas, saindo do carro) em STATIC 9:16 ON-FOOT, foto única. Mostra o modelo inteiro de forma natural (posts 09 e 11). Evitar cortar bico ou salto e deixar o par no canto do quadro.
- **Uma estação, uma narrativa.** Testar cenário e paleta repetidos em todas as peças de uma campanha.

## Aplicabilidade
**Alta.** O produto está sempre visível, em foto única, com pouco texto.

## Limite (não trazer)
- Paleta apagada marrom e madeira como padrão.
- Conta dos EUA, não a do Brasil; checar o tom local.

## Confiança
Média-alta para a conta dos EUA. Não vale para a conta Brasil.

## Limites da coleta
Miniaturas de 640px (grid público). A versão em alta (~1080px) depende de acesso logado. Não abri carrosséis nem li legendas, e a conta brasileira não foi vista.

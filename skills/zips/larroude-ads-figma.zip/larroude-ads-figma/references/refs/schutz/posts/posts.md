# schutz - 12 primeiros posts do grid público (observado em 2026-09-30, sem login)

Miniaturas do grid público: lado maior 640px (limite sem login; ~1080px só com acesso logado). Tipo inferido pelo ícone do grid; descrição = o que se vê na miniatura (capa do carrossel/reel, sem ver o interior). Ordem = ordem do grid.

| nº | link | tipo | data | resolução salva (px) | descrição visual |
|---|---|---|---|---|---|
| 01 | https://www.instagram.com/schutz/p/Dd62FDgG3l-/ | carrossel | 2026-09-30 | 480x640 | Malas vintage abertas no porta-malas com sapatilhas bordô, boné e suéter: estilo preppy. |
| 02 | https://www.instagram.com/schutz/p/Dd4QK9DG85u/ | carrossel | 2026-09-29 | 480x640 | Duas amigas na grama em piquenique, boné universitário, sapatilhas bordô, caderno. |
| 03 | https://www.instagram.com/schutz/p/Dd1goWxkX4V/ | carrossel | 2026-09-28 | 480x640 | Quatro jovens num muro de pedra, camisas rugby e bonés; sapatilhas visíveis. |
| 04 | https://www.instagram.com/schutz/p/Ddy-7qTRM2i/ | foto | 2026-09-27 | 480x640 | Modelo em sofá listrado vermelho e branco, jeans, suéter e botas marrons; madeira escura. |
| 05 | https://www.instagram.com/schutz/p/DdwwoTDmy86/ | carrossel | 2026-09-26 | 480x640 | Mulher sentada no chão lendo, suéter cinza e saia, scarpin marrom. |
| 06 | https://www.instagram.com/schutz/p/Ddt8kSmhF--/ | foto | 2026-09-25 | 480x640 | Par de mules de pelo de onça sobre pilha de livros azul-petróleo, madeira escura. |
| 07 | https://www.instagram.com/schutz/p/DdrPHe4kWJe/ | carrossel | 2026-09-24 | 480x640 | Modelo sentada em baú num quarto, blusa branca, sapato de onça. |
| 08 | https://www.instagram.com/schutz/p/DdovYoeEVjb/ | carrossel | 2026-09-23 | 480x640 | Detalhe de pernas com telefone antigo, scarpins marrom e preto de bico fino. |
| 09 | https://www.instagram.com/schutz/p/DdmKDx9G5IA/ | carrossel | 2026-09-22 | 480x640 | Modelo saindo de station wagon vintage, botas de cobra acima do joelho, blazer marrom. |
| 10 | https://www.instagram.com/schutz/reel/Ddjwxcph6o-/ | reel | 2026-09-21 | 360x640 | Par de scarpins pretos sobre livros; texto "Meet: Lexi" na lateral direita. |
| 11 | https://www.instagram.com/schutz/p/DdhKSmwhnwp/ | foto | 2026-09-20 | 480x640 | Pernas dentro de carro, scarpins creme com tira no tornozelo, bancos bege. |
| 12 | https://www.instagram.com/schutz/p/DdePtC2kUBE/ | carrossel | 2026-09-19 | 480x640 | Modelo de blazer bege e mules marrons sentada em banco de biblioteca, estantes ao fundo. |

# Cult Gaia

Cult Gaia · concorrente direto (classificação a confirmar) · @cultgaia (https://www.instagram.com/cultgaia/, 2,3 mi seguidores, bio "Objets d'art", link cultgaia.com) · observado em 2026-09-30 · fonte: grid público sem login (12 primeiros posts)

## Leitura dos posts
- **Formatos:** 6 reels e 6 carrosséis. A semana é dominada pela cobertura de desfile (passarela, convidados, cenário).
- **Composição:** passarela em corpo inteiro com cenário marcante (colina verde, concreto curvo), detalhes sem rosto (mão segurando clutch) e editorial de estúdio com parede de concreto texturizada. O post 01 traz sapatos de salto pretos espalhados no chão ao redor da modelo deitada: o calçado entra como elemento gráfico da cena.
- **Tipografia/texto:** nenhum texto sobre imagem nas capas.
- **Cor:** bege, concreto e verde do cenário, com acentos fortes da roupa (vermelho, vinho, mostarda).
- **Ritmo:** fase de "evento", com 3 a 4 posts por dia. Fora do desfile não dá para afirmar o padrão.
- **Modelo, still ou ambiente:** quase tudo com modelo, mais 1 interior de loja e 1 detalhe.

## O que aprender
1. **Sapato espalhado na cena** (post 01): o par fora do pé, jogado no chão, sugere uma história e dá destaque ao produto num editorial.
2. **Cenário arquitetônico** (concreto e arco) como moldura natural; dispensa elementos gráficos.
3. **Detalhe sem rosto segurando o produto:** foco total no acessório.

## Base "nossa" usada para filtrar
Estudo de layouts Larroudé (ADS US/BR, 2026-09-30) e regras da liderança. Os pontos são:
- foto real liderando, com o produto em destaque e inteiro (bico e salto);
- foto única full-bleed em cerca de metade das peças;
- 1:1 hero com foto mais alta que o frame e título no rodapé;
- hero com tira de detalhes do mesmo produto;
- colagem de até 3 fotos do mesmo storytelling ou fundo, coladas, sem listra branca e sem "cara de PowerPoint";
- títulos curtos (≤30 caracteres) em Platform, Items ou Very Vogue;
- name-card "Bota X" ao lado do produto;
- cores chapadas da paleta;
- sem selos ou carimbos em volta do logo.

A referência é uma opção para inovar, nunca uma regra.

## Quando usar / quando não usar
- Editorial de coleção ou de evento.
- Não usar como ad de produto quando a roupa domina o quadro.

## Sugestões
- **Par fora do pé.** Testar sandálias tiradas e deixadas no chão ao lado da modelo em STATIC 9:16 EDITORIAL, foto única de um mesmo shoot. Conta história e mantém o par visível e inteiro (post 01). Evitar quando o par ocupa pouco do quadro ou a roupa rouba a atenção.
- **Mão segurando o sapato.** Testar detalhe sem rosto, com a mão segurando ou ajustando o sapato (tema HAND-HELD já existente), como 1 das até 3 fotos de uma colagem do mesmo shoot, colada e sem listra branca. É foco total no produto com contexto humano (post 06). Evitar misturar com fotos de outro shoot.

## Aplicabilidade
**Média.** Duas ideias boas, num feed atípico (semana de desfile).

## Limite (não trazer)
- Cobertura de desfile e front row.
- Roupa dominando.
- Cenário arquitetônico que deixa o sapato pequeno.

## Confiança
Média-baixa. O recorte coincidiu com a semana de desfile, então é provável que não represente o feed regular.

## Limites da coleta
Miniaturas de 640px (grid público). A versão em alta (~1080px) depende de acesso logado. Não vi o interior dos carrosséis e reels nem li legendas, e não confirmei o selo visualmente.

# cultgaia - 12 primeiros posts do grid público (observado em 2026-09-30, sem login)

Miniaturas do grid público: lado maior 640px (limite sem login; ~1080px só com acesso logado). Tipo inferido pelo ícone do grid; descrição = o que se vê na miniatura (capa do carrossel/reel, sem ver o interior). Ordem = ordem do grid.

| nº | link | tipo | data | resolução salva (px) | descrição visual |
|---|---|---|---|---|---|
| 01 | https://www.instagram.com/cultgaia/p/Dd60Px2D7F_/ | carrossel | 2026-09-30 | 480x640 | Modelo deitada de saia preta e top de plumas; sapatos de salto pretos pontudos espalhados pelo chão bege (calçado em cena). |
| 02 | https://www.instagram.com/cultgaia/reel/Dd4CFNlBgBq/ | reel | 2026-09-29 | 640x480 | Modelo de cabelo curto sentada em cadeira branca segurando bolsa vinho com corrente; fundo marrom-escuro. |
| 03 | https://www.instagram.com/cultgaia/p/Dd107VdD59I/ | carrossel | 2026-09-28 | 512x640 | Desfile: modelo masculino de blazer e bermuda preta, sandália, plateia; cenário de colina verde e concreto. |
| 04 | https://www.instagram.com/cultgaia/reel/Ddzxs-jPqYl/ | reel | 2026-09-27 | 361x640 | Desfile: vestido longo de plumas vermelho e branco. |
| 05 | https://www.instagram.com/cultgaia/reel/DdzRrJfPWIG/ | reel | 2026-09-27 | 360x640 | Desfile: vestido halter azul-acinzentado, braceletes. |
| 06 | https://www.instagram.com/cultgaia/p/DdwyzA6D1Im/ | carrossel | 2026-09-26 | 512x640 | Detalhe de jaqueta de couro oliva segurando clutch listrada; corte sem rosto. |
| 07 | https://www.instagram.com/cultgaia/p/DdujsFsj41N/ | carrossel | 2026-09-25 | 480x640 | Três pessoas sentadas num banco em roupas de couro preto (front row). |
| 08 | https://www.instagram.com/cultgaia/p/Ddre8s_j6Tq/ | carrossel | 2026-09-24 | 480x640 | Interior de loja em arcos bege com dois pufes amarelo-mostarda. |
| 09 | https://www.instagram.com/cultgaia/reel/DdpFO6MyiDX/ | reel | 2026-09-23 | 360x640 | Desfile: vestido verde-claro com babados. |
| 10 | https://www.instagram.com/cultgaia/reel/DdmcrsSznU9/ | reel | 2026-09-22 | 360x640 | Modelo de perfil, casaco roxo-vinho texturizado e saia longa transparente, parede de concreto. |
| 11 | https://www.instagram.com/cultgaia/reel/Ddj2JRsvSPu/ | reel | 2026-09-21 | 360x640 | Desfile: vestido estampado aquarela com bolsa de palha. |
| 12 | https://www.instagram.com/cultgaia/p/DdhXhuaEp8g/ | carrossel | 2026-09-20 | 512x640 | Modelo de óculos escuros, top e saia vermelhos, argola grande, parede de concreto branca. |

# Net-a-Porter

Net-a-Porter · site · https://www.net-a-porter.com/en-us/ (home, /shop/shoes, /shop/new-in/shoes, artigo PORTER "best-winter-boots") · observado em 2026-09-30 · fonte: páginas públicas sem login, navegador do app

## Screenshots salvos
Todos com 800 x 569 px (viewport de 1000 x 700 reduzido pelo navegador do app).

| arquivo | conteúdo |
|---|---|
| 01-home-hero.jpg | Home: barra superior, menu preto e hero full-bleed |
| 02-home-editorial-pair.jpg | Home: par de imagens lado a lado (modelo com botas e still de bolsa) |
| 03-home-accessories-update.jpg | Home: tríptico de imagens, título serifado, subtítulo e CTA sublinhado |
| 04-shoes-grid-top.jpg | Categoria de sapatos: título, subcategorias, filtro e grade de 4 colunas |
| 05-shoes-grid-scroll.jpg | Grade com legenda (marca em caixa-alta e preço) e tile editorial maior na grade |
| 06-new-in-shoes.jpg | Novidades de sapatos: rótulo "NEW IN" e grade |
| 07-porter-editorial-header.jpg | Artigo PORTER: masthead, menu em caixa-alta espaçada e título serifado gigante em itálico/regular |

## Leitura (diagramação, tipografia, espaço)
- **Grade de produto:** 4 colunas sem gutter, packshot sobre cinza muito claro e uniforme, sapato de perfil apontando para a esquerda, todos na mesma escala e linha de base. A legenda fica abaixo em 3 níveis: MARCA em caixa-alta bold sans, nome do modelo em serifa regular e preço em sans. No meio da grade entra um tile editorial maior, ocupando 2 colunas (foto de produto em ambiente).
- **Home:** hero full-bleed com modelo, depois blocos editoriais. Cada bloco segue a sequência imagem, título serifado curto centralizado, subtítulo de uma linha e CTA em texto sublinhado (sem botão).
- **Tipografia:** a sans do site é AkkuratPro (14px, tracking leve), lida via CSS. Títulos e nomes de produto usam serifa de alto contraste. O PORTER usa display serifado enorme misturando itálico e regular na mesma frase ("THE BEST BOOTS" em itálico, "TO SEE YOU THROUGH THE SEASON" em regular).
- **Espaço em branco:** generoso nas margens e entre blocos, e a imagem vai até a borda. O contraste "foto cheia × texto com muito ar" organiza a página.

## O que aprender
1. **Legenda em 3 níveis** (marca, modelo, preço) com contraste sans bold, serifa e sans: hierarquia limpa para cards de produto.
2. **Packshot padronizado:** mesma escala, mesma direção e fundo cinza-claro, para uma grade calma.
3. **Tile editorial quebrando a grade:** um quadro maior a cada N produtos.
4. **Título misturando itálico e regular** para enfatizar o tema (ex.: *THE BEST BOOTS* to see you through).

## Base "nossa" usada para filtrar
Estudo de layouts Larroudé (ADS US/BR, 2026-09-30) e regras da liderança. Os pontos são:
- foto real liderando, com o produto em destaque e inteiro (bico e salto);
- foto única full-bleed em cerca de metade das peças;
- 1:1 hero com foto mais alta que o frame e título no rodapé;
- hero com tira de detalhes do mesmo produto;
- colagem de até 3 fotos do mesmo storytelling ou fundo, coladas, sem listra branca e sem "cara de PowerPoint";
- títulos curtos (≤30 caracteres) em Platform, Items ou Very Vogue;
- name-card "Bota X" ao lado do produto;
- cores chapadas da paleta;
- sem selos ou carimbos em volta do logo.

A referência é uma opção para inovar, nunca uma regra.

## Quando usar / quando não usar
- Carrossel de catálogo e edit curado.
- Não usar o tom de varejo multimarca em peças de marca.

## Sugestões
- **Carrossel "the edit".** Testar 1 packshot por slide, na mesma escala e direção, sobre fundo claro que já usamos (#F6F6F6 ou #ECE6E8), com legenda em 2 níveis: nome do modelo em Platform e cor ou preço em Plain caixa-alta. Organiza um CAROUSEL PRODUCT-MIX sem montar grade, com um produto por slide. Evitar vários produtos num mesmo slide.
- **Capa com itálico e regular.** Testar título misturando Very Vogue Display Italic e Regular (já existe no arquivo), com 30 caracteres ou menos, na capa de carrossel editorial sobre foto. Dá ênfase elegante (screenshot 07). Evitar caixa-alta gigante cobrindo o produto.

## Aplicabilidade
**Média-alta** para carrossel de produto. **Baixa** para o resto.

## Limite (não trazer)
- Grade de vários produtos num quadro.
- CTA sublinhado de site, que não se traduz em ad.
- Packshot pequeno demais.

## Confiança
Média. Vi a home, 2 listagens e o topo de 1 artigo.

## Limites da coleta
O navegador do app limita os screenshots a 800px de largura, então não foi possível chegar a 1600px ou mais. Uma tentativa de screenshot em alta com Chrome headless recebeu "Access Denied" (proteção anti-bot do Akamai); parei ali, sem insistir nem contornar, e o arquivo foi descartado. O corpo do artigo PORTER renderizou em branco nas capturas (lazy-load), então só o cabeçalho foi registrado. Fiquei na versão en-us. Um pop-up de "Shipping to Brazil" foi ocultado via JS, sem clicar.

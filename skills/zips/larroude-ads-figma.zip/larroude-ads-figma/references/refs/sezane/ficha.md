# Sézane

Sézane · concorrente direto (DTC premium acessível; classificação a confirmar pela equipe) · @sezane (https://www.instagram.com/sezane/, 6 mi seguidores, bio "From Paris", link linktr.ee) · observado em 2026-09-30 · fonte: grid público sem login (12 primeiros posts)

## Leitura dos posts
- **Formatos:** 10 carrosséis, 1 reel e 1 foto. Os 3 primeiros parecem fixados (datas fora de ordem: 18/08, 11/09 e 30/09).
- **Composição:** foto única por post. Alterna modelo em meio-corpo (tricô), still de acessório de cima (bolsa, lenços em nós), interior de loja ou café e esboço de perfume. O produto aparece em plano médio ou fechado, quase sempre vestido ou manuseado. Não vi calçado nos 12.
- **Tipografia/texto:** um post é capa tipográfica pura (SÉZANE em serifa alta preta sobre branco, data pequena em caixa-alta espaçada). O resto não tem texto.
- **Cor:** paleta outonal quente e coesa: mostarda, terracota, verde-oliva, vermelho-ferrugem, caramelo e creme. Os fundos são coloridos, mas da mesma família.
- **Ritmo:** mistura de produto (roupa e acessório) com o universo da marca (loja, café, perfume), sempre na mesma temperatura de cor.
- **Modelo, still ou ambiente:** cerca de 5 com modelo, 3 stills, 3 ambientes e 1 gráfico.

## O que aprender
1. **Fundo da mesma família da peça** (tricô ferrugem sobre mostarda, cardigã branco sobre verde-musgo): o conjunto fica harmônico, sem disputa.
2. **Capa tipográfica** (wordmark grande e data pequena) para anunciar evento ou lançamento.
3. **Still em nós ou dobras** (lenços): o produto vira textura e padrão.
4. **Universo de loja e café** como prova de lifestyle entre os posts de produto.

## Base "nossa" usada para filtrar
Estudo de layouts Larroudé (ADS US/BR, 2026-09-30) e regras da liderança. Os pontos são:
- foto real liderando, com o produto em destaque e inteiro (bico e salto);
- foto única full-bleed em cerca de metade das peças;
- 1:1 hero com foto mais alta que o frame e título no rodapé;
- hero com tira de detalhes do mesmo produto;
- colagem de até 3 fotos do mesmo storytelling ou fundo, coladas, sem listra branca e sem "cara de PowerPoint";
- títulos curtos (≤30 caracteres) em Platform, Items ou Very Vogue;
- name-card "Bota X" ao lado do produto;
- cores chapadas da paleta;
- sem selos ou carimbos em volta do logo.

A referência é uma opção para inovar, nunca uma regra.

## Quando usar / quando não usar
- Campanhas de estação, cor e lançamento com data.
- Não usar a paleta outonal apagada nos drops de verão.

## Sugestões
- **Tom sobre tom.** Testar sapato e fundo ou cenário da mesma família de cor (rosa sobre rosa-claro, vermelho sobre bordô) em STATIC 1:1 ou 9:16 PRODUCT-FOCUSED ou ON-FOOT de estúdio. A casa já usa fundos de cor chapada, e o tom sobre tom harmoniza sem disputar com o produto (posts 10 e 12). Evitar fundo de outra família de cor e fundo mais saturado que o sapato.
- **Capa de lançamento com wordmark.** Testar o wordmark Larroudé grande no topo com a data pequena em caixa-alta espaçada como capa de CAROUSEL de drop, seguida de slides com foto real. Isso já existe em lookbook BR (15136:210), e a data cria urgência elegante (post 01). Evitar capa só de texto num ad de conversão: aplicar sobre foto ou usar como slide 1 no orgânico.

## Aplicabilidade
- **Alta** para o tom sobre tom.
- **Média** para a capa tipográfica.

## Limite (não trazer)
- Peça 100% tipográfica sem foto num ad.
- Feed sem calçado.
- Universo de café e perfume sem produto.

## Confiança
Média. O padrão de cor é claro em 12 capas. O grupo atribuído é uma inferência minha.

## Limites da coleta
Miniaturas de 640px (grid público). A versão em alta (~1080px) depende de acesso logado. Não abri os carrosséis nem li legendas, e não confirmei o selo visualmente.

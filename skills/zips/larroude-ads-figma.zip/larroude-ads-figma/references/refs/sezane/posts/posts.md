# sezane - 12 primeiros posts do grid público (observado em 2026-09-30, sem login)

Miniaturas do grid público: lado maior 640px (limite sem login; ~1080px só com acesso logado). Tipo inferido pelo ícone do grid; descrição = o que se vê na miniatura (capa do carrossel/reel, sem ver o interior). Ordem = ordem do grid.

| nº | link | tipo | data | resolução salva (px) | descrição visual |
|---|---|---|---|---|---|
| 01 | https://www.instagram.com/sezane/p/DcLPS05lweH/ | carrossel | 2026-08-18 (fora de ordem: provável fixado) | 512x640 | Capa tipográfica: SÉZANE em serifa alta preta sobre fundo branco; "AUGUST 23, 2026" pequeno, caixa-alta espaçada, na base. |
| 02 | https://www.instagram.com/sezane/reel/DdJh-43B6wE/ | reel | 2026-09-11 (provável fixado) | 360x640 | Fachada de loja haussmanniana em Paris, contra-plongée, céu azul. |
| 03 | https://www.instagram.com/sezane/p/Dd6hgAFDhLl/ | carrossel | 2026-09-30 | 512x640 | Detalhe de lenço estampado azul e off-white com logo SÉZANE, ao lado de bolsa cinza. |
| 04 | https://www.instagram.com/sezane/p/DcS0Whol7fj/ | carrossel | 2026-08-21 | 512x640 | Modelo de ombro à mostra, tricô verde-oliva oversized e pulseira dourada, olhar baixo, planta ao fundo. |
| 05 | https://www.instagram.com/sezane/p/DcQckGUFyP6/ | carrossel | 2026-08-20 | 512x640 | Bolsa de camurça caramelo vista de cima, pingente dourado de concha, fundo de tecido marrom. |
| 06 | https://www.instagram.com/sezane/p/DdQ_JeTl6Ux/ | carrossel | 2026-09-14 | 511x640 | Loja: araras com casacos e malhas em degradê terracota a amarelo, quadros na parede. |
| 07 | https://www.instagram.com/sezane/p/DcVYY-clwja/ | carrossel | 2026-08-22 | 512x640 | Lenços de seda estampados atados em nós (vermelho, marrom, creme), plano fechado. |
| 08 | https://www.instagram.com/sezane/p/DdCFDPhlxRR/ | carrossel | 2026-09-08 | 514x640 | Interior de café/livraria com madeira clara, prateleiras e balcão inox. |
| 09 | https://www.instagram.com/sezane/p/DdrBTP1F2bz/ | carrossel | 2026-09-24 | 514x640 | Duas modelos de tricô preto e creme com babado, enquadramento vertical cortado, fundo dourado. |
| 10 | https://www.instagram.com/sezane/p/Ddt17c1F_Gn/ | carrossel | 2026-09-25 | 512x640 | Perfil de modelo de coque baixo, tricô vermelho-ferrugem e lenço, fundo mostarda. |
| 11 | https://www.instagram.com/sezane/p/Ddn8GGsl0wP/ | carrossel | 2026-09-23 | 512x640 | Esboços de frascos do perfume L EAU SÉZANE em papel vegetal. |
| 12 | https://www.instagram.com/sezane/p/Dd3hWS4O6_v/ | foto | 2026-09-29 | 512x640 | Modelo de cardigã branco com rosas bordadas e cinto marrom, fundo verde-musgo. |

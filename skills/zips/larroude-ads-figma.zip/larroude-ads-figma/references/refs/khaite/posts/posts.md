# khaite - 12 primeiros posts do grid público (observado em 2026-09-30, sem login)

Miniaturas do grid público: lado maior 640px (limite sem login; ~1080px só com acesso logado). Tipo inferido pelo ícone do grid; descrição = o que se vê na miniatura (capa do carrossel/reel, sem ver o interior). Ordem = ordem do grid.

| nº | link | tipo | data | resolução salva (px) | descrição visual |
|---|---|---|---|---|---|
| 01 | https://www.instagram.com/khaite/reel/DdwLjK4R5Xe/ | reel | 2026-09-26 | 360x640 | Margem do Sena com outdoor gigante KHAITE na empena de um prédio; tons frios esverdeados. |
| 02 | https://www.instagram.com/khaite/p/DdrQ8K_kePg/ | carrossel | 2026-09-24 | 512x640 | Corpo inteiro: blusa de organza marfim com laço na cintura, cabelo curto, fundo cinza-claro liso. |
| 03 | https://www.instagram.com/khaite/p/DdosHgZkeNO/ | carrossel | 2026-09-23 | 512x640 | Close de rosto com cabelo volumoso e batom vermelho sobre fundo claro. |
| 04 | https://www.instagram.com/khaite/p/DdmXxjym9K6/ | carrossel | 2026-09-22 | 512x640 | Detalhe macro de bolsa em couro croco preto com fecho dourado canelado. |
| 05 | https://www.instagram.com/khaite/p/DdmW45om85P/ | carrossel | 2026-09-22 | 512x640 | Modelo de cabelo volumoso escuro, óculos escuros e jaqueta de couro preta cropped; fundo cinza-azulado. |
| 06 | https://www.instagram.com/khaite/p/DdmV40fm_GM/ | carrossel | 2026-09-22 | 512x640 | Retrato fechado de mulher de cabelo preto, blazer creme com botões grandes. |
| 07 | https://www.instagram.com/khaite/p/DdeJACsEQDg/ | carrossel | 2026-09-19 | 512x640 | Recorte sem rosto: corpete floral bordado sob cabelo loiro sobre o ombro. |
| 08 | https://www.instagram.com/khaite/p/DdeHlJ6EQ45/ | carrossel | 2026-09-19 | 512x640 | Modelo de rabo de cavalo, top floral transparente com gola preta; fundo cinza-azulado. |
| 09 | https://www.instagram.com/khaite/p/DdeFrdbEc0g/ | carrossel | 2026-09-19 | 512x640 | Modelo cacheada de top floral transparente com bolsa croco preta, enquadramento baixo. |
| 10 | https://www.instagram.com/khaite/reel/DdZuIfdTFrr/ | reel | 2026-09-17 | 512x640 | Passarela/backstage escuro: vestido cinza cortado com bolsa preta. |
| 11 | https://www.instagram.com/khaite/reel/DdY6p2DxAN3/ | reel | 2026-09-17 | 512x640 | Passarela: modelo loira de cabelo esvoaçante, top branco e saia de couro, plateia desfocada. |
| 12 | https://www.instagram.com/khaite/reel/DdXcIezxFOb/ | reel | 2026-09-16 | 512x640 | Modelo de casaco escuro com recorte brilhante, luz lateral, fundo preto. |

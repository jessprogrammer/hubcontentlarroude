# Khaite

Khaite · runway · @khaite (https://www.instagram.com/khaite/, 919 mil seguidores, segue 1 conta, link khaite.com) · observado em 2026-09-30 · fonte: grid público sem login (12 primeiros posts)

## Leitura dos posts
- **Formatos:** 8 carrosséis e 4 reels. Os reels são de desfile/backstage (SS27) e do outdoor em Paris.
- **Composição:** foto única, enquadramentos fechados (rosto, ombro, detalhe de couro croco) e corpo inteiro sobre fundo liso cinza-claro ou cinza-azulado. Há recortes sem rosto (post 07). Bolsas aparecem em macro (post 04). Não vi nenhum calçado nos 12.
- **Tipografia/texto:** nenhum texto sobre a imagem no grid.
- **Cor:** neutros frios (cinza-azulado, marfim, preto), com um único acento por imagem: batom vermelho, floral ou dourado do fecho.
- **Ritmo:** blocos de 3 posts do mesmo dia (22/09 e 19/09) formam uma "linha" do grid com a mesma luz e o mesmo fundo. Feed muito consistente.
- **Modelo, still ou ambiente:** a maioria é modelo em estúdio, mais 1 still macro e 1 ambiente urbano (outdoor).

## O que aprender
1. **Fundo liso frio e um acento quente:** a imagem respira e o produto ou o detalhe vira o único ponto de cor.
2. **Macro de textura** (croco e metal) como post autônomo: o material comunica luxo sozinho.
3. **Postar em trios** com a mesma luz para fechar uma linha coesa do grid.
4. **Mídia exterior reaproveitada** (outdoor) como prova de escala da marca.

## Base "nossa" usada para filtrar
Estudo de layouts Larroudé (ADS US/BR, 2026-09-30) e regras da liderança. Os pontos são:
- foto real liderando, com o produto em destaque e inteiro (bico e salto);
- foto única full-bleed em cerca de metade das peças;
- 1:1 hero com foto mais alta que o frame e título no rodapé;
- hero com tira de detalhes do mesmo produto;
- colagem de até 3 fotos do mesmo storytelling ou fundo, coladas, sem listra branca e sem "cara de PowerPoint";
- títulos curtos (≤30 caracteres) em Platform, Items ou Very Vogue;
- name-card "Bota X" ao lado do produto;
- cores chapadas da paleta;
- sem selos ou carimbos em volta do logo.

A referência é uma opção para inovar, nunca uma regra.

## Quando usar / quando não usar
- Linhas premium e texturas (verniz, croco, metal).
- Não usar o tom frio como padrão: contraria a paleta viva da marca.

## Sugestões
- **Macro de material.** Testar verniz, croco ou o salto como 1 das miniaturas do layout hero com tira de detalhes (mesmo produto e mesma sessão), ou como slide de detalhe num CAROUSEL PRODUCT-DETAILS. O layout já existe (20391:652) e a macro reforça qualidade (post 04). Evitar a macro como peça única de performance sem mostrar o sapato inteiro.
- **Trio da mesma sessão.** Testar 3 fotos com a mesma luz e o mesmo fundo num carrossel de 3 slides ON-FOOT. Respeita o "mesmo storytelling" e dá coesão. Evitar misturar estúdio, rua e packshot no mesmo trio.

## Aplicabilidade
**Média.** A macro e a coesão servem; o tom frio e a ausência de calçado no feed reduzem o uso direto.

## Limite (não trazer)
- Retratos de rosto ou de roupa sem calçado.
- Paleta fria e apagada como linguagem geral.
- Conteúdo de passarela.

## Confiança
Média-alta para o tom visual (padrão muito repetido). Baixa para o uso de calçado, porque nenhum apareceu.

## Limites da coleta
Miniaturas de cerca de 640px no lado maior (grid público). A versão em alta (~1080px) depende de acesso logado. Não abri carrosséis (pode haver calçado nos slides internos), não li legendas e não confirmei o selo de verificação visualmente.

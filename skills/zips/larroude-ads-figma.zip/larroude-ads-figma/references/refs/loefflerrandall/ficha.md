# Loeffler Randall

Loeffler Randall · concorrente direto (calçado e acessório, NY) · @loefflerrandall (https://www.instagram.com/loefflerrandall/, 433 mil seguidores, link loefflerrandall.com) · observado em 2026-09-30 · fonte: grid público sem login (12 primeiros posts)

## Leitura dos posts
- **Formatos:** 7 carrosséis, 3 reels e 2 fotos.
- **Composição:** a variedade é grande. Há 2 flat lays de cima (look completo com botas; botas e mocassins espalhados em grade solta sobre branco), close de botas croco com saia amarelo-limão sobre piso terracota, modelo em paisagem (deserto, celeiro com feno), P&B de noivos e uma composição duplicada (a mesma modelo em dois andares de motel). Calçado visível em cerca de 7 dos 12.
- **Tipografia/texto:** um reel tem data em serifa clara ("September 22nd") sobre a foto, e outro é uma ilustração aquarelada da loja.
- **Cor:** quente e artesanal: azul-denim, terracota, creme e marrom, com amarelo-limão como acento.
- **Ritmo:** feed de fundadora: produto, lifestyle, bridal, UGC (selfie de espelho) e loja. É coeso pela cor, não pelo formato.
- **Modelo, still ou ambiente:** cerca de 6 com modelo, 3 stills/flat lays e 3 de ilustração ou bastidor.

## O que aprender
1. **Flat lay de look completo com a bota no pé da composição:** vende o sapato dentro de um outfit.
2. **Grade solta de vários pares** sobre fundo branco: mostra a família de produto num único quadro.
3. **Close de pernas com cor de saia e de chão em contraste** (limão e terracota) para destacar a textura da bota.
4. **Repetição da mesma modelo no quadro** (composição duplicada) como recurso lúdico.

## Base "nossa" usada para filtrar
Estudo de layouts Larroudé (ADS US/BR, 2026-09-30) e regras da liderança. Os pontos são:
- foto real liderando, com o produto em destaque e inteiro (bico e salto);
- foto única full-bleed em cerca de metade das peças;
- 1:1 hero com foto mais alta que o frame e título no rodapé;
- hero com tira de detalhes do mesmo produto;
- colagem de até 3 fotos do mesmo storytelling ou fundo, coladas, sem listra branca e sem "cara de PowerPoint";
- títulos curtos (≤30 caracteres) em Platform, Items ou Very Vogue;
- name-card "Bota X" ao lado do produto;
- cores chapadas da paleta;
- sem selos ou carimbos em volta do logo.

A referência é uma opção para inovar, nunca uma regra.

## Quando usar / quando não usar
- Anúncio de categoria (botas da estação), look e cross-sell.
- Não usar flat lay quando o sapato fica pequeno.

## Sugestões
- **Close de pernas com contraste de cor.** Testar o close com a cor da saia e do chão em contraste (bota mais saia de cor viva mais piso colorido) em STATIC 1:1 ON-FOOT hero (foto mais alta que o frame, calçado no terço inferior, título no rodapé). É exatamente o crop 1:1 da casa, com mais cor (post 03). Evitar cortar o pé: corta-se o cano.
- **Flat lay de look.** Testar o look completo com o sapato maior no terço inferior em STATIC 1:1 PRODUCT-MIX, sobre fundo de cor da paleta (não branco). Mostra o sapato dentro do outfit (post 01). Evitar o flat lay em que o sapato fica do tamanho das outras peças.
- **Família de pares.** Mostrar vários pares só numa foto única fotografada junta. Evitar montar uma grade com fotos separadas: fere a regra de colagem.

## Aplicabilidade
**Alta.** É a referência mais próxima do negócio e do padrão da casa.

## Limite (não trazer)
- Grade de vários modelos montada a partir de fotos diferentes.
- Ilustração ou diorama.
- Selfie de espelho de baixa qualidade.
- Composição duplicada da mesma modelo, que parece montagem.

## Confiança
Média. É a mais próxima do negócio Larroudé entre as observadas.

## Limites da coleta
Miniaturas de 640px (grid público). A versão em alta (~1080px) depende de acesso logado. Não abri carrosséis nem reels e não li legendas.

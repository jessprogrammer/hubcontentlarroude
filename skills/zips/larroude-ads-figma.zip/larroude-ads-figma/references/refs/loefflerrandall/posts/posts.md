# loefflerrandall - 12 primeiros posts do grid público (observado em 2026-09-30, sem login)

Miniaturas do grid público: lado maior 640px (limite sem login; ~1080px só com acesso logado). Tipo inferido pelo ícone do grid; descrição = o que se vê na miniatura (capa do carrossel/reel, sem ver o interior). Ordem = ordem do grid.

| nº | link | tipo | data | resolução salva (px) | descrição visual |
|---|---|---|---|---|---|
| 01 | https://www.instagram.com/loefflerrandall/p/Dd7N8eGBDoT/ | foto | 2026-09-30 | 512x640 | Flat lay de cima: cardigã azul bordado, jeans cinza e botas pretas de bico, fundo claro. |
| 02 | https://www.instagram.com/loefflerrandall/p/Dd4I3mjHNKw/ | carrossel | 2026-09-29 | 512x640 | Mulher de vestido de tricô branco e botas marrons em paisagem de deserto, céu azul; foto com margem clara fina. |
| 03 | https://www.instagram.com/loefflerrandall/p/Dd2LhhYmjAn/ | carrossel | 2026-09-28 | 480x640 | Close de botas de cano alto em couro croco preto, saia amarelo-limão, piso de terracota laranja. |
| 04 | https://www.instagram.com/loefflerrandall/p/Ddza416Gm3L/ | carrossel | 2026-09-27 | 480x640 | Foto P&B de casal de noivos junto a carro antigo (linha Bridal). |
| 05 | https://www.instagram.com/loefflerrandall/p/DdwlbWgxCxI/ | foto | 2026-09-26 | 512x640 | Flat lay de botas e mocassins de sola tratorada marrons e pretos sobre fundo branco, em grade solta. |
| 06 | https://www.instagram.com/loefflerrandall/p/DdpGB-Jmolk/ | carrossel | 2026-09-23 | 512x640 | Modelo sentada em fardos de feno, cardigã azul, jeans e botas pretas; celeiro. |
| 07 | https://www.instagram.com/loefflerrandall/p/Ddt2vaGnHj6/ | carrossel | 2026-09-25 | 480x640 | Calça bege com bordado azul dobrada, vista de cima, fundo claro (roupa). |
| 08 | https://www.instagram.com/loefflerrandall/p/Ddl-Q8enD0D/ | carrossel | 2026-09-22 | 510x640 | Modelo de saia branca com bainha rendada e botas marrons no deserto, sol forte. |
| 09 | https://www.instagram.com/loefflerrandall/reel/DdkIevmguaV/ | reel | 2026-09-21 | 360x640 | Close de modelo de cardigã azul com texto "September 22nd" sobreposto em serifa clara, foco suave. |
| 10 | https://www.instagram.com/loefflerrandall/reel/Ddhr5KYgp90/ | reel | 2026-09-20 | 360x640 | Miniatura/diorama aquarelado da loja (Crosby Street) nas mãos; ilustração floral. |
| 11 | https://www.instagram.com/loefflerrandall/p/DdfH94bmuXD/ | carrossel | 2026-09-19 | 512x640 | Mesma modelo em dois andares de um motel (composição duplicada), blusa verde e saia listrada. |
| 12 | https://www.instagram.com/loefflerrandall/reel/DdZVnrOyvsi/ | reel | 2026-09-17 | 361x640 | Selfie de espelho: suéter cinza, calça de bolinhas, sapatos pretos. |

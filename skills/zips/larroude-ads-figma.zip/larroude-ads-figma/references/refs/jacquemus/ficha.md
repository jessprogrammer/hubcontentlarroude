# Jacquemus

Jacquemus · runway · @jacquemus (https://www.instagram.com/jacquemus/, 6,8 mi seguidores, link jacquemus.com na bio) · observado em 2026-09-30 · fonte: grid público sem login (12 primeiros posts)

## Leitura dos posts
- **Formatos:** 8 carrosséis, 3 reels, 1 foto. Dois posts são colab com @simon_porte_jacquemus (perfil do fundador). Um post de nov/2025 aparece entre os de setembro, provavelmente fixado.
- **Composição:** foto única por post, sem colagem no grid. Alterna planos abertos com muito céu e parede lisa (Miami, terraço, fachada da loja) com recortes muito fechados (pernas pedalando, taça sobre toalha). O produto costuma estar "no meio da vida", sem pose de catálogo. O calçado aparece por acidente (sandálias, tênis), exceto no post 07, que é um recorte de tênis em ação.
- **Tipografia/texto:** quase nenhum. Quando há texto, é só o logotipo branco centralizado sobre o vídeo (reels 11 e 12). Nada de preço ou chamada.
- **Cor:** paleta solar e lúdica: azul-turquesa, rosa, amarelo e branco, com cor chapada em parede ou objeto. Há um P&B pontual (post 09).
- **Ritmo:** mistura de editorial, bastidor/street style, natureza-morta, loja e cenas-poema (burro, pescador). A coesão vem do humor e da luz, não da repetição de formato.
- **Modelo, still ou ambiente:** cerca de metade com pessoas (candid), um terço de ambiente ou objeto, quase nenhum still de produto isolado.

## O que aprender
1. **Recorte de ação sobre cor chapada** (post 07): o calçado vira personagem sem precisar de rosto, só o pé num gesto com uma cor dominante.
2. **Cor gráfica do cenário** (post 06): círculo rosa na parede branca e a roupa no mesmo tom de acento. A diagramação vem da própria foto, não de elementos adicionados.
3. **Logotipo pequeno e centralizado sobre a cena** como única tipografia (reels 11 e 12).
4. **Natureza-morta com objeto do cotidiano** (taça e prato) para criar universo de marca entre um post de produto e outro.

## Base "nossa" usada para filtrar
Estudo de layouts Larroudé (ADS US/BR, 2026-09-30) e regras da liderança. Os pontos são:
- foto real liderando, com o produto em destaque e inteiro (bico e salto);
- foto única full-bleed em cerca de metade das peças;
- 1:1 hero com foto mais alta que o frame e título no rodapé;
- hero com tira de detalhes do mesmo produto;
- colagem de até 3 fotos do mesmo storytelling ou fundo, coladas, sem listra branca e sem "cara de PowerPoint";
- títulos curtos (≤30 caracteres) em Platform, Items ou Very Vogue;
- name-card "Bota X" ao lado do produto;
- cores chapadas da paleta;
- sem selos ou carimbos em volta do logo.

A referência é uma opção para inovar, nunca uma regra.

## Quando usar / quando não usar
- Awareness, lançamento de cor ou estação.
- Não usar como está em ads de conversão: lá o produto quase nunca lidera.

## Sugestões
- **Recorte de pé em ação.** Testar o gesto (pedalar, subir degrau, atravessar a faixa) em STATIC 9:16 ON-FOOT, foto única full-bleed, só com o wordmark branco ou um título Platform curto. O formato já é o mais usado na casa e o gesto acrescenta história sem tirar o produto do centro (post 07). Evitar o recorte que corta bico ou salto e a foto em que o pé fica pequeno no quadro.
- **Cenário de cor chapada.** Testar parede ou chão real numa cor da paleta (rosa, azul, lilás), com o sapato no mesmo tom ou em contraste, em STATIC 1:1 hero (foto mais alta que o frame, título no rodapé). A cor vem da foto, não de fundo aplicado no layout (post 06). Evitar faixa ou painel de cor artificial para "esticar" a foto.

## Aplicabilidade
- **Alta** para o recorte de ação e a cor de cenário: encaixam na foto única e no hero 1:1 da casa.
- **Baixa** para o resto do feed: sem produto.

## Limite (não trazer)
- Posts sem calçado: cenas-poema com burro ou pescador, natureza-morta, fachada de loja.
- Logo grande centralizado como único elemento sobre uma cena sem produto.
- Street style em que o sapato aparece por acaso.

## Confiança
Média. Vi 12 capas e reconheço um padrão claro de tom, mas não abri nenhum carrossel nem reel.

## Limites da coleta
As miniaturas do grid público têm cerca de 640px no lado maior; a versão em alta (~1080px) depende de acesso logado. Não vi o interior dos carrosséis nem o áudio e a edição dos reels, legendas não foram lidas e a verificação (selo) não foi confirmada visualmente: o @ foi escolhido por seguidores e link do site na bio.

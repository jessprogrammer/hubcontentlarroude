# jacquemus - 12 primeiros posts do grid público (observado em 2026-09-30, sem login)

Miniaturas do grid público: lado maior 640px (limite sem login; ~1080px só com acesso logado). Tipo inferido pelo ícone do grid; descrição = o que se vê na miniatura (capa do carrossel/reel, sem ver o interior). Ordem = ordem do grid.

| nº | link | tipo | data | resolução salva (px) | descrição visual |
|---|---|---|---|---|---|
| 01 | https://www.instagram.com/jacquemus/reel/Ddoo-a8o2WM/ | reel | 2026-09-23 | 360x640 | Cena de rua candid: mulher de vestido branco com cinto preto entre dois homens de terno empurrando carrinhos de bebê; luz do dia, sem produto em foco. |
| 02 | https://www.instagram.com/jacquemus/p/Dd4Q0ONkR8T/ | carrossel | 2026-09-29 | 512x640 | Modelo de vestido de bolinhas com babado e bolsa amarela em terraço de Miami, sandália de salto fino visível, céu azul e prédios ao fundo. |
| 03 | https://www.instagram.com/jacquemus/p/Ddg-2wQiH0v/ | carrossel | 2026-09-20 | 480x640 | Street style: mulher de blazer e saia marrons, óculos escuros, sandália de salto, na calçada com fotógrafos ao fundo. |
| 04 | https://www.instagram.com/jacquemus/p/DdUNBBxiPi6/ | carrossel | 2026-09-15 | 512x640 | Fachada da loja Jacquemus (Miami) com árvore em primeiro plano, arquitetura clara e céu limpo. |
| 05 | https://www.instagram.com/jacquemus/p/DQ9ssiTiCKz/ | carrossel | 2025-11-12 (fora de ordem: provável fixado) | 480x640 | Duas mulheres de vestido preto ao espelho num banheiro rosa clássico; bolsa rosa em destaque. |
| 06 | https://www.instagram.com/jacquemus/p/DdjVemjiIMu/ | carrossel | 2026-09-21 | 480x640 | Mulher de macacão azul-turquesa em bicicleta diante de parede branca com círculo rosa e placa; composição gráfica, muito respiro. |
| 07 | https://www.instagram.com/jacquemus/p/DdZSae6In9P/ | foto | 2026-09-17 | 512x640 | Recorte fechado de pernas pedalando bicicleta cromada; tênis azul-água com meia branca em primeiro plano (calçado em ação, sem rosto). |
| 08 | https://www.instagram.com/simon_porte_jacquemus/p/Dcys47CiAY2/ | carrossel (colab do perfil do fundador) | 2026-09-02 | 480x640 | Natureza-morta: taça de água com gás sobre toalha rosa e borda de prato azul com peixe. |
| 09 | https://www.instagram.com/jacquemus/p/Dc5lmnhEcMe/ | carrossel | 2026-09-05 | 480x640 | Retrato P&B de homem de terno em pose teatral, fundo cinza. |
| 10 | https://www.instagram.com/simon_porte_jacquemus/p/DcizCcqiOxW/ | carrossel (colab do perfil do fundador) | 2026-08-27 | 512x640 | Dois homens de terno (azul-marinho e creme) apoiados em carro antigo, campo e nuvens ao fundo. |
| 11 | https://www.instagram.com/jacquemus/reel/DbdTTqvoL5m/ | reel | 2026-07-31 | 360x640 | Burro em rua de vilarejo italiano com prédio amarelo; logotipo JACQUEMUS branco sobreposto no centro. |
| 12 | https://www.instagram.com/jacquemus/reel/DcDn1udxfqL/ | reel | 2026-08-15 | 360x640 | Silhueta de pescador com vara contra pôr do sol laranja; logotipo branco centralizado. |

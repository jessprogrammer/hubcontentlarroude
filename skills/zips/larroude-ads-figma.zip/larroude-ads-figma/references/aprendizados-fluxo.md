---
name: larroude-ads-flow-corrections
description: Pietro 01/10 corrections to the ADS creation flow — never clone the last job, use APPROVED + base library, photo by beauty, black text only on pure white/light, fixed rules checklist
metadata:
  type: feedback
---

Pietro's corrections after the New Drop 07/10 test (01/10/2026). These are firm.

1. **NEVER copy the previous/last job as the base.** It may be unfinished, and that is not the flow we structured. Read only the current task, not earlier tasks of the same collection.
   - Base = the **APPROVED LAYOUTS** category, then the V/Q/H base library on the "Claude Padrões ADS" page.
   - Test the text application on those bases.
2. **Pick the photo by beauty first.** The first piece / cover must be the most eye-catching. Do NOT pick photos by "space for copy". Adapt the copy to the photo.
3. **Black text ONLY on white or light background, with nothing else sharing that space.** Everything else gets white text. It's a quick judgment, not a big analysis. Colour may differ per format.
4. **Fixed rules must be followed every time** (Pietro: "a robot not following its own operating laws"). Before building, run the fixed-rules checklist. Carousel: title/copy only on card 1, all other cards logo-only.
5. Air search paths: calculate the path once and keep it in the scripts/map; keep searches small.
6. **Team rollout:** tell each person to allow the permissions (Figma download/export, Air upload, Asana comment) when the flow reaches that step.
7. Learning from adjustments (before/after): keep it lightweight.

**Why:** the test lost time because I cloned the 30.09 job (unfinished) and ignored the fixed carousel rule.
**How to apply:** for every ADS task:
1. Fixed-rules checklist.
2. Choose the APPROVED category and V/Q/H base per format.
3. Choose the most beautiful photos.
4. Place the copy using the rule in item 3.
5. Build once, one QA pass, deliver.

Related: [[larroude-pattern-library]], [[larroude-qa-loop]], [[larroude-delivery-air-folders]].

**Colour rule refined (Pietro 01/10):** if the art is predominantly DARK or high-contrast (not so light) and has no white background, text AND logo are white. Black only when the copy/logo sits on white or on a clearly light colour, with nothing else sharing that space.

**Logo rules (Pietro 01/10, firm):**
- The Larroudé wordmark is never all one colour. The accent (é) is ALWAYS pink. Recolour only the letters (black/white) and keep the accent vector's pink.
- When there is a logo, it is the SAME size on every card/piece of the same format (e.g. every 1080x1920 the same width, every 1200x1200 the same, every 628 the same).

**Pietro's adjustments on New Drop v2 (01/10). Lightweight before/after, learned:**
- **Static copy:** moved off the corner into the body of the image, over the product's calmer mass. Lockup left-aligned, logo right under the subline.
  - 1920: title y≈700.
  - 1200: title ≈(260,490).
  - 628 diptych: copy goes on the DETAIL half (right), not on the full photo.
- **Carousel cover:** copy aligned to the side with space. 1920 = bottom-RIGHT, right-aligned. 1200/628 = top-left.
- **Logo-only cards:** wordmark mostly bottom-centred at a constant y per format (1920 y≈1690, 1200 y≈1080). Centred only when the middle is the calm/strong zone. On 628 it goes to whichever corner is calm (bottom-left or top-right).

## Stories orgânicos: ajustes do Pietro (06/10/2026)
- **Texto sobre a foto, nunca acima dela.** A foto fica em tela cheia (recorte fechado) e o texto vai na área calma da própria foto. Meça essa área com `scripts/python/area_vazia.py`. Se não houver área livre na zona segura, troque a foto.
- **Em sequências (stories/carrossel), cada tela responde à própria foto.**
  - Use coluna de texto estreita, de 340 a 460 px, alternando o lado entre as telas.
  - Posicione a polaroid ou a foto secundária pela composição, não num canto fixo.
- **Tela de modelo ou família (formato aprovado no Bardot, New Arrivals):**
  - "meet the" em Plain Light 40, no alto à esquerda;
  - nome em Platform 110, em 2 linhas, logo abaixo;
  - a linha curta em Plain Light 30, do lado oposto, alinhada à direita e na altura do "meet the".
- **Cartão de personagem (Silhouette Study):** cartão de 836 px com margem colorida.
  - Em cima, a foto editorial.
  - Embaixo, base #F6F6F6 com "the" pequeno + nome em Blitz Script à esquerda, o mood pequeno à direita e o produto inteiro centralizado.
  - Capa e tela final mantêm o layout de foto em tela cheia: quando ele pedir para trocar, troque só a foto.
- **GIF de variantes:** produto na mesma escala e linha de base em todos os quadros, com o nome da cor trocando junto. No estado estático, só o primeiro quadro fica visível.
- **Onde montar:** na última coluna do segmento certo da página Stories, abaixo da fileira mais recente. Não abra um bloco novo em outro lugar.
- **Extensão ou expansão de imagem:** sempre perguntar antes.
- **Ao refazer uma peça:** mostre antes a folha com as opções de foto e o plano tela a tela.

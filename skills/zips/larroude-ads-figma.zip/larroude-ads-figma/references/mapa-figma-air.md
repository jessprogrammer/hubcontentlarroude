# Mapa · Figma + Air (onde fica cada coisa)
Levantado em 01/10/2026. Arquivo Figma: FIGMA ZAINERS NOVO (DRphNBA9HvgZ6HwazNMHrm). Coordenadas aproximadas (x, y do canvas); confira com o script do fim antes de criar.

## 1. Figma

### Como as páginas orgânicas se organizam
- Cada **seção** tem um título grande (Plain/Platform ~1000px em Stories, ~437px em Feed).
- Embaixo do título há **colunas acumuladas** (sub-colunas). Cada tarefa é uma **linha** de artboards lado a lado (capa, 02, 03…), e as tarefas novas descem dentro da coluna.
- Quando uma coluna fica longa demais, alguém abre uma nova coluna à direita. **A tarefa nova vai embaixo da última tarefa da coluna mais recente (a mais à direita)**, a menos que a pessoa que pediu indique outro lugar (ex.: "abaixo da Markarian, 3ª coluna").
- Antes de criar: rode o script do §1.4 para achar o "bottom" atual e comece ~400px abaixo, alinhado ao x da coluna.

### 1.1 Stories (página 188:214)
Título da página "STORIES" em -129572, -129764. "Bottom" = y do fim da última peça.

| Seção | Título (x, y) | Colunas (x) · peça mais recente/embaixo |
|---|---|---|
| Why we like it | -129478, -126138 | -129600 · bottom -94091 |
| Categories | -107089, -127172 | -107600 / -89200 · "Stories_KatiePump" bottom -44750 |
| Hot Girls in Larroude | -82816, -129996 | -82800…-31000 · "Hot Girls Nicolo B" bottom -115390 |
| New Arrivals \| New Drop | -22243, -128478 | 4 colunas: -22200, -6200, 13800, **27000…52600** (NewArrivalsDROP26Ago, bottom -84428) |
| SHOE INSPO | -130080, -85572 | -130600 / **-117000** (bottom -50399) |
| POP CULTURE | -45030, -79225 | -45600 / **-33800** (10.01 Nicolo B, bottom -19793) |
| interactive pool · This or That · Quiz | -4639, -80091 | A -4400 · B 6200 · **C 14800** (Which Nicolò Are You, bottom -49120) |
| City guides | 45847, -82376 | 47200 / **63000** (Hamptons, bottom -65821) |
| Dressing Guide | -130091, -38933 | -130000 · -119600 · **-110600** (Nicolò B. Drop 3, bottom -11364) |
| Press Recap | -88715, -37999 | -88800 · bottom -23683 |
| BRAND CAROUSEL | -65420, -39849 | -65400 / **-50200** (bottom -9936) |
| Trend Report | -4701, -42535 | -4800 · bottom -10093 (Brocade Effect) |
| Shop by Color | 17969, -42692 | 17800 / **36000** (10.01 Burgundy Report, bottom -18397) |
| Shop by PRINT | 55253, -42563 | 55200 · bottom -31779 |
| Transitional Season | -87122, -1247 | -87200 / -73200 · bottom ~50000 |
| extras / aleatórios | -65100, -4080 | -65400 · -50000 · -39000 · -30400 |
| Breakdown / ABC stories | -111617, 1655 | -111400 · bottom 31729 |
| Meet our Muse | -130470, 1801 | -130400 · bottom 15254 |
| HOLIDAY 2025 | -129825, 22040 | -129800 / -117600 |
| Weekend Rush | -102792, 22998 | -102600 · bottom 52771 |
| Marina's Picks | -47718, 23061 | -47600 · bottom 31915 |
| BLOG Recap | -34797, 22810 | -34800 · bottom 31565 |
| REVIEW | -47451, 38506 | -47400…-39800 |
| Signs | -114595, 58330 | -114600 · bottom 64897 |
| SPOTTED / bts shooting | -103470, 57828 | -103400 |
| FAQ | -84678, 57585 | -84600 · bottom 65748 |
| AMAZON LUXURY | -129689, 58364 | -129600 |
| new layout · teste | -120439, 76009 | testes, não é entrega |

### 1.2 Feed (página 1894:2)
Título "FEED" em -126938, -4630. Linha de cima (y ≈ -800) e linha de baixo (y ≈ 20700–32600).

| Seção | Título (x, y) | Coluna · mais recente/embaixo |
|---|---|---|
| BRAND CAROUSEL | -126896, -741 | bottom 17631 |
| Collab posts | -114416, -808 | bottom 60093 (Feed_NicoloB.) |
| Hot Girls | -99319, -808 | bottom 67654 |
| Aplicação de Logo | -78074, -711 | bottom 43181 (Loulou Boot 29.09) |
| Grids | -64325, -713 | bottom 22570 |
| Shop the look grid | -53824, -651 | 10.01 Shop the look grid |
| Polaroids | -45712, -651 | bottom 10395 |
| Trend Report | -36748, -808 | bottom 16178 |
| DRESSING GUIDE | -19256, -808 | bottom 9011 |
| TRAVEL GUIDE | -10290, -808 | bottom 3814 |
| GIFT GUIDE | -722, -808 | bottom 30077 |
| Quote | 7014, -1056 | bottom 6818 |
| Weekend Rush | 7014, 8429 | — |
| black friday | 7014, 14901 | — |
| HOT BOYS | 19986, -1227 | bottom 28935 |
| highlights | 40735, -1056 | capas de destaque |
| CAROUSEL | -50278, 20703 | bottom 27020 |
| Why we like it | -50278, 30266 | — |
| Silhouette | -37850, 20703 | — |
| Copy overlay | -37892, 28208 | — |
| Product Detail | -37719, 32580 | — |
| MEMES | -37719, 37380 | — |
| Press Recap | -28401, 20703 | bottom 52418 |
| Aleatórios | -17309, 20703 | bottom 52418 |
| VALENTINES DAY | -4736, 32380 | — |
| HARVARD | 5055, 32380 | — |
| "não usar!" | 433, 24061 | **não usar** |

### 1.3 ADS (US e BR)
- Tarefa nova: **à direita, abaixo ou ao lado da última carreira de ads**, em colunas de **2 em 2 tarefas** (padrão atual): a coluna tem 2 tarefas empilhadas; a 3ª tarefa abre uma coluna nova à direita.
- Cada tarefa: marcador de texto "DD.MM - [ADS US] Nome", versões do mesmo tamanho lado a lado, tamanhos diferentes embaixo.
- Última referência (01/10): marcador "01.10 - [ADS US] UGC Kirstin Pump" em 65825, -91000.

### 1.4 Script: achar o próximo espaço livre de uma seção
```js
// use_figma (somente leitura). Troque PAGE_ID e LABEL.
const PAGE_ID='188:214', LABEL='Dressing Guide';
const page=await figma.getNodeByIdAsync(PAGE_ID); await figma.setCurrentPageAsync(page);
const labels=page.children.filter(n=>n.type==='TEXT'&&n.fontSize>=400&&n.fontSize<1500);
const frames=page.children.filter(n=>['FRAME','GROUP','COMPONENT','INSTANCE'].includes(n.type));
const own=frames.filter(f=>{let best=null,bs=1e12;for(const L of labels){if(L.x-600>f.x||L.y-600>f.y)continue;const s=(f.x-L.x)+(f.y-L.y)*0.5;if(s<bs){bs=s;best=L;}}return best&&best.characters.trim()===LABEL;});
const cols={};for(const f of own){const k=Math.round(f.x/200)*200;(cols[k]=cols[k]||[]).push(f);}
const res=Object.keys(cols).map(Number).sort((a,b)=>a-b).map(k=>{const b=cols[k].reduce((a,c)=>c.y+c.height>a.y+a.height?c:a);return {x:k,n:cols[k].length,bottom:Math.round(b.y+b.height),last:b.name.replace(/[^\x20-\x7E]/g,'')};});
return res; // nova tarefa: x da coluna mais recente, y = bottom + 400
```
A atribuição por seção é heurística (título mais próximo acima/à esquerda). Peças soltas podem cair na seção errada; olhe o resultado antes de criar.

## 2. Air (fotos)

### 2.1 Pastas raiz de produto
| Pasta | ID | O que tem |
|---|---|---|
| **DROPS** | ae56b098 | Uma subpasta por **modelo** (HYDRA, FUZZY, HARPER, ANNE, FREDDIE, VALENTINA, SABINE, HAILEY, ALICIA, CAMBON, GINNY, LUNA, TABI, ALEXIS, KATIE, JERSEY, BARDOT, IVY, KRIS, RICKY, FRANCA, DEW DROP, CHER, LUMA, ELLE, CARMEN, JETTY, FREYA, LOULOU, LINDA, JOLENE, PLUME, VERONICA, ROXY, VALERIE, MADISON, PAVLOVA, DAPHNE, SOPHIA, PATTI, AMALFI, TALITHA, MARIA… 147 no total) + especiais: **FALL 26** (7c0be88d: DROP 1–4, FALL ROTATION 1ef930ab), **1_EXTRAS FOR ADS** (9887bd56), MATERIAL ESTOQUE, RIO SHOOT, 4TH OF JULY, CHINESE NEW YEAR |
| **CONTENT** | 2aadec41 | Conteúdo social e de creators (96 subpastas): **UGC - NYC** (ddce1060), **UGC FOR ADS** (63741dbf), **Partnership Ad UGC** (f888780d), **PARTNERSHIP ADS UGC BRASIL** (a5271842), KENNETH RAPID FIRE / MARINA UGC (dc71d3aa), **Influencers - Best Sellers** (20e1a93e), 2026 SOCIAL CONTENT, Brand Trip Influencer Content, UNBOXING, WEEKEND RUSH, Press Recap, Marina's Looks, NEW ABC'S (1e70a697 › ABC'S US / ABC'S BR › 2026 › "Drop DD.MM" = material de cada drop para os stories ABC), **AI (DO NOT USE YET)** = não usar |
| **SPRING BY YEAR** | 73964992 | SPRING 21, 22, 23, 24, 25, SPRING |
| **HIGH SUMMER BY YEAR** | 512a7470 | HIGH SUMMER 21–25, BROOKS NADER CAMPAIGN |
| **FALL BY YEAR** | 1bf0d6d2 | FALL 21–26 (FALL 25: EDITED, CROP FOR PDP, WILDPOSTERING, video) |
| PRE-FALL BY YEAR | d4848813 | (existe também) |
| RESORT BY YEAR | 85e996b5 | (existe também) |
| **COLLABS** | 3e9fc90f | Uma pasta por parceiro: SERGIO HUDSON, BRUNO FRISONI, SHERIDAN COX, CIAO LUCIA, KENNETH COLE, TANNER FLETCHER, HARVARD, ANGELICA HICKS, **NICOLÓ BERETTA** (f3582876), PARKE, CANDY, MARKARIAN, LIBERTINE, MELISSA, OSCAR DE LA RENTA, LOVESHACKFANCY, JENNIFER FISHER… (29) |

Atalhos já usados: Collab Nicolò B. › 2026-2 = 0e55d45a (CAMPAIGN 8d522ca8, 2_STILL e164ecaa, 2_STILL_CLASSIC bcd9465f).

### 2.2 Dá para buscar sem abrir todas as pastas?
**Sim.** A busca por palavra-chave (`list_assets` com `search`) procura no nome do arquivo **e** no resumo automático da imagem. Duas formas:
1. **Busca com escopo:** `search="GROUP"` + `parentBoardId=<pasta raiz>` + `includeNestedAssets=true`. Procura só dentro daquela árvore (ex.: só DROPS), sem listar pasta por pasta.
2. **Busca pelo SKU ou modelo:** `search="L415-STEL"` ou `search="STELLA"`. É o caminho mais rápido quando o briefing traz SKU.

Limites: a busca semântica ("mulher sentada em café com bota marrom") está desligada no plano atual. Como a busca pega o resumo também, aparecem falsos positivos (ex.: "group" no resumo de um vídeo). Filtre pelo nome do arquivo.
Ordem recomendada: SKU/modelo → busca com escopo na raiz certa → só então navegar pastas.

### 2.3 Nomes específicos
**GROUP** = foto com **várias cores/versões do mesmo calçado** juntas (ótima para "available in X colors", carrossel de cores, capa de drop).
- Padrões de nome: `GROUP_<MODELO>_<VARIANTE> (n)` (ex.: `GROUP_VERONA_SHEARLING (1–15)`, `GROUP_CYRPUS_SHEARLING (1–6)`), `GROUP_<COLEÇÃO> (n)` (ex.: `GROUP_FALL (1–7)`) e `<MODELO>_GROUP (n)` (ex.: `STELLA_GROUP (1–6)`).
- Onde ficam: dentro de DROPS (ex.: GROUP_FALL em DROPS › FALL 26 › FALL ROTATION; STELLA_GROUP em "2_STILL CREATIVE" da pasta do modelo). Algumas cópias antigas também ficam em pastas WEBP.
- São arquivos grandes (5464×8192): use o imgix com `?w=2400` para montar e o original só na versão final.
- Busca: `search="GROUP_"` + `parentBoardId=ae56b098` (o `_` reduz falsos positivos).

**UGC** = material de creators/clientes (celular, luz natural), modelo recorrente de post e de ads "UGC".
- Arquivos brutos **não** têm "UGC" no nome (IMG_8469, Tezza-2452, DSC…). O que marca o UGC é a **pasta**: UGC - NYC, UGC FOR ADS, Partnership Ad UGC, PARTNERSHIP ADS UGC BRASIL, KENNETH RAPID FIRE / MARINA UGC, Influencers - Best Sellers. Vídeos: `Marina_ugc_<modelo>_vertical_captions`, `GABI UGC`.
- Peças finais de ADS com UGC levam `_UGC_` ou `_ON-FOOT-UGC_` no nome (ex.: `L415-STEL-MUSH-1939_STATIC_PRODUCT-AWARE_UGC_01`). Servem como referência do que já foi publicado e para **não repetir a mesma foto**.
- Busca: `search="<modelo>"` + `parentBoardId=2aadec41` (CONTENT) para brutos; `search="_UGC_"` em geral para peças finais.

### 2.4 Entrega (lembrete)
ADS: ADS › US|BR › 2026 › OCT 26 › 10.01 › <nome curto da tarefa>. Orgânico: Graphic Design › Social / Organic › 2026 › OCTOBER › STORIES|FEED|REELS › <MM.DD nome>. Só sobe depois da aprovação.

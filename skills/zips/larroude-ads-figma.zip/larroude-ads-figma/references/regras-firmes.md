# Regras firmes · checklist
**Status: APROVADO (01/10/2026).** Revisável a qualquer momento pela pessoa responsável.
São as poucas regras que **sempre** valem. Todo o resto (crop, posição, escolhas de composição) é contexto e julgamento, caso a caso.
Rode este checklist **antes de montar** e **no QA**. Se uma regra não puder ser cumprida, avise na entrega; não ignore.

## Fluxo e material
- [ ] 1. Li **só a tarefa atual**. A base é a categoria dos APPROVED LAYOUTS ou a base V/Q/H, **nunca** o último trabalho feito.
- [ ] 2. Nomes = nome da tarefa + formato (`_A/_B/_C`). No carrossel: letra do formato + número do card.
- [ ] 3. Formatos: A 1080×1920 · B 1200×1200 · C 1200×628 (salvo instrução da tarefa).
- [ ] 4. Lugar no canvas:
  - **ADS:** à direita, em colunas de 2 tarefas.
  - **Stories/Feed:** na coluna mais recente da seção.
- [ ] 5. Só **fotos reais** (nunca geradas por IA).
  - SKUs da tarefa respeitados.
  - Produto cancelado nunca entra.
  - Produto fora do site entra, mas é sinalizado.
- [ ] 6. Nenhuma foto repetida entre criativos da mesma tarefa. Foto usada nos últimos 10 dias só por falta de material ou pedido, e é sinalizada.

## Composição
- [ ] 7. **Colagem:** até 3 fotos do mesmo story ou fundo, sem barra branca entre as imagens.
- [ ] 8. Calçado inteiro quando aparece (bico + salto). O par enquadrado, não um pé cortado.
- [ ] 9. **Carrossel:** título/copy **só no 1º card**; os demais cards têm só o logo.
- [ ] 10. **GIF:** troca de imagens em corte seco, no mínimo 10 s, logo branco.

## Tipografia e logo
- [ ] 11. **Preto só sobre branco ou cor clara**, sem dividir espaço com mais nada. Arte escura ou contrastada sem fundo branco leva texto e logo **brancos**. A cor pode variar por formato.
- [ ] 12. **Wordmark Larroudé:** acento **sempre rosa** (#F44C7F). **Mesmo tamanho em todas as peças do mesmo formato.**
- [ ] 13. Logo de collab (ex.: "Larroudé by Nicolò B."): lockup intocável, só escalar.
- [ ] 14. Logo dentro da margem Meta no 1080×1920 (x 65–1015, y 269–1536). Nos outros formatos, respiro ≥ 40 px.
- [ ] 15. **Nunca** converter texto em vetor/contorno.

## Entrega
- [ ] 16. Air só **depois da aprovação**:
  - criar pasta `STATIC/NN` ou `GIF/NN` por arte;
  - conferir a contagem;
  - comentar com menção real: @Monique Tauane da Silva (ADS) ou @Bruna Klaus (social) + link.
- [ ] 17. Nunca apagar trabalho, cards ou arquivos de outra pessoa.

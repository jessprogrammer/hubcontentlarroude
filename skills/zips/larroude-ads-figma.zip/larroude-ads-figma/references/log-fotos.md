# Log de fotos usadas
Serve para **não repetir fotos com frequência** (regra: evitar a mesma cena em tarefas próximas; capa e foto-herói são as mais visíveis).
Antes de escolher fotos: procure o arquivo/modelo aqui. Se a mesma foto aparece nos **últimos 10 dias**, prefira outra cena (outro set, ângulo ou look). Exceções: pouca foto disponível do produto, ou a pessoa que pediu quer aquela foto específica. Nesses casos pode repetir; avise na entrega. Depois de 10 dias a foto volta a ficar livre, mas a preferência continua sendo usar fotos novas/pouco usadas.
Depois de aprovar a peça: acrescente uma linha por foto (mais recente em cima).

Colunas:
- **Data** da entrega (DD/MM/AAAA)
- **Tarefa** (nome do Asana) e **canal** (ADS US, ADS BR, Stories, Feed)
- **Artboard(s)** onde a foto entrou (nome ou nodeId)
- **Arquivo Air** (nome) e **id** (asset ou versão), ou "site PDP" se veio do larroude.com
- **Papel**: capa / herói / apoio / recorte de produto
- **Cena**: descrição curta (set, look, cor, enquadramento) para reconhecer fotos parecidas

| Data | Tarefa · canal | Artboard | Arquivo · id | Papel | Cena |
|---|---|---|---|---|---|
| 06/10/2026 | The Architectural Heel × Nicolò B · Stories | 01 capa / 06 CTA | GROUP_MARIA (6) 3133fae4 / GROUP_MARIA (5) c9aea28a | capa / apoio | saltos curvos em vermelho com luz |
| 06/10/2026 | The Architectural Heel × Nicolò B · Stories | 02–05 | GRAC-BURG (2) ab7aec76 + GRAC-BLAC (4) ea62c062; GROUP_MARIA (3) eb730a37 + MARI-LILA (7) 637695f5; LUCI-WHIT (2) 74709b53 + (6) ceb363b0; ISAB-BLAC (10) 7669bf73 + (6) a3c261a7 | herói + polaroid | 2_STILL Nicolò, fundos vermelho/cinza |
| 06/10/2026 | [ADS US] New Drop 07/10 · ADS US | carrossel capa | foto de grupo Hydra 4 cores (enviada pelo Pietro, ≈ GROUP_HYDRA (1)) | capa | 4 cores empilhadas, fundo branco |
| 06/10/2026 | [ADS US] New Drop 07/10 · ADS US | cards 2–5 + estático | HYDR INDI (1)(2), BURG (1)(3), BURN-3259 (2)(3), MAYA (1)(2) | herói | stills fundo branco, pares e macros |
| 05/10/2026 | [GRAPHIC] ADS Marina (Cyprus) · ADS US | ANOTHER-PAIR_01_A/B | cyprus shearling · versão 5132815b | herói | suéter vermelho + jeans, Cyprus marrom, banco de pedra |
| 05/10/2026 | [GRAPHIC] ADS Marina (Cyprus) · ADS US | ANOTHER-PAIR_02_A/B | "1" (L545-CYPR-BLAC-3142) · versão 7d5be19b + upscale | herói | Cyprus preto, meia verde de bolinha, xadrez rosa |
| 05/10/2026 | [GRAPHIC] ADS Marina (Cyprus) · ADS US | BESTSELLER_01_A/B | GROUP_CYPRUS (2) · versão 60b5f6a1 | herói | 3 pares em fundo azul com sombra |
| 05/10/2026 | [GRAPHIC] ADS Marina (Cyprus) · ADS US | BESTSELLER_02_A/B | GROUP_CYPRUS · asset b00a538d versão aee9127a | herói | 6 pares empilhados em fundo kraft |
| 05/10/2026 | [GRAPHIC] ADS Marina (Cyprus) · ADS US | PRESS_01 + SOULMATE_02 | L545-CYPR-BROW-3045 · versão 515403dd | herói | jeans escuro + meia off-white, fundo branco |
| 05/10/2026 | [GRAPHIC] ADS Marina (Cyprus) · ADS US | PRESS_02 + SOULMATE_01 | "8" · versão 275db99a + upscale | herói | Cyprus shearling + meia azul, madeira |
| 05/10/2026 | [GRAPHIC] ADS Marina (Cyprus) · ADS US | PRESS_03 + SOULMATE_04 | "7" · versão 236087c2 + upscale | herói | jeans claro, carpete vermelho de bolinha |
| 05/10/2026 | [GRAPHIC] ADS Marina (Cyprus) · ADS US | SOULMATE_03 | "9" · versão c872f34a + upscale | herói | tapete persa vermelho, meia listrada |
| 05/10/2026 | [GRAPHIC] ADS Marina (Cyprus) · ADS US | SOULMATE_05 | "6" · versão 7cc164f2 + upscale | herói | lulu da pomerânia + par shearling, carpete mostarda |
| 02/10/2026 | WPP_BR 05-10 Best Duo Últimas Horas · WhatsApp BR | 21481:79 faixa topo | GROUP_CYPRUS (1) · versão c1b09310 | apoio | Cyprus camurça em fundo azul com sombra de sol |
| 02/10/2026 | WPP_BR 05-10 Best Duo Últimas Horas · WhatsApp BR | 21481:79 faixa meio | STELLA_GROUP (2) · versão 4525d604 | apoio | Stella várias cores em diagonal, fundo verde |
| 02/10/2026 | WPP_BR 05-10 Best Duo Últimas Horas · WhatsApp BR | 21481:79 faixa base | GROUP_VERONABALLETFLAT (1) · versão 81ed2e56 | apoio | fileira de Verona em fundo azul |
| 02/10/2026 | Storytelling Katie · ADS US | KATI…_A/B/D 1,3,5 | Downloads image-1790786985893/360337/261404 (+024699 removida) | herói | pernas+suéteres, texturas de couro, mão na cortina |
| 01/10/2026 | New Drop 07/10 v2 (TESTE) · ADS US | STATIC_ON-FOOT_02_A/B/C | L305-CIND-RUSS-3012 · versão 86167a03 | herói | bota slouchy camurça caramelo, parede branca + chão azul |
| 01/10/2026 | New Drop 07/10 v2 (TESTE) · ADS US | CAROUSEL_02 card 1 (capa) | L642-ALEX-IVOR-3022 · versão 27d19e9e | capa | bota creme em fundo azul claro |
| 01/10/2026 | New Drop 07/10 v2 (TESTE) · ADS US | CAROUSEL_02 card 2 | L421-DEWD-BLAC-2932 (2) · versão b2d695e1 | apoio | botas pretas salto dourado, fundo branco |
| 01/10/2026 | New Drop 07/10 v2 (TESTE) · ADS US | CAROUSEL_02 card 3 | L642-ALEX-BROW-2997 (2) · versão 17b4a7f3 | apoio | bota marrom cano alto, casaco de oncinha |
| 01/10/2026 | New Drop 07/10 v2 (TESTE) · ADS US | CAROUSEL_02 card 4 | L218-DOLL-BROW-2956 (2) · versão a13e8756 | apoio | bota plataforma camurça em fundo azul |
| 01/10/2026 | New Drop 07/10 (TESTE, fotos aleatórias) · ADS US | STATIC_ON-FOOT_02_A/B/C | L659-LOUL-BLAC-2984 (2) · versão cb647308 | herói | perna + bota preta Loulou, fundo branco de estúdio |
| 01/10/2026 | New Drop 07/10 (TESTE) · ADS US | CAROUSEL_02 card 1 (A1/B1/C1) | L545-HYDR-BURN-3255 (13) · versão 41696044 | capa | HYDRA marrom encostada na parede, chão cinza |
| 01/10/2026 | New Drop 07/10 (TESTE) · ADS US | CAROUSEL_02 card 2 | L545-HYDR-BURN-3255 (1) · versão 0ebb31aa | apoio | HYDRA no chão, parede clara |
| 01/10/2026 | New Drop 07/10 (TESTE) · ADS US | CAROUSEL_02 card 3 | L545-HYDR-BURN-3255 (2) · versão 1f6b5d20 | apoio | par HYDRA de cima, fundo branco |
| 01/10/2026 | New Drop 07/10 (TESTE) · ADS US | CAROUSEL_02 card 4 | L545-HYDR-BURN-3255 (3) · versão 812b8dd0 | apoio | pé único HYDRA de cima, fundo branco |
| 01/10/2026 | UGC Kirstin Pump · ADS US | L481-KIRS-BURN-3043_…_UGC_01_A/B/C | Kirstin UGC · versão 520e39b7 | herói | creator na calçada, vestido marrom, pump de tiras coloridas, grade preta |
| 01/10/2026 | UGC Kirstin Pump · ADS US | …_UGC_02_A/B/C | Kirstin UGC · versão 7055b051 | herói | mesma creator/look, segundo enquadramento |
| 01/10/2026 | Which Nicolò Are You? (This or That) · Stories | Capa 21346:2 | _DSF1042 (Collab Nicolò B. › 2026-2) | capa | campanha Nicolò B., cena da capa trocada a pedido para não repetir |
| 01/10/2026 | Which Nicolò Are You? · Stories | Encerramento 21354:57 | _DSF1203 (Collab Nicolò B. › 2026-2) | apoio | campanha Nicolò B. |
| 01/10/2026 | Which Nicolò Are You? · Stories | Pares 21354:2/13/24 | 6 recortes · site PDP | recorte de produto | packshots sem contorno, fundo #F6F6F6 |
| 01/10/2026 | Nicolò B. Drop 3 Dressing Guide · Stories | Capa (21326:2) | _DSF9679 (Collab Nicolò B. › 2026-2) | capa | campanha Nicolò B. |
| 01/10/2026 | Nicolò B. Drop 3 Dressing Guide · Stories | CTA final | _DSF8773 (Collab Nicolò B. › 2026-2) | apoio | campanha Nicolò B. |
| 01/10/2026 | Nicolò B. Drop 3 Dressing Guide · Stories | Looks 1–5 (21326:9…114) | recortes · site PDP | recorte de produto | Bow Mule, Suede Pump, Slingback, Patent Pump, Second-Skin Boot, com contorno branco |

Observação: nas próximas tarefas, registre também o **asset id** completo quando a foto vier do Air (o get_asset_download_url já devolve). As linhas de hoje usam só o nome onde o id não foi guardado.

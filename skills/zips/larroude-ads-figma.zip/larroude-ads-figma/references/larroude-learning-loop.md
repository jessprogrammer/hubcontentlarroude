Pietro (2026-09-29): "eu vou fazendo mudanças e pedindo pra você revisar o que eu ajusto e entender como eu trabalho para novas aplicações."

**Why:** he prefers to fix details himself and have Claude learn from the diff, instead of iterating via instructions.
**How to apply:** when he says he adjusted something, do NOT edit — read the changed nodes (imageTransform, rect positions, text sizes/positions, effects), screenshot at ≥50%, compare to what I built, and report a table (onde / eu fiz / você fez / lição). Record each lesson as a numbered rule in [[larroude-creation-rules]] with concrete values, and apply them in future builds. Keep a baseline of my own values when delivering so the diff is precise.

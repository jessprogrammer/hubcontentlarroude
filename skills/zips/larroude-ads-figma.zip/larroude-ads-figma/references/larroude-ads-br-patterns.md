Figma file "FIGMA ZAINERS NOVO" (fileKey DRphNBA9HvgZ6HwazNMHrm), page "ADS BR" (id 3375:2). Analyzed 2026-09-24.

- 2,790 artboards. Formats: 1080x1920 (1128), 1200x628 (532), 1080x1080 (490, legacy), 1200x1200 (488), 1080x1350 (78).
- Current naming (node ids 16k+, ~100%): {SKU|campaignID|BRAND|XXX}_{STATIC|CAROUSEL|GIF}_{MOST|PRODUCT|SOLUTION}-AWARE_{PRODUCT-FOCUSED|PRODUCT-MIX|ON-FOOT|UGC|NO-IMAGE}_{nn}[_A/B/v2]. Suffix 01=1080x1920, 02=1200x1200, 03=1200x628. Columns per variant; 02 row at +2461px y, 03 row at +4202px below 01.
- Layout: dates/campaign title TEXT nodes above each column group (e.g. "24.09 - Pavlova").
- Archetypes: (1) full-bleed photo + short white headline + logo bottom-center; (2) NO-IMAGE typographic offer on solid color (lilac #9D7AD6, burgundy #481022 + butter #FEE88E, pink #E9519E), Suprapower SE Heavy for big %; (3) 1200x628 split: text column one side, photo/grid other; (4) PRODUCT-MIX collage grid + offer card; (5) cut-out product on #F6F6F6 with name + "De: R$ / Por: R$"; (6) Review/UGC quote + ★★★★★ + name; (7) editorial serif (Very Vogue Display) e.g. "I'm George".
- Type: Platform Regular (main sans), Plain Regular/Light, Graphik, Suprapower SE Heavy (promo numbers, recent), Very Vogue Display (editorial), Blitz Script (accent, rare). Futura Bold only in BF era (legacy).
- Text colors: white / black dominant; butter #FEE88E/#FEEEAA on burgundy. Center align dominant, then left.
- Logo: bottom-center or under headline; node names inconsistent (LOGO, Asset 1, L Mark, Larroude-Wordmark_*); L-mark ~57-70px tall in 1920, wordmark ~30-40px.
- Headline max font median: 80 (1920), 70 (1200²), 65 (628). Stories: ≥10% recent have text <180px from top (safe-zone risk).
- Copy: short sentence case with period; offers "40% off" / "1 PAR 40% OFF · 2 PARES OU MAIS 60% OFF"; urgency ("72h", "últimas horas"); coupons (WELCOME20, EXTRA20).

**How to apply:** use as baseline when suggesting edits/new versions in this file; match naming, row offsets, fonts and logo placement. See [[larroude-abc]] skill for ABC callouts (different deliverable).

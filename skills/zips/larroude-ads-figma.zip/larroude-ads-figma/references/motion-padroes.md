# Motion: padrões aceitos

Animações aprovadas que servem de ponto de partida. Dá para variar, mas parta daqui em vez de inventar do zero.

## M01 · Tipografia por letra (NO-IMAGE / oferta só texto)
**Origem:** GIF "[AÇÃO-BR] In Stock 60%", frames 21630:2 (1080×1920) e 21630:71 (1200×1200), aprovado em 05/10/2026.
**Quando usar:** GIF de oferta só com texto (NO-IMAGE), sobre a cor da campanha.

### Visual
- Fundo chapado na cor da campanha: sem gradiente, sem sombra, sem efeito nenhum.
- Fontes da campanha, iguais às do estático (identidade não muda). Cor do texto igual à da campanha (ex.: amarelo-manteiga sobre vermelho).
- Logo: L mark pequeno na base.
- Nada de linha decorativa nem disclaimer no GIF.

### Estrutura (10 s, loop sem emenda)
| Tempo | O que acontece |
|---|---|
| 0–1,75 s | L mark grande no centro desce até a base, só com escala e posição, **sem sumir nem desfocar** |
| 1,45 s | Etiqueta (ex.: THE HIT LIST) entra com tracking-in: as letras convergem para o centro |
| 1,65 s | Número da oferta (ex.: 60% OFF) sobe letra por letra de dentro da máscara |
| 2,55 s | Segunda frase entra **embaixo** do número, formando um bloco só |
| 5,0 s | O bloco sai subindo, letra por letra |
| 5,95 s | Frase final (ex.: Pronta entrega) entra **da esquerda para a direita, de baixo**, do mesmo jeito que sai |
| 8,75 s | Frase final sai subindo |
| 9,2–10 s | L mark volta ao centro (mesma posição do início, fecha o loop) |

- Durante cada pausa a tela "respira": SCALE_XY de 1 → 1,035, linear.
- Easings:
  - entrada `cubic-bezier(.16,1,.3,1)` (expo out);
  - saída `(.7,0,.84,0)` (expo in);
  - movimento do logo `(.83,0,.17,1)`.
- Stagger entre letras de 0,03 a 0,065 s.

### O que NÃO funcionou (evitar)
- Texto entrando como bloco inteiro, com easing padrão: fica "quadrado".
- Corte seco entre telas.
- Letras vindo de direções opostas, com rotação.
- Logo apagando e surgindo, ou desfocando.
- Fonte diferente da campanha.
- Sombra herdada do texto copiado: sempre zerar os `effects`.

### Como montar
Script: `scripts/figma/motion_letras.js`.
1. Monte um frame temporário com cada texto no tamanho final e tire `get_screenshot` (contentsOnly).
2. Com Python, ache os vãos entre as letras: colunas sem tinta, onde a tinta é cor do texto > 200. Isso dá os segmentos de x de cada letra.
3. Para cada letra, crie um frame com clip. A janela vai do meio do vão anterior ao meio do vão seguinte. Dentro dela vai um clone do texto inteiro, deslocado por `x = -inícioDaJanela`.
   - Funciona com fonte que o plugin não carrega (Very Vogue): o clone só é reescalado, nunca editado.
4. **Altura da máscara:** use a altura real do texto + 44 px de folga embaixo, para letras com descendente (g, p, y). A entrada vem de +H e a saída vai para -(H+2), com H = altura da máscara. Assim não sobra pedaço.
5. Animação:
   - Para subir da máscara, anime `TRANSLATION_Y` do texto dentro da janela.
   - Para o tracking-in, anime `TRANSLATION_X` da própria janela.
6. Timeline: `setTimelineDuration(id, 10)` em um nó filho.
7. Verificação: `export_video` com 400 px de largura e 10 fps; extraia os quadros com imageio (sem ffmpeg CLI) e confira as transições e o fim do loop.
8. Entrega: `export_video` no tamanho cheio, 30 fps, quality high; a URL vai direto em `create_import` (ext mp4) na pasta GIF/NN.

### Pegadinhas
- `absoluteRenderBounds` de um texto dentro de máscara vem **recortado**. Para medir o deslocamento da tinta, use um clone solto no canvas.
- Very Vogue não muda de cor pelo plugin. Para outra cor, clone um texto que já exista nessa cor (ex.: banner desktop amarelo 21591:93, banner mobile branco 21591:97) e realinhe pela tinta.
- Keyframes que se repetem por ciclo precisam de um valor "segurado" no fim do ciclo. Senão o valor desliza até o próximo keyframe.

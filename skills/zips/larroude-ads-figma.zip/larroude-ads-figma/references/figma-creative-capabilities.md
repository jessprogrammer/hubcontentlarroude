Research files (session folder, may not persist): design-advisor-notes.md, research-design-references.md, research-figma-features.md, artboards-coordinates.json.

**API-drivable, not yet used by me (use_figma):**
- Variables + modes per format (1080x1920 / 1200x1200 / 1200x628) bound to sizes, padding, logo position → derive formats from one master; also constraints + `rescale()`.
- `ImagePaint.filters` (exposure, contrast, saturation, temperature, tint, highlights, shadows) to harmonize photos from different shoots (write works; reading UI-set values unreliable).
- Effects: progressive blur, NOISE (grain), GLASS (frames only), blend modes (MULTIPLY for white-bg packshots), luminance/vector masks. Newer effects in beta.
- Shaders via `list_shaders`/`create_shader` (library of 35: Color adjust, Duotone, Light rays, Bokeh, Mesh gradient, Halftone…) — load figma-shaders skill first.
- Type: `createTextPath` (circular seal), `textWrapStyle:'BALANCE'`, OpenType features, variable fonts.
- Grid auto layout, components/variants/slots, angular/diamond gradients, pattern fills, Figma Draw brushes.
- Motion via `figma.motion` → export MP4/GIF/WEBM (`export_video`).
- Buzz `figma.buzz.smartResize` only inside Buzz files (unconfirmed via MCP).
**UI-only / blocked:** native AI image tools (remove bg, expand, erase, upscale). Weave tools could do it but need Figma↔Weave account link at app.weavy.ai (user action).

**Design-craft highlights:** 12-based grids (1080: margin 60, 6 cols × 150, gutter 12); cells 1:1/2:1/1:2; hero ≥62% area, quadrant split at 0.382/0.618; type scale 1.333, headline tracking −1 to −2%, label +10–16%, leading 1.0–1.1, align by cap height; 2px stroke white if photos luma ≤50%, black if ≥70%, stroke OR gutter not both, best with ≥4 similar-luma cells; moves: contact sheet, zoom chain 1×/3×/9×, single sole horizon, BR/NY diptych, series with stroke color shift.

**Open decision for Pietro:** Meta unified Stories+Reels safe zone (Mar/2026) wants text/logo y≤1248 on 1080x1920, but house L-mark sits ~1545–1649. Ask which placement to target before next production batch.

Related: [[larroude-creation-rules]], [[larroude-ads-br-patterns]].

**Figma Motion GIFs — working recipe (2026-09-28, ADS US 20974:2 PRODUCT-MIX, 20974:51 EDITORIAL):** house GIFs = stacked full-bleed image rects + LOGO on top; each rect gets an OPACITY manual keyframe track with hard cuts (0→1 at start, 1→0 at end with 1ms gap), timeline = n × slot. House editorial slot 1.5s; product-detail ref GIFs ~0.75s. Build with `applyManualKeyframeTrack({type:'PROPERTY',name:'OPACITY'},…)` + `setTimelineDuration` on a child. Verify via `export_video` (MP4 only, WIDTH 320, fps 5) + imageio frame strips (pip imageio imageio-ffmpeg installed; no ffmpeg CLI). `figma.getImageByHash` returns null for images only placed on other pages — keep a size table instead.

Pietro shared the brand palette (8 hues × 3 tones: strong / mid / light) on 2026-09-25. **Main + favorites: rosa, vermelho, lilás, azul. Use mainly the strongest/darkest tone.** Mid/light tints only as support.

Strong tones (hex matched to values already used in the Figma file / SDK tokens where possible; others estimated from his swatch image):
- **Rosa** #E9519E (SDK hotPink #E9519F) · mid ≈#F07BAE · light ≈#F9BBCF
- **Vermelho** #D11524 (SDK red #D21525) · mid ≈#E24B4B · light ≈#F9B3A1
- **Lilás** #A685DB (file also #9D7AD6) · mid ≈#C2A7E8 · light ≈#E6D4FA
- **Azul** #2464AB · mid ≈#5090CF · light ≈#A9D7F5
- Secondary hues in palette (less used): light blue ≈#9DC3E6, green ≈#6BA851, orange ≈#EC7220, yellow #FED966.
- Promo pair also seen in file: burgundy #481022 + butter #FEE88E. Neutrals: #111 / #FFF / #F6F6F6.

**Context:** he approved the v3 + Idea A/B round ("esses ficaram ótimos") right before sharing this.
**How to apply:** for colored bands/backgrounds/panels (e.g. text bands behind white type, promo bands), prefer the strong tone of pink/red/lilac/blue; verify white text contrast (all four strong tones pass ≥3:1 for large type; check lilac for small labels). Related: [[larroude-creation-rules]] (rule 24: colored/dark band instead of white).

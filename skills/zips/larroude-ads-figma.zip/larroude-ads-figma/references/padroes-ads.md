# Padrões ADS · bases por formato

Figma: aba **"Claude Padrões ADS"**, com uma cópia de cada base, rótulo e ID de origem. Levantamento feito em 01/10/2026 sobre ~5.800 estáticos de ADS US e BR.
São bases para aplicar conforme a foto pedir, não regras. A posição da copy sempre se adapta à foto.
Escolha: (1) foto com ou sem copy; (2) quantas fotos do MESMO story (no máximo 3, coladas); (3) onde a foto tem área calma.

## 01 · Vertical 1080×1920
| Código | Base | Quando usar | Origem |
|---|---|---|---|
| V01 | Foto única + copy central | área calma no meio | 21305:141 |
| V02 | Copy no topo + etiquetas laterais | modelo em movimento, topo livre | 17196:3 |
| V03 | Copy lateral + L-mark acima | lado livre na altura média | 16142:3 |
| V04 | Foto única, só logo | foto forte (flat lay, pernas) | 20373:206 |
| V05 | Oferta sobre a foto | promo | 20597:59 |
| V06 | Díptico vertical sem copy | produto inteiro + detalhe | 20563:4 |
| V07 | Hero + detalhes emoldurados | on-foot + 2–3 miniaturas do mesmo produto | 20391:674 |
| V08 | Quadrante com painel de texto | 3 fotos do mesmo shoot | 17372:2 |
| V09 | Xadrez foto/texto | lançamento de cores/modelo | 17322:611 |
| V10 | Colagem do mesmo story + lockup | collab, até 3 fotos | 21305:261 |
| V12 | UGC: copy e logo ladeando o calçado | UGC/on-foot com espaço dos dois lados | 21367:25 |

## 02 · Quadrado 1200×1200
| Código | Base | Quando usar | Origem |
|---|---|---|---|
| Q01 | Foto única, só logo | flat lay/foto forte | 21049:40 |
| Q02 | Foto única + copy central | área calma no meio | 21305:147 |
| Q03 | Título serif no rodapé | foto mais alta que o frame, calçado central | 20349:200 |
| Q04 | Oferta sobre a foto | promo | 20597:116 |
| Q05 | Copy no canto superior | cena com topo-esquerdo livre | 20330:134 |
| Q06 | Xadrez 2x2 com texto | novidades da estação | 20564:23 |
| Q07 | Hero + tira de detalhes | mesmo produto | 20391:652 |
| Q08 | Quadrante + painel | modelo em cores | 16017:3 |
| Q09 | Título no topo, produto embaixo | still empilhado em fundo liso | 21305:160 |
| Q10 | UGC: copy e logo ladeando | UGC, foto mais fechada | 21367:41 |

## 03 · Horizontal 1200×628
| Código | Base | Quando usar | Origem |
|---|---|---|---|
| H01 | Foto à esquerda + texto no fundo liso | still/packshot | 21305:167 |
| H02 | Foto + painel de oferta | promo | 20695:256 |
| H03 | Foto única, só logo | foto larga forte | 21049:77 |
| H04 | Kicker + título no topo | still com topo livre | 21016:581 |
| H05 | Texto topo-esquerdo + logo à direita | on-foot em fundo de cor | 20356:30 |
| H06 | Texto + produto + detalhes | lançamento | 20391:675 |
| H07 | Hero + 3 detalhes em linha | mesmo produto | 20391:665 |
| H08 | Tríptico com painel central | lançamento | 18183:49 |
| H09 | Close do produto, só logo | macro de textura/estampa | 20373:187 |
| H10 | Mesma foto em duas escalas | cena + close, copy/logo ladeando | 21367:33 |

## Só tipografia · fundo colorido (sale/oferta sem foto)
| Código | Base | Origem |
|---|---|---|
| V11a / V11b / V11c (01) | bordô + faixas de desconto / rosa minimalista / vermelho com cupom recortado | 19526:99 / 20730:437 / 20240:80 |
| Q11a / Q11b / Q11c (02) | bordô + faixas / rosa minimalista / bordô + tipografia inclinada | 19526:53 / 20730:442 / 18525:224 |
| H11a / H11b / H11c (03) | coral "Sale up to" / vermelho com código / rosa minimalista | 18328:496 / 17774:809 / 20730:432 |
(Não usar a "Larroudé FEST" 20597:26 como base: era uma campanha de sale específica.)

## APPROVED LAYOUTS (prioridade: aprovados com o time e a Marina)
A aba original é a 11547:2. Há uma cópia completa no fim da aba "Claude Padrões ADS". Categorias:
- **US · Sale:** (a) versão limpa de SALE UP; (b) visual bem clean; (c) bem promocional e focado.
- **US · Pre-Order.**
- **US · Copy** (serve também para new arrivals).
- **US · Just Logo.**
- **BRASIL · Sale & promoções em geral.**
- **BRASIL · Copy.**
- **BRASIL · Just Logo.**
- **BRASIL · Pre-venda.**
- **BRASIL · UGC.**
Na hora de escolher uma base, olhar primeiro a categoria aprovada correspondente e depois as bases V/Q/H.

## Padrões fixos (outras peças)
- Carrossel ADS só com logo: padrão fechado.
- GIF: base de troca de imagens em corte seco (variações quando fizer sentido).
- Stories: This or That (Velvets Edition_02, 7286:17) e Dressing Guide (21326:x).

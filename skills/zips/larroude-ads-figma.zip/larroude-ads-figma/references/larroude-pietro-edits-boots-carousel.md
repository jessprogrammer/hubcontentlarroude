Pietro finished the boots carousel himself and asked me to log his changes as practices. Frames now named 494005223738_CAROUSEL_MOST-AWARE_PRODUCT-MIX_{01|02}_{A..G} at ADS BR y=24693 (01 vertical) / y=26793 (02 square), x≈35392+.

**Practices observed**
1. **Naming = campaign ID + card letter.** 01 = 1080x1920, 02 = 1200x1200; A/B = cover versions, C…G = product cards in carousel order. Rows placed next to the campaign's existing artboards (same ID), not in a test area.
2. **Model/lifestyle over packshot.** Ricky + Florencia both come from ONE street on-model photo (c41067) cropped tight on different boots/legs; Georgia swapped to a dramatic crossed-legs on-model shot (ba7fe6 vertical / 393856 square). Only Carine/Dolly stayed product-ish. One strong lifestyle image can feed two cards via different crops.
3. **Tighter crops, boot fills the frame.** He zoomed further (e.g. Dolly sx .577, Carine sx .76, Ricky/Flor sx .306) — shaft/legs bleed off edges; boot dominates. In squares he simply scaled the photo layer past the frame (x -46, w 1246) instead of leaving margins.
4. **Lockup placement follows the product, not a fixed top line.** Wordmark+name sits beside the boot shaft at mid-height when that's the calm zone (Florencia y849 L, Carine y960 R, Georgia y503 R), top only when the top is calm (Dolly centered, Ricky top-right). Alignment toward the side of free space.
5. **Shadow only when needed.** Ricky/Georgia/Carine text has no shadow; halos kept only over busy areas (Dolly, covers, Florencia).
6. **Covers:** kept my A/B structure; on the square cover he narrowed the headline box (379w) for a better rag.
7. Carousel order changed: Florencia before Ricky (C = Florencia, D = Ricky).

**How to apply:** for future product carousels, start from on-model lifestyle crops, zoom until the boot dominates, place the house lockup next to the product in its calm zone, name frames with campaign ID + format + card letter and park them beside that campaign. Related: [[larroude-creation-rules]] rule 27, [[larroude-air-bridge]].

**Approved 2026-09-25 ("ficou muito bom"):** 689526374566_STATIC_NO-COPY_EDITORIAL_01/02/03 on ADS US (20922:2/18/34, under "25.09 -" marker). Recipe to reuse for TOF no-copy editorial: 5 on-model photos (Air FALL 25 NYC shoot + current Cyprus), white 8px gutters, darkest/strongest photo in the center cell, collection LOGO (white wordmark 409x72 from 18822:26) exactly centered with soft shadow; 1920 = 2 / wide band / 2, 1200² = center tall column + 2 narrow columns each side, 628 = 5 vertical strips.

**Approved 2026-09-28 (collection 689526374566, ADS US):** GIF PRODUCT-MIX_01/02 + EDITORIAL_01/02 (0.75s hard cuts, 7 unique imgs ×2 = 10.5s, white centered logo) and CAROUSEL_NO-COPY_EDITORIAL-ON-FOOT 01/02 A–G (one Air on-foot photo per SKU, full-bleed, white centered logo) — "está ok".

Pietro asked (2026-09-25) for a reviewer agent that loads all accumulated knowledge, inspects every art in detail (read-only), sends errors back, and must approve before delivery. First test on v3 arts (20818:2/9/19/26) took 3 rounds → all APROVADO.

**Why:** my own analysis missed errors (white-on-white, logo on sock, seal touching shoe, clipped soles, upscaled crop, mislabeled layers).
**How to apply:** after building any art, spawn/resume a QA reviewer (general-purpose agent, read-only Figma, checklist: product clipping + source px/output px ≥1.0, contrast via measured luminance, spacing 18/90, L-mark exactly 35×66, safe zones, stroke consistency, layer names, orphans). Apply fixes, re-review until APROVADO. Then send Pietro a report: errors → how I fixed → what I should have caught.

**Self-check lessons (catch these before QA):**
- Measure luminance behind every text/logo box, don't eyeball thumbnails (white text on jeans edge/sock).
- Project product bbox into cell and require ≥40px clearance from text, seals, cell edges; soles must not touch band bottoms.
- Compute source px per output px for every macro crop (<1.0 = upscaled).
- Adjacent detail cells must show different subjects (not same center at 1.3× apart).
- Stroke INSIDE on touching cells doubles to 4px — use per-side 1px internal / 0 at frame edges.
- Name layers by actual content.
- CROP aspect math: sy = sx·(imgW·cellH)/(imgH·cellW); identity transform only when image aspect == cell aspect. Every resize of a cell requires recomputing sy. Keep tx+sx≤1 and ty+sy≤1 (else empty strip).
- Converting FILL→CROP with identity stretches non-matching images.
- Before placing insets, compute bottom margin (≥60px) and gap to L-mark.
- Cloned L-mark comes 35×67 and with inherited shadow — reset to 35×66, clear effects on light bg.
- createTextPath: re-append to frame; text starts at 3 o'clock — rotate 180° so the phrase reads across the top; tune tracking so ring closes without dropping glyphs.
- Logo/wordmark must fit INSIDE the cell it sits on with ≥80px clearance to cell edges/gutters (Pietro 2026-09-25: 409px logo overflowed a 392px center strip on the 1200x628). Size the center cell for the logo, and scale the wordmark per format (~300w on 628, 409w on 1920/1200²). Never skip QA even when rushing.
- Don't invent product names/claims silently — flag them as questions.
- Canvas may be rearranged by Pietro; re-read positions before recording them.

Related: [[larroude-creation-rules]], [[larroude-v3-tests]].

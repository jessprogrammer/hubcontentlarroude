// Cria as artboards de uma tarefa no padrão de canvas da casa:
// versões do mesmo tamanho lado a lado; tamanhos diferentes empilhados embaixo.
// Ex.: 2 criativos × 3 formatos → linha 1: _01_A _02_A (1080×1920), linha 2: _01_B _02_B (1200²), linha 3: _01_C _02_C (1200×628).
// Opcional: marcador de texto acima ("DD.MM - [ADS US] Nome").
// Uso: use_figma (skillNames "figma-use"). Edite CONFIG. x/y = canto superior esquerdo (use proximo_espaco.js antes).
const CONFIG = {
  pageId: 'PAGE_ID',
  x: 0, y: 0,
  base: 'NOME_DA_TAREFA',                  // ex.: L481-KIRS-BURN-3043_STATIC_MOST-AWARE_UGC
  criativos: ['01', '02'],                 // colunas
  formatos: [                              // linhas (letra vai no fim do nome)
    { sufixo: 'A', w: 1080, h: 1920 },
    { sufixo: 'B', w: 1200, h: 1200 },
    { sufixo: 'C', w: 1200, h: 628 },
  ],
  gap: 100,
  marcador: '',                            // ex.: '01.10 - [ADS US] UGC Kirstin Pump' ('' = sem)
};

const page = await figma.getNodeByIdAsync(CONFIG.pageId);
await figma.setCurrentPageAsync(page);
const ids = []; let y = CONFIG.y;
if (CONFIG.marcador) {
  await figma.loadFontAsync({ family: 'Inter', style: 'Bold' });
  const m = figma.createText(); m.fontName = { family: 'Inter', style: 'Bold' }; m.fontSize = 120;
  m.characters = CONFIG.marcador; m.x = CONFIG.x; m.y = y; page.appendChild(m); y += m.height + CONFIG.gap; ids.push(m.id + ' marcador');
}
const colW = Math.max(...CONFIG.formatos.map(f => f.w));
for (const f of CONFIG.formatos) {
  CONFIG.criativos.forEach((c, i) => {
    const fr = figma.createFrame();
    fr.resize(f.w, f.h); fr.x = CONFIG.x + i * (colW + CONFIG.gap); fr.y = y;
    fr.name = `${CONFIG.base}_${c}_${f.sufixo}`; fr.fills = [{ type: 'SOLID', color: { r: 1, g: 1, b: 1 } }];
    page.appendChild(fr); ids.push(fr.id + ' ' + fr.name);
  });
  y += f.h + CONFIG.gap;
}
return { criados: ids, fimY: y };

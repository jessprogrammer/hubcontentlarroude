// motion_letras.js · animação por letra (padrão M01, references/motion-padroes.md)
// Rodar com use_figma (skillNames "figma-use,figma-use-motion"). Edite só o CONFIG.
// Pré-requisito: segmentos de cada texto medidos via screenshot + Python (vãos entre letras).
// Altera o arquivo: cria janelas com clip por letra dentro de PARENT_ID e grava keyframes.

// ===== CONFIG =====
const PARENT_ID = '0:0';          // frame/tela onde as letras entram (filho do frame raiz)
const SOURCE_TEXT_ID = '0:0';     // texto de origem (clonado; nunca editado se a fonte não carregar)
const SCALE_TO = null;            // ex.: 260 -> rescale do clone para esse fontSize (null = mantém)
const SEGS = [[0, 10]];           // [x0,x1] da tinta de cada letra, relativo ao box do texto
const BOX_W = 100;                // largura do box do texto no tamanho final
const CX = 540, Y = 800;          // centro horizontal da palavra e topo da máscara no frame
const PAD_BOTTOM = 44;            // folga para descendentes
const ENTER = 1.65, STAGGER = 0.05, ENTER_DUR = 0.9;   // entrada (s)
const EXIT = 5.0, EXIT_STAGGER = 0.04, EXIT_DUR = 0.55; // saída (s); null = sem saída
const TOTAL = 10;                 // duração da timeline
// ==================

const XO = {type:'CUSTOM_CUBIC_BEZIER', easingFunctionCubicBezier:{x1:0.16,y1:1,x2:0.3,y2:1}};
const XI = {type:'CUSTOM_CUBIC_BEZIER', easingFunctionCubicBezier:{x1:0.7,y1:0,x2:0.84,y2:0}};
const K = (t,v,e)=>{const k={timelinePosition:+t.toFixed(3), value:{type:'FLOAT', value:v}}; if(e) k.easing=e; return k;};

const parent = await figma.getNodeByIdAsync(PARENT_ID);
const src = await figma.getNodeByIdAsync(SOURCE_TEXT_ID);
const ink0 = SEGS[0][0], ink1 = SEGS[SEGS.length-1][1];
const X = Math.round(CX - (ink0+ink1)/2);
const wins = SEGS.map((s,i)=>[i?Math.floor((SEGS[i-1][1]+s[0])/2):-4, i<SEGS.length-1?Math.ceil((s[1]+SEGS[i+1][0])/2):BOX_W+4]);
const ids = [];
wins.forEach(([a,b],i)=>{
  const t = src.clone(); if (SCALE_TO) t.rescale(SCALE_TO / src.fontSize); t.effects = [];
  const H = Math.ceil(t.height) + PAD_BOTTOM;
  const m = figma.createFrame(); parent.appendChild(m); m.name = 'letra '+(i+1); m.fills = []; m.clipsContent = true;
  m.resize(b-a, H); m.x = X + a; m.y = Y; m.appendChild(t); t.x = -a; t.y = 0;
  const kf = [K(ENTER+i*STAGGER, H+2), K(ENTER+i*STAGGER+ENTER_DUR, 0, XO)];
  if (EXIT != null) kf.push(K(EXIT+i*EXIT_STAGGER, 0), K(EXIT+i*EXIT_STAGGER+EXIT_DUR, -(H+2), XI));
  t.applyManualKeyframeTrack({type:'PROPERTY', name:'TRANSLATION_Y'}, {keyframes: kf});
  ids.push(m.id);
});
const first = (await figma.getNodeByIdAsync(ids[0])).children[0];
const [tl] = first.timelines; if (tl && tl.duration < TOTAL) first.setTimelineDuration(tl.id, TOTAL);
return 'ok ' + ids.length + ' letras';

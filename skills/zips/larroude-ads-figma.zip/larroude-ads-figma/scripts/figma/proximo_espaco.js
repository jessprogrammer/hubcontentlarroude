// Leitura. Acha onde começar uma tarefa nova numa seção de Stories/Feed (ou qualquer página com títulos grandes).
// Retorna as colunas da seção, quantas peças cada uma tem, onde termina (bottom) e a última peça.
// Tarefa nova: x da coluna mais recente (mais à direita), y = bottom + 400 — salvo instrução de quem pediu.
// ADS (US/BR): colunas de 2 em 2 tarefas à direita da última coluna (ver references/mapa-figma-air.md).
// A atribuição por seção é heurística (título mais próximo acima/à esquerda): confira antes de criar.
const CONFIG = { pageId: '188:214', titulo: 'Dressing Guide', fonteMin: 400 }; // Stories 188:214 · Feed 1894:2

const A = s => String(s).normalize('NFD').replace(/[^\x20-\x7E]/g, '');
const page = await figma.getNodeByIdAsync(CONFIG.pageId); await figma.setCurrentPageAsync(page);
const labels = page.children.filter(n => n.type === 'TEXT' && typeof n.fontSize === 'number' && n.fontSize >= CONFIG.fonteMin && n.fontSize < 1500);
const alvo = labels.find(l => A(l.characters).trim().toLowerCase() === CONFIG.titulo.toLowerCase());
if (!alvo) return { erro: 'titulo nao encontrado', titulos: labels.map(l => A(l.characters).trim()) };
const frames = page.children.filter(n => ['FRAME', 'GROUP', 'COMPONENT', 'INSTANCE'].includes(n.type));
const meus = frames.filter(f => {
  let best = null, bs = 1e12;
  for (const L of labels) { if (L.x - 600 > f.x || L.y - 600 > f.y) continue; const s = (f.x - L.x) + (f.y - L.y) * 0.5; if (s < bs) { bs = s; best = L; } }
  return best === alvo;
});
// colunas: junta artboards pela borda direita real (vão < 600px = mesma coluna)
const ord = meus.slice().sort((a, b) => a.x - b.x); const agrup = [];
for (const f of ord) { const c = agrup[agrup.length - 1]; if (c && f.x <= c.dir + 600) { c.dir = Math.max(c.dir, f.x + f.width); c.f.push(f); } else agrup.push({ dir: f.x + f.width, f: [f] }); }
const res = agrup.map(c => { const b = c.f.reduce((a, d) => (d.y + d.height > a.y + a.height ? d : a)); return { x: Math.round(Math.min(...c.f.map(f => f.x))), pecas: c.f.length, bottom: Math.round(b.y + b.height), ultima: A(b.name) }; });
// peças soltas (coluna com menos de 4 artboards) não contam como coluna para a sugestão
const reais = res.filter(c => c.pecas >= 4); const ult = (reais.length ? reais : res)[(reais.length ? reais : res).length - 1];
return { titulo: [Math.round(alvo.x), Math.round(alvo.y)], colunas: res, sugestao: ult ? { x: ult.x, y: ult.bottom + 400, coluna: ult.ultima } : null };

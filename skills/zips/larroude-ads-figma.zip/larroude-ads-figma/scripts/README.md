# Biblioteca de scripts
Scripts testados (01/10/2026) para as etapas que se repetem em toda tarefa. **Use estes antes de escrever código novo.** Se precisar mudar algo, ajuste o arquivo aqui e anote no fim desta página.

Figma: rode com `use_figma` (skillNames `figma-use`), editando só o bloco `CONFIG` no topo. Todos devolvem texto sem acento (o conector quebra com acentos no retorno).
Python: precisa de Pillow e numpy. Trabalhe numa pasta curta (ex.: `C:/Users/<voce>/airtmp`).

## Fluxo típico de uma peça
1. Onde criar → `figma/proximo_espaco.js` (Stories/Feed) ou regra de ADS em `references/mapa-figma-air.md`
2. Artboards → `figma/criar_formatos.js`
3. Fotos → `python/air_baixar.py` (Air) ou `python/site_produto.py` (site, SKU, ON/OFF)
4. Escolher fotos → `python/folha_contato.py` + conferir `references/log-fotos.md` (não repetir nos últimos 10 dias)
5. Recorte de produto (packshot) → `python/recorte_calcado.py`
6. Subir para o Figma → `figma/enviar_imagem.md`
7. Enquadrar → `figma/aplicar_crop.js` (ou calcular antes com `python/crop_celula.py`)
8. Textos de template → `figma/trocar_texto.js`
9. QA → `figma/qa_rapido.js` + folha de contato
10. Aprender com o ajuste da pessoa responsável → `figma/inspecionar_frames.js` antes e depois

## Figma (`figma/`)
| Script | O que faz | Altera o arquivo? |
|---|---|---|
| `proximo_espaco.js` | Colunas de uma seção, onde cada uma termina e onde começar a próxima tarefa | não |
| `criar_formatos.js` | Cria as artboards no padrão de canvas (mesmo tamanho lado a lado, tamanhos diferentes embaixo) e o marcador da tarefa | sim |
| `aplicar_crop.js` | Põe a foto no node com CROP sem esticar, zoom e centro escolhidos, e avisa resolução baixa | sim |
| `trocar_texto.js` | Troca texto mantendo o estilo de cada linha; avisa fonte faltando e texto passando da margem | sim |
| `qa_rapido.js` | Margens, camadas escondidas, crop vazando/esticado, resolução, fontes, nomes | não |
| `inspecionar_frames.js` | Raio-X de frames (posições, estilos, crops, efeitos) para comparar antes/depois | não |
| `enviar_imagem.md` | Passo a passo do upload (upload_assets + curl com bytes crus) | sim |
| `motion_letras.js` | Animação por letra (máscara por letra, sobe/sai com expo), padrão M01 de `references/motion-padroes.md` | sim |

## Python (`python/`)
| Script | O que faz |
|---|---|
| `air_baixar.py <versionId> saida.jpg [--largura 2400]` | Baixa a foto do Air pelo id de versão (imgix) |
| `site_produto.py <link/handle> [--baixar PASTA]` · `--colecao <handle>` | Título, SKU do modelo, ON/OFF, fotos do site |
| `recorte_calcado.py entrada saida.png [--thresh 18] [--contorno 23]` | Tira o fundo liso do packshot; contorno branco opcional (Dressing Guide) |
| `crop_celula.py W H cw ch [--zoom] [--cx] [--cy] [--preview]` | Calcula o imageTransform e a resolução |
| `folha_contato.py saida.jpg fotos... [--lado] [--colunas]` | Folha de contato numerada |

## Valores de referência
- `recorte_calcado.py`: `--thresh 18` padrão; `6` para calçado branco/claro. `--contorno 23` = adesivo do Dressing Guide; quiz/This or That sem contorno.
- Zoom da casa: leve, 1.05–1.2. Calçado no terço de baixo: `cy` 0.65–0.75.
- Resolução ≥ 1 (px de origem por px de saída). Abaixo disso: foto maior, ou upscale com IA só se realmente precisar, conferindo os detalhes.

## Testes (01/10/2026)
- Python: Inna Pump (site) → SKU do modelo L517-INNA-BLAC-0036, recorte com e sem contorno, crop 1080×1920 (res 1.91), folha de contato, download do Air (id de versão ok; id de asset dá erro claro).
- Figma: criar_formatos (2×3 + marcador), aplicar_crop (proporção exata, dentro dos limites), trocar_texto (2 estilos + caixa alta mantidos, linha extra), proximo_espaco (Dressing Guide → 3ª coluna; This or That → coluna C), inspecionar. Os nodes de teste foram apagados.

## Alterações
- 01/10/2026: versão inicial.
- 05/10/2026: motion_letras.js (GIF In Stock 60% aprovado).

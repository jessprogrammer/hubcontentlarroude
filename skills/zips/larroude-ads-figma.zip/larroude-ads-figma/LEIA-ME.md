# Skill · Larroudé · Criativos no Figma

## Instalar
- **claude.ai:** Settings → Capabilities → Skills → Upload skill → selecione `larroude-ads-figma.zip` → ative.
- **Claude Code:** descompacte em `~/.claude/skills/larroude-ads-figma/`.

## Pré-requisitos
- Conector **Figma** com acesso ao arquivo "FIGMA ZAINERS NOVO".
- Conector **Air** (workspace da Larroudé).
- Conector **Asana** (ler a tarefa e comentar a entrega).
- Python com Pillow e numpy, para os scripts de foto.
- **Fontes:**
  - Platform, Plain e Items instaladas.
  - Arquivos em `G:\…\Publico\CONTEÚDO\Brand Larroude\Fonts\Fonts` ou em Air › Graphic Design / Brand.
  - Very Vogue precisa estar disponível para a organização no Figma; senão o Claude não consegue editar esses textos.

## Permissões (importante)
O fluxo faz ações fora do computador:
- exportar imagens do Figma;
- subir arquivos no Air (criar pastas e importar);
- comentar no Asana mencionando uma pessoa.

Na primeira vez que cada ação aparecer, o Claude Code pode pedir permissão ou bloqueá-la. **Libere quando ele pedir**, ou autorize no chat ("autorizo exportar do Figma, subir no Air e comentar no Asana"). Sem isso a entrega para no meio.

## Como usar
Mande a tarefa do Asana (link ou nome). O Claude:
1. lê a tarefa;
2. escolhe a base aprovada e as fotos;
3. monta, faz 1 rodada de QA e entrega para revisão.

Depois da aprovação ele sobe no Air e comenta na tarefa.
Quando você ajustar uma peça, ele lê o que mudou e aprende.

Versão 01/10/2026

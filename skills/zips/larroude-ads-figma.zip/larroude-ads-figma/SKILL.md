---
name: larroude-ads-figma
description: Create, adapt, QA and deliver Larroudé creatives in the Figma file "FIGMA ZAINERS NOVO" — paid ads (ADS US / ADS BR: STATIC, CAROUSEL, GIF) and organic Instagram (Stories / Feed) — using real photos from Air or larroude.com, then export to Air and notify on Asana. Use whenever a Larroudé Asana task ([ADS US], [ADS BR], Stories, Feed), SKU list, collection ID, or "fazer os 3 formatos / carrossel / gif" request appears.
---

# Larroudé · Criativos no Figma

Arquivo Figma: `DRphNBA9HvgZ6HwazNMHrm` ("FIGMA ZAINERS NOVO").
- **ADS US:** `991:319`
- **ADS BR:** `3375:2`
- **Stories:** `188:214`
- **Feed:** `1894:2`
- **Bases:** "Claude Padrões ADS" `21378:2`
- **Regras do time:** "Claude Teste Zainers" `21120:2`

Papéis citados aqui:
- **quem solicitou:** a pessoa que abriu a tarefa no Asana.
- **pessoa responsável:** o designer que revisa e ajusta.
- **liderança / direção de marca:** decide as regras de marca.

## 0. Antes de tudo (todo início de tarefa)
1. **Permissões.** O fluxo chega a ações externas: exportar do Figma, subir no Air e comentar no Asana. Na primeira vez que cada uma aparecer, peça à pessoa que **libere a permissão** (ou que autorize no chat). Sem isso, a entrega trava no meio.
2. **Regras firmes.** Leia `references/regras-firmes.md`. Elas **sempre** valem. Rode o checklist delas antes de montar e de novo no QA.
3. **Regras do time.** Leia na página "Claude Teste Zainers" as colunas "Regras da casa" e "Produtos cancelados". Elas têm prioridade sobre `references/`.

## 1. Fluxo de uma tarefa (1 montagem, 1 QA)

> **Orçamento de tempo (Pietro, 06/10):** o objetivo é entregar um **rascunho forte rápido**, não a arte final. O Pietro sempre ajusta no fim, então:
> - no máximo **1 montagem + 1 correção**; depois disso, entregue e liste o que ficou pendente em vez de seguir corrigindo;
> - **1 folha de contato** só no final (ou só dos frames corrigidos), nunca screenshot por frame com retorno em base64;
> - **extensão/expansão de imagem (fundo esticado, outpaint): SEMPRE perguntar antes** (Pietro 06/10). Prefira recorte mais fechado, girar ou outra foto;
> - não perseguir detalhes finos (posição do logo em 1 card, 10 px de margem): anote na entrega e deixe para o ajuste dele;
> - pergunte antes só o que muda a estrutura (qual foto na capa, qual formato); o resto, decida e siga.
1. **Ler só a tarefa atual** no Asana: tipo, formatos, copy, SKUs ou link e o nome final das peças. **Nunca** use um trabalho anterior como base, nem que seja da mesma coleção.
2. **Escolher a base**:
   - primeiro a categoria certa dos **APPROVED LAYOUTS** (no fim da página "Claude Padrões ADS"): US/BR · Sale, Pre-Order, Copy, Just Logo, UGC;
   - depois as bases V/Q/H por formato (`references/padroes-ads.md`);
   - padrões fechados: carrossel ADS (título só no 1º card), GIF de corte seco, This or That, Dressing Guide.
   - **cardápio de movimentos** (`references/movimentos-ads.md`; visual na aba "Claude Referências", frame 21679:3): escolha 1 ou 2 movimentos por peça, **um diferente para cada peça da entrega**, e cite os números na entrega. Não pesquise marcas a cada ad: a coleta de marcas é mensal e só alimenta o cardápio.
3. **Onde criar:** ver `references/mapa-figma-air.md`.
   - **ADS:** à direita da última coluna, com 2 tarefas por coluna.
   - **Stories/Feed:** abaixo da última tarefa da coluna mais recente da seção (script `proximo_espaco.js`).
   - Se quem solicitou indicar um lugar, ele vale.
4. **Fotos, escolhidas pela beleza.** A primeira peça ou capa é a mais chamativa.
   - Busca no Air por SKU ou modelo, limitada à pasta certa (`mapa-figma-air.md` §2).
   - Monte a folha de contato (`folha_contato.py`).
   - Confira o `log-fotos.md`: não repetir foto usada nos últimos 10 dias, salvo pedido ou falta de material.
   - Material faltando → avise; não improvise.
5. **Montar com um script só**, partindo dos scripts de `scripts/`:
   - cria as artboards e põe as fotos com CROP;
   - aplica copy, logo e cor;
   - confere antes se tudo existe; se faltar algo, não altera nada.
6. **Cor:**
   - **preto** só quando a copy ou o logo está sobre branco ou cor clara, sem dividir espaço com mais nada;
   - arte escura ou contrastada, sem fundo branco → **branco**;
   - a cor pode mudar entre formatos.
   - Wordmark: o acento é **sempre rosa** e o tamanho é **o mesmo em todas as peças do mesmo formato**.
7. **QA, 1 rodada:**
   - rode `qa_rapido.js` e o checklist de regras firmes;
   - monte 1 folha de contato com todas as peças;
   - corrija só o que falhar e entregue.
   - A pessoa responsável faz o ajuste fino.
8. **Aprender com o ajuste.** Depois que a pessoa responsável ajustar, leia as peças com `inspecionar_frames.js` (só leitura). Registre em poucas linhas o que mudou e por quê.
9. **Entregar** (só depois da aprovação) → ver §3.

## 2. Nomes e formatos
- Formatos padrão: **A = 1080×1920**, **B = 1200×1200**, **C = 1200×628**.
- **Static:** nome da tarefa + `_A/_B/_C` (ex.: `232503476390_STATIC_MOST-AWARE_ON-FOOT_02_A`).
- **Carrossel:** nome da tarefa + letra do formato + número do card (ex.: `…_PRODUCT-MIX_02_A1…A4`, `_B1…`, `_C1…`).
- Arte nova ao lado das versões do mesmo tamanho; tamanhos diferentes embaixo.

## 3. Entrega (Air + Asana)
1. Confirme o caminho com a pessoa responsável antes de criar a pasta.
   - **ADS:** `ADS › US|BR › 2026 › <MÊS AA> › <MM.DD> › <nome curto da tarefa>`
   - **Orgânico:** `Graphic Design › Social / Organic › 2026 › <MÊS> › STORIES|FEED|REELS › <MM.DD nome>`
   - Use ponto no lugar de barra no nome (ex.: "New Drop 07.10").
2. Dentro da pasta da tarefa, **crie as subpastas antes de subir**:
   - `STATIC/01`, `STATIC/02`…: uma por arte/post, com todos os formatos dela juntos;
   - `GIF/01`, `GIF/02`…: os .mp4 de cada animação.
3. Exporte cada frame (`download_assets`, jpg, escala 1) e importe direto na subpasta (`create_import`, nome do arquivo = nome do frame).
4. **Confira a contagem** na pasta do Air (= número de peças) antes de comentar.
5. Comente na subtarefa "… - Graphic Design" com **menção real**:
   - **ADS:** `@Monique Tauane da Silva disponível aqui!` + link (gid 1210732809098268).
   - **Social:** `@Bruna Klaus disponível aqui!` + link (gid 1204514604884005).
   - Em teste, acrescente "(teste Claude)".
6. Registre as fotos usadas no `log-fotos.md`.

## 4. Referências e scripts
- `references/regras-firmes.md`: regras que sempre valem (checklist).
- `references/padroes-ads.md`: APPROVED LAYOUTS + bases V/Q/H.
- `references/mapa-figma-air.md`: onde fica cada coisa no Figma e no Air, e como buscar sem abrir todas as pastas.
- `references/log-fotos.md`: fotos já usadas.
- `references/qa-rapido.md`: checklist do QA.
- `references/larroude-creation-rules.md`: histórico de aprendizados (contexto, não lei; em conflito, valem as regras firmes).
- `references/movimentos-ads.md`: cardápio de movimentos de layout (P = ajustes do Pietro, R = marcas). Usar em toda tarefa de ADS.
- `references/refs/`: banco de referências de ADS (lista oficial da Marina, 06/10: CORE, FOOTWEAR e CREATIVE/GROWTH). Coleta mensal; alimenta o cardápio. São inspiração dentro dos limites da marca; dos concorrentes de calçado (FOOTWEAR), evitar repetir o material recente.
- `scripts/README.md`: biblioteca testada (Figma + Python). **Use antes de escrever código novo.**

## 5. Decidir, perguntar ou sinalizar
- **Decida** o que não muda o resultado: crop fino, posição dentro da base, cor pela regra.
- **Pergunte uma vez, no início,** o que muda o resultado: tarefa ambígua, board, produto sem foto.
- **Sinalize na entrega:** produto fora do site, foto repetida por falta de material, nome de arquivo fora do padrão.
- Nunca: imagem gerada por IA no lugar de foto real, texto convertido em vetor, apagar trabalho de outra pessoa.

## Como pedir (para quem usa)
```
Tarefa: [link ou nome no Asana]
(ou) Entrega: [n] artes · [formatos] · Tipo: STATIC/CAROUSEL/GIF
Produto/fotos: [SKUs, link ou "livre"] · Copy: [texto ou "só logo"]
Onde: [marcador/artboard, se quiser outro lugar]
```
